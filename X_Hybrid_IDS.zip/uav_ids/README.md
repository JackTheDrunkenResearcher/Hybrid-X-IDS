# UAV IDS — Online Intrusion Detection for UAVIDS-2025

## Quick start (Streamlit — recommended for demos)

One process, one command, no separate frontend server.

```bash
cd uav_ids
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt

streamlit run streamlit_app/app.py
# → opens automatically at http://localhost:8501
```

Everything — upload, preprocessing, training, HPO, results — happens in
this single browser tab. The Streamlit app reuses every backend module
(`preprocessing/`, `models/`, `training/`, `diagnostics/`) completely
unchanged from the FastAPI+React version below; only the UI layer differs.

---

## Quick start (FastAPI + React — full app, two processes)

### 1. Install Python dependencies
```bash
cd uav_ids
python3 -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Set API key (only for the LLM provider you use)
```bash
export OPENAI_API_KEY="sk-..."          # GPT-4o
export ANTHROPIC_API_KEY="sk-ant-..."  # Claude
# Qwen/Llama via Ollama: run `ollama serve` and `ollama pull qwen2:7b`
```

### 3. Start the backend
```bash
python server.py
# → http://localhost:8000
```

### 4. Start the dashboard (new terminal)
```bash
cd ui
npm install
npm run dev
# → http://localhost:5173
```

---

## Workflow

1. **Data tab** — Upload your synthetic UAVIDS-2025 CSV
2. **Preprocessing panel (left sidebar)** — Set window size, step size, n folds, gap, test fraction, RFE threshold → click **Run Preprocessing**
3. **Preprocessing tab** — Inspect all diagnostic plots (class distribution, density, histograms, boxplots, correlation heatmaps, IP freq, RFE importance, fold layout)
4. **Training panel** — Pick LLM provider, calibration method, device, models → click **Start Training**
5. **Training tab** — Watch live events, loss curves, CV metrics per fold, confusion matrices, ROC/PR curves, calibration curves
6. **HPO tab** — Select model + uni/multi objective + sampler/pruner → click **Start HPO** → see optimisation history, fANOVA importance, parallel coordinates, Pareto front
7. **Results tab** — Two metric tables (CV mean±std + final test) + all diagnostic figures

---

## File structure
```
uav_ids/
├── preprocessing/
│   └── pipeline.py          # Online preprocessing — exact notebook logic
├── models/
│   ├── embeddings.py         # Per-window LLM embeddings (GPT-4o/Claude/Qwen/Llama)
│   └── networks.py           # MLP, CNN1D, LSTM + EmbeddingFusion + XGBoost
├── training/
│   ├── rolling_cv.py         # Rolling window CV engine + metrics
│   └── optuna_engine.py      # Uni/multi-objective Bayesian HPO
├── diagnostics/
│   └── plots.py              # All 22 Plotly diagnostic figures
├── server.py                 # FastAPI backend + SSE streaming
├── ui/App.jsx                # React dashboard
└── requirements.txt
```

## LLM providers
| Provider | Free? | Needs |
|----------|-------|-------|
| gpt-4o   | No    | OPENAI_API_KEY |
| claude   | No    | ANTHROPIC_API_KEY |
| qwen     | Yes (local) | Ollama + `ollama pull qwen2:7b` |
| llama    | Yes (local) | Ollama + `ollama pull llama3.1:8b` |
