"""
training/optuna_engine.py

Bayesian hyperparameter optimisation with Optuna.

Two modes (user selects in dashboard):

  Uni-objective
    → TPE sampler + Hyperband pruner
    → Single objective: maximise weighted F1 on rolling CV validation mean
    → Returns best trial with single best_params dict

  Multi-objective (NSGA-II)
    → Optimise simultaneously: weighted F1 AND weighted ROC-AUC
    → Returns full Pareto front of non-dominated configurations
    → User can pick any Pareto-optimal point from the dashboard

For each trial:
  - Suggest hyperparameters from the search space for the selected model
  - Run a FAST rolling CV (fewer folds / epochs than full CV) for speed
  - Report intermediate values per fold for Hyperband pruning (uni mode)
  - Emit SSE events so the dashboard shows live trial progress

Visualisation data produced:
  - Optimisation history (best value per trial)
  - Parameter importance (fANOVA)
  - Parallel coordinates
  - Pareto front scatter (multi mode)
  - Slice plots per hyperparameter
  - Per-trial metrics DataFrame
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from models.networks import (
    MLPConfig, CNNConfig, LSTMConfig, XGBConfig,
    RFConfig, ETConfig, GBConfig, HGBConfig,
    AdaConfig, BaggingConfig, Stacking1Config, Stacking2Config, LGBMConfig,
    build_mlp, build_cnn, build_lstm,
    XGBoostModel, SklearnModel,
    build_rf, build_et, build_gb, build_hgb,
    build_ada, build_bagging, build_stacking1, build_stacking2, build_lgbm,
)
from models.embeddings import WindowEmbedder
from preprocessing.pipeline import OnlinePreprocessingPipeline
from training.rolling_cv import RollingCVTrainer, compute_metrics, aggregate_cv_metrics

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class OptunaConfig:
    mode:          str   = "uni"        # "uni" | "multi"
    model_name:    str   = "xgb"   # mlp|cnn|lstm|xgb|rf|et|gb|hgb|ada|bagging|stacking1|stacking2|lgbm
    n_trials:      int   = 40
    timeout_s:     Optional[float] = None

    # Uni-objective
    sampler:       str   = "tpe"        # tpe | cmaes | random
    pruner:        str   = "hyperband"  # hyperband | median | nop
    objective:     str   = "f1"         # f1 | roc_auc | accuracy

    # Multi-objective
    objectives:    List[str] = field(default_factory=lambda: ["f1", "roc_auc"])
    directions:    List[str] = field(default_factory=lambda: ["maximize","maximize"])

    # Fast CV settings inside each trial (fewer folds / epochs)
    fast_n_folds:  int   = 2
    fast_epochs:   int   = 10

    # Storage
    storage_url:   Optional[str] = None
    study_name:    str   = "uav_ids_hpo"
    seed:          int   = 42


# ─────────────────────────────────────────────────────────────────────────────
# Search spaces
# ─────────────────────────────────────────────────────────────────────────────

def suggest_mlp(trial) -> MLPConfig:
    return MLPConfig(
        n_layers      = trial.suggest_int("n_layers",    1, 5),
        hidden_dim    = trial.suggest_categorical("hidden_dim", [64, 128, 256, 512]),
        dropout       = trial.suggest_float("dropout",   0.0, 0.5),
        activation    = trial.suggest_categorical("activation", ["relu","gelu","silu"]),
        use_batchnorm = trial.suggest_categorical("use_batchnorm", [True, False]),
        lr            = trial.suggest_float("lr",        1e-4, 1e-2, log=True),
        batch_size    = trial.suggest_categorical("batch_size", [32, 64, 128, 256]),
        epochs        = trial.suggest_int("epochs",      10, 80),
        proj_dim      = trial.suggest_categorical("proj_dim", [32, 64, 128]),
        calibration   = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


def suggest_cnn(trial) -> CNNConfig:
    return CNNConfig(
        n_blocks      = trial.suggest_int("n_blocks",    1, 4),
        out_channels  = trial.suggest_categorical("out_channels", [32, 64, 128]),
        kernel_size   = trial.suggest_categorical("kernel_size",  [3, 5, 7]),
        dilation_base = trial.suggest_categorical("dilation_base",[1, 2, 4]),
        use_residual  = trial.suggest_categorical("use_residual", [True, False]),
        dropout       = trial.suggest_float("dropout",   0.0, 0.5),
        lr            = trial.suggest_float("lr",        1e-4, 1e-2, log=True),
        batch_size    = trial.suggest_categorical("batch_size", [32, 64, 128, 256]),
        epochs        = trial.suggest_int("epochs",      10, 80),
        proj_dim      = trial.suggest_categorical("proj_dim", [32, 64, 128]),
        seq_len       = trial.suggest_categorical("seq_len", [8, 16, 32]),
        calibration   = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


def suggest_lstm(trial) -> LSTMConfig:
    return LSTMConfig(
        n_layers      = trial.suggest_int("n_layers",    1, 4),
        hidden_size   = trial.suggest_categorical("hidden_size", [64, 128, 256, 512]),
        dropout       = trial.suggest_float("dropout",   0.0, 0.5),
        bidirectional = trial.suggest_categorical("bidirectional", [True, False]),
        lr            = trial.suggest_float("lr",        1e-4, 1e-2, log=True),
        batch_size    = trial.suggest_categorical("batch_size", [32, 64, 128, 256]),
        epochs        = trial.suggest_int("epochs",      10, 80),
        proj_dim      = trial.suggest_categorical("proj_dim", [32, 64, 128]),
        seq_len       = trial.suggest_categorical("seq_len", [8, 16, 32]),
        calibration   = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


def suggest_xgb(trial) -> XGBConfig:
    return XGBConfig(
        n_estimators      = trial.suggest_int("n_estimators",    50, 500),
        max_depth         = trial.suggest_int("max_depth",       2, 10),
        learning_rate     = trial.suggest_float("lr",            0.01, 0.3, log=True),
        subsample         = trial.suggest_float("subsample",     0.5, 1.0),
        colsample         = trial.suggest_float("colsample",     0.5, 1.0),
        reg_alpha         = trial.suggest_float("reg_alpha",     1e-4, 10.0, log=True),
        reg_lambda        = trial.suggest_float("reg_lambda",    1e-4, 10.0, log=True),
        min_child_weight  = trial.suggest_int("min_child_weight",1, 10),
        calibration       = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


SUGGESTERS = {"mlp": suggest_mlp, "cnn": suggest_cnn,
              "lstm": suggest_lstm, "xgb": suggest_xgb}


def suggest_rf(trial) -> RFConfig:
    return RFConfig(
        n_estimators      = trial.suggest_int("n_estimators",      50, 500),
        max_depth         = trial.suggest_int("max_depth",         3, 20),
        min_samples_leaf  = trial.suggest_int("min_samples_leaf",  1, 20),
        min_samples_split = trial.suggest_int("min_samples_split", 2, 20),
        max_features      = trial.suggest_categorical("max_features", ["sqrt", "log2", None]),
        class_weight      = trial.suggest_categorical("class_weight",
                              ["balanced", "balanced_subsample"]),
        calibration       = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


def suggest_et(trial) -> ETConfig:
    return ETConfig(
        n_estimators      = trial.suggest_int("n_estimators",      50, 500),
        max_depth         = trial.suggest_int("max_depth",         3, 20),
        min_samples_leaf  = trial.suggest_int("min_samples_leaf",  1, 20),
        min_samples_split = trial.suggest_int("min_samples_split", 2, 20),
        max_features      = trial.suggest_categorical("max_features", ["sqrt", "log2", None]),
        class_weight      = trial.suggest_categorical("class_weight",
                              ["balanced", "balanced_subsample"]),
        calibration       = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


def suggest_gb(trial) -> GBConfig:
    return GBConfig(
        n_estimators      = trial.suggest_int("n_estimators",      50, 400),
        max_depth         = trial.suggest_int("max_depth",         2, 10),
        learning_rate     = trial.suggest_float("learning_rate",   0.005, 0.3, log=True),
        subsample         = trial.suggest_float("subsample",       0.5, 1.0),
        min_samples_leaf  = trial.suggest_int("min_samples_leaf",  1, 20),
        calibration       = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


def suggest_hgb(trial) -> HGBConfig:
    return HGBConfig(
        max_iter          = trial.suggest_int("max_iter",          50, 400),
        max_depth         = trial.suggest_int("max_depth",         2, 15),
        learning_rate     = trial.suggest_float("learning_rate",   0.005, 0.3, log=True),
        min_samples_leaf  = trial.suggest_int("min_samples_leaf",  5, 50),
        l2_regularization = trial.suggest_float("l2_regularization", 1e-6, 10.0, log=True),
        calibration       = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


def suggest_ada(trial) -> AdaConfig:
    return AdaConfig(
        n_estimators  = trial.suggest_int("n_estimators",   10, 300),
        learning_rate = trial.suggest_float("learning_rate", 0.01, 2.0, log=True),
        dt_max_depth  = trial.suggest_int("dt_max_depth",   1, 8),
        calibration   = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


def suggest_bagging(trial) -> BaggingConfig:
    return BaggingConfig(
        n_estimators  = trial.suggest_int("n_estimators",  5, 100),
        max_samples   = trial.suggest_float("max_samples", 0.5, 1.0),
        max_features  = trial.suggest_float("max_features_frac", 0.5, 1.0),
        dt_max_depth  = trial.suggest_int("dt_max_depth",  2, 15),
        calibration   = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


def suggest_stacking1(trial) -> Stacking1Config:
    return Stacking1Config(
        dt_max_depth  = trial.suggest_int("dt_max_depth",   2, 12),
        hgb_max_iter  = trial.suggest_int("hgb_max_iter",   50, 300),
        ridge_alpha   = trial.suggest_float("ridge_alpha",  0.01, 100.0, log=True),
        calibration   = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


def suggest_stacking2(trial) -> Stacking2Config:
    return Stacking2Config(
        dt_max_depth  = trial.suggest_int("dt_max_depth",   2, 12),
        lr_C          = trial.suggest_float("lr_C",         0.001, 100.0, log=True),
        lr_max_iter   = trial.suggest_int("lr_max_iter",    200, 2000),
        ridge_alpha   = trial.suggest_float("ridge_alpha",  0.01, 100.0, log=True),
        calibration   = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


def suggest_lgbm(trial) -> LGBMConfig:
    return LGBMConfig(
        n_estimators      = trial.suggest_int("n_estimators",       50, 500),
        max_depth         = trial.suggest_int("max_depth",          3, 15),
        learning_rate     = trial.suggest_float("learning_rate",    0.005, 0.3, log=True),
        num_leaves        = trial.suggest_int("num_leaves",         15, 255),
        subsample         = trial.suggest_float("subsample",        0.5, 1.0),
        colsample_bytree  = trial.suggest_float("colsample_bytree", 0.5, 1.0),
        reg_alpha         = trial.suggest_float("reg_alpha",        1e-5, 10.0, log=True),
        reg_lambda        = trial.suggest_float("reg_lambda",       1e-5, 10.0, log=True),
        min_child_samples = trial.suggest_int("min_child_samples",  5, 100),
        calibration       = trial.suggest_categorical("calibration", ["isotonic","sigmoid"]),
    )


# Complete registry of all models
SUGGESTERS = {
    "mlp":       suggest_mlp,
    "cnn":       suggest_cnn,
    "lstm":      suggest_lstm,
    "xgb":       suggest_xgb,
    "rf":        suggest_rf,
    "et":        suggest_et,
    "gb":        suggest_gb,
    "hgb":       suggest_hgb,
    "ada":       suggest_ada,
    "bagging":   suggest_bagging,
    "stacking1": suggest_stacking1,
    "stacking2": suggest_stacking2,
    "lgbm":      suggest_lgbm,
}


# ─────────────────────────────────────────────────────────────────────────────
# Fast mini-CV for inside each Optuna trial
# ─────────────────────────────────────────────────────────────────────────────

class TrialEvaluator:
    """
    Lightweight CV runner used inside Optuna trials (fast settings).

    Delegates to RollingCVTrainer._train_torch / _train_xgb so the
    calibration strategy is identical to the full training run — no
    separate (broken) calibration logic here.
    """

    def __init__(
        self,
        pipeline:    OnlinePreprocessingPipeline,
        embedder:    Optional[WindowEmbedder],
        device:      str,
        fast_n_folds:int,
        fast_epochs: int,
        calibration: str = "isotonic",
    ):
        self.pipeline     = pipeline
        self.embedder     = embedder
        self.device       = device
        self.fast_n_folds = fast_n_folds
        self.fast_epochs  = fast_epochs
        self.calibration  = calibration
        self.n_features   = pipeline.n_features
        self.n_classes    = pipeline.n_classes
        self.embed_dim    = embedder.embed_dim if embedder else 0

        # Reuse the trainer's helpers — same calibration logic as full CV
        self._trainer = RollingCVTrainer(
            pipeline    = pipeline,
            embedder    = embedder,
            event_cb    = None,
            device      = device,
            calibration = calibration,
        )

    def evaluate(self, model_cfg, model_name: str, trial=None) -> Dict[str, float]:
        """Return mean metrics over fast_n_folds folds."""
        import optuna

        folds        = self.pipeline.folds[:self.fast_n_folds]
        fold_metrics = []

        for fi in range(len(folds)):
            Xtr, Ytr, Xval, Yval = self.pipeline.get_fold_data(fi)
            if len(Xtr) == 0 or len(Xval) == 0:
                continue

            Xtr_p  = self._trainer._pack(
                Xtr, self._trainer._get_embed(Xtr, Ytr, fi))
            Xval_p = self._trainer._pack(
                Xval, self._trainer._get_embed(Xval, Yval, fi))
            Ytr_np  = Ytr.values.astype(int)
            Yval_np = Yval.values.astype(int)

            # Use reduced epochs for speed
            fast_cfg = _override_epochs(model_cfg, self.fast_epochs)
            model    = _build(model_name, fast_cfg, self.n_features,
                              self.embed_dim, self.n_classes, self.device)

            try:
                # Delegate to the same methods used by the full CV trainer
                if hasattr(model, '_loss_history'):       # TorchWrapper
                    cal_model, _ = self._trainer._train_torch(
                        model, Xtr_p, Ytr_np, Xval_p, Yval_np)
                elif isinstance(model, XGBoostModel):     # XGBoost
                    cal_model = self._trainer._train_xgb(model, Xtr_p, Ytr_np)
                elif isinstance(model, SklearnModel):     # RF/ET/GB/HGB/Ada/Bag/Stack/LGBM
                    cal_model = self._trainer._train_sklearn(model, Xtr_p, Ytr_np)
                else:
                    raise TypeError(f"Unknown model type: {type(model)}")

                proba   = cal_model.predict_proba(Xval_p)
                preds   = proba.argmax(axis=1)
                metrics = compute_metrics(Yval_np, preds, proba, self.n_classes)
                fold_metrics.append(metrics)

                # Hyperband pruning — report intermediate value after each fold
                if trial is not None:
                    intermediate = float(metrics.get("f1", 0.0))
                    trial.report(intermediate, step=fi)
                    if trial.should_prune():
                        raise optuna.exceptions.TrialPruned()

            except optuna.exceptions.TrialPruned:
                raise
            except Exception as e:
                logger.warning(f"Trial fold {fi} failed: {e}")
                continue

        if not fold_metrics:
            return {k: 0.0 for k in ["accuracy", "f1", "precision",
                                      "recall", "roc_auc"]}

        agg = aggregate_cv_metrics(fold_metrics)
        return {k: v["mean"] for k, v in agg.items()}


def _override_epochs(cfg, fast_epochs: int):
    """Return a copy of cfg with reduced epoch count."""
    import copy
    c = copy.deepcopy(cfg)
    if hasattr(c, "epochs"):
        c.epochs = min(getattr(c, "epochs", fast_epochs), fast_epochs)
    return c


def _build(model_name, cfg, n_features, embed_dim, n_classes, device):
    if model_name == "mlp":
        return build_mlp(n_features, embed_dim, n_classes, cfg, device)
    elif model_name == "cnn":
        return build_cnn(n_features, embed_dim, n_classes, cfg, device)
    elif model_name == "lstm":
        return build_lstm(n_features, embed_dim, n_classes, cfg, device)
    elif model_name == "xgb":
        return XGBoostModel(n_classes, cfg)
    elif model_name == "rf":
        return build_rf(n_classes, cfg)
    elif model_name == "et":
        return build_et(n_classes, cfg)
    elif model_name == "gb":
        return build_gb(n_classes, cfg)
    elif model_name == "hgb":
        return build_hgb(n_classes, cfg)
    elif model_name == "ada":
        return build_ada(n_classes, cfg)
    elif model_name == "bagging":
        return build_bagging(n_classes, cfg)
    elif model_name == "stacking1":
        return build_stacking1(n_classes, cfg)
    elif model_name == "stacking2":
        return build_stacking2(n_classes, cfg)
    elif model_name == "lgbm":
        return build_lgbm(n_classes, cfg)
    raise ValueError(f"Unknown model: {model_name}")


# ─────────────────────────────────────────────────────────────────────────────
# Optuna study runner
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class HPOResult:
    mode:          str
    model_name:    str
    best_params:   Dict[str, Any]
    best_values:   Dict[str, float]
    all_trials_df: pd.DataFrame          # one row per trial
    pareto_front:  Optional[pd.DataFrame] = None  # multi-obj only
    importance_df: Optional[pd.DataFrame] = None  # fANOVA importances
    n_trials_done: int                    = 0
    elapsed_s:     float                  = 0.0


def run_optuna(
    optuna_cfg:  OptunaConfig,
    pipeline:    OnlinePreprocessingPipeline,
    embedder:    Optional[WindowEmbedder],
    device:      str = "cpu",
    event_cb:    Optional[Callable] = None,
) -> HPOResult:
    """Run Optuna HPO. Returns HPOResult with all diagnostic data."""
    import optuna
    optuna.logging.set_verbosity(optuna.logging.WARNING)

    emit = event_cb or (lambda t, d: None)
    cfg  = optuna_cfg

    evaluator = TrialEvaluator(
        pipeline     = pipeline,
        embedder     = embedder,
        device       = device,
        fast_n_folds = cfg.fast_n_folds,
        fast_epochs  = cfg.fast_epochs,
    )

    suggest_fn = SUGGESTERS.get(cfg.model_name, suggest_mlp)

    # ── Build study ────────────────────────────────────────────────────────
    if cfg.mode == "multi":
        sampler = optuna.samplers.NSGAIISampler(seed=cfg.seed)
        pruner  = optuna.pruners.NopPruner()
        study   = optuna.create_study(
            study_name  = f"{cfg.study_name}_{cfg.model_name}_multi",
            directions  = cfg.directions,
            sampler     = sampler,
            storage     = cfg.storage_url,
        )
    else:
        samplers = {
            "tpe":   lambda: optuna.samplers.TPESampler(
                         n_startup_trials=10, multivariate=True, seed=cfg.seed),
            "cmaes": lambda: optuna.samplers.CmaEsSampler(seed=cfg.seed),
            "random":lambda: optuna.samplers.RandomSampler(seed=cfg.seed),
        }
        pruners  = {
            "hyperband": lambda: optuna.pruners.HyperbandPruner(
                             min_resource=1, max_resource=cfg.fast_n_folds,
                             reduction_factor=3),
            "median":    lambda: optuna.pruners.MedianPruner(n_startup_trials=5),
            "nop":       lambda: optuna.pruners.NopPruner(),
        }
        sampler = samplers.get(cfg.sampler, samplers["tpe"])()
        pruner  = pruners.get(cfg.pruner,  pruners["hyperband"])()
        study   = optuna.create_study(
            study_name  = f"{cfg.study_name}_{cfg.model_name}_uni",
            direction   = "maximize",
            sampler     = sampler,
            pruner      = pruner,
            storage     = cfg.storage_url,
        )

    # ── Objective closure ──────────────────────────────────────────────────
    def objective(trial):
        model_cfg = suggest_fn(trial)
        try:
            metrics = evaluator.evaluate(model_cfg, cfg.model_name, trial)
        except optuna.exceptions.TrialPruned:
            raise
        except Exception as e:
            logger.warning(f"Trial {trial.number} failed: {e}")
            return (0.0, 0.0) if cfg.mode == "multi" else 0.0

        emit("trial_done", {
            "trial":       trial.number,
            "model":       cfg.model_name,
            "mode":        cfg.mode,
            "params":      trial.params,
            "metrics":     metrics,
        })

        if cfg.mode == "multi":
            return tuple(metrics.get(obj, 0.0) for obj in cfg.objectives)
        else:
            return float(metrics.get(cfg.objective, 0.0))

    # ── Optimise ───────────────────────────────────────────────────────────
    t0 = time.time()
    emit("hpo_start", {"model": cfg.model_name, "mode": cfg.mode,
                        "n_trials": cfg.n_trials})

    study.optimize(
        objective,
        n_trials  = cfg.n_trials,
        timeout   = cfg.timeout_s,
        catch     = (Exception,),
        show_progress_bar=False,
    )

    elapsed = time.time() - t0
    emit("hpo_done", {"model": cfg.model_name, "elapsed_s": elapsed})

    # ── Collect trials DataFrame ────────────────────────────────────────────
    rows = []
    for t in study.trials:
        row = {"trial": t.number, "state": str(t.state)}
        row.update(t.params)
        if cfg.mode == "multi" and t.values:
            for obj, val in zip(cfg.objectives, t.values):
                row[obj] = val
        elif t.value is not None:
            row[cfg.objective] = t.value
        rows.append(row)
    all_trials_df = pd.DataFrame(rows)

    # ── Best params ─────────────────────────────────────────────────────────
    pareto_df = None
    if cfg.mode == "multi":
        best_trials  = study.best_trials
        best_params  = best_trials[0].params if best_trials else {}
        best_values  = {obj: v for obj, v in zip(cfg.objectives, best_trials[0].values)} \
                       if best_trials and best_trials[0].values else {}
        if best_trials:
            pareto_rows = []
            for bt in best_trials:
                r = {"trial": bt.number}
                r.update(bt.params)
                if bt.values:
                    for obj, val in zip(cfg.objectives, bt.values):
                        r[obj] = val
                pareto_rows.append(r)
            pareto_df = pd.DataFrame(pareto_rows)
    else:
        try:
            best_params = study.best_trial.params
            best_values = {cfg.objective: study.best_trial.value}
        except Exception:
            best_params, best_values = {}, {}

    # ── Parameter importance (fANOVA) ───────────────────────────────────────
    importance_df = None
    try:
        imp = optuna.importance.get_param_importances(
            study,
            evaluator=optuna.importance.FanovaImportanceEvaluator(),
        )
        importance_df = pd.DataFrame([
            {"parameter": k, "importance": v} for k, v in imp.items()
        ]).sort_values("importance", ascending=False)
    except Exception as e:
        logger.warning(f"fANOVA failed: {e}")

    return HPOResult(
        mode          = cfg.mode,
        model_name    = cfg.model_name,
        best_params   = best_params,
        best_values   = best_values,
        all_trials_df = all_trials_df,
        pareto_front  = pareto_df,
        importance_df = importance_df,
        n_trials_done = len(study.trials),
        elapsed_s     = elapsed,
    )
