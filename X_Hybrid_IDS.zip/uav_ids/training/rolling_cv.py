"""
training/rolling_cv.py

Rolling window cross-validation engine.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, recall_score, roc_auc_score,
)
from sklearn.preprocessing import label_binarize
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression

from preprocessing.pipeline import OnlinePreprocessingPipeline
from models.embeddings import WindowEmbedder
from models.networks import TorchWrapper, XGBoostModel, SklearnModel

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Probability calibration
# ─────────────────────────────────────────────────────────────────────────────

def _fit_calibrators(
    raw_proba: np.ndarray,   # (N, n_classes) — from training data
    y_true:    np.ndarray,   # (N,)
    method:    str = "isotonic",
) -> list:
    """
    Fit one per-class calibrator on TRAINING data probabilities.
    Returns a list of calibrators (one per class, or None if degenerate).
    Fitting on TRAIN (not val) prevents the calibrator from simply memorising
    the validation set, which would collapse all predictions to the majority class.
    """
    n_classes   = raw_proba.shape[1]
    calibrators = []

    for k in range(n_classes):
        scores = raw_proba[:, k]
        y_bin  = (y_true == k).astype(int)

        # Skip if only one class present, or scores have no variance
        if y_bin.sum() == 0 or y_bin.sum() == len(y_bin):
            calibrators.append(None)
            continue
        if scores.std() < 1e-6:
            calibrators.append(None)
            continue

        try:
            if method == "isotonic":
                cal = IsotonicRegression(out_of_bounds="clip")
                cal.fit(scores, y_bin)
            else:
                cal = LogisticRegression(C=1.0, solver="lbfgs", max_iter=1000)
                cal.fit(scores.reshape(-1, 1), y_bin)
            calibrators.append(cal)
        except Exception:
            calibrators.append(None)

    return calibrators


def _apply_calibrators(
    raw_proba:   np.ndarray,
    calibrators: list,
    method:      str = "isotonic",
) -> np.ndarray:
    """
    Apply fitted calibrators to new probability estimates.
    Falls back to raw score for any degenerate calibrator.
    Re-normalises rows to sum to 1.
    """
    cal_proba = raw_proba.copy().astype(float)

    for k, cal in enumerate(calibrators):
        if cal is None:
            continue   # keep raw score
        scores = raw_proba[:, k]
        try:
            if method == "isotonic":
                cal_proba[:, k] = cal.predict(scores)
            else:
                cal_proba[:, k] = cal.predict_proba(scores.reshape(-1, 1))[:, 1]
        except Exception:
            pass   # keep raw score on error

    # Clip negatives (isotonic can rarely produce small negatives)
    cal_proba = np.clip(cal_proba, 0, None)

    row_sums = cal_proba.sum(axis=1, keepdims=True)
    row_sums = np.where(row_sums < 1e-9, 1.0, row_sums)
    cal_proba = cal_proba / row_sums

    return cal_proba


class CalibratedModel:
    """Wraps a trained model with optional probability calibration."""

    def __init__(self, base_model, calibrators: Optional[list], method: str):
        self.base_model  = base_model
        self.calibrators = calibrators
        self.method      = method

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        raw = self.base_model.predict_proba(X)
        if self.calibrators is None:
            return raw
        return _apply_calibrators(raw, self.calibrators, self.method)

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.predict_proba(X).argmax(axis=1)


# ─────────────────────────────────────────────────────────────────────────────
# XGBoost probability alignment
# ─────────────────────────────────────────────────────────────────────────────

def _align_xgb_proba(proba: np.ndarray, classes: np.ndarray, n_classes: int) -> np.ndarray:
    """
    XGBoost only outputs columns for classes present in the training fold.
    Expand to full n_classes columns, placing each column correctly by class index.
    """
    if proba.shape[1] == n_classes:
        return proba
    full = np.zeros((len(proba), n_classes), dtype=float)
    for col_idx, cls in enumerate(classes):
        if int(cls) < n_classes:
            full[:, int(cls)] = proba[:, col_idx]
    # Rows that got no probability mass → uniform
    row_sums = full.sum(axis=1)
    zero_rows = row_sums == 0
    if zero_rows.any():
        full[zero_rows] = 1.0 / n_classes
    return full


# ─────────────────────────────────────────────────────────────────────────────
# Metrics
# ─────────────────────────────────────────────────────────────────────────────

def compute_metrics(
    y_true:    np.ndarray,
    y_pred:    np.ndarray,
    y_proba:   np.ndarray,
    n_classes: int,
    average:   str = "weighted",
) -> Dict[str, float]:
    classes = list(range(n_classes))
    acc = float(accuracy_score(y_true, y_pred))
    f1  = float(f1_score(y_true, y_pred, average=average, zero_division=0))
    pre = float(precision_score(y_true, y_pred, average=average, zero_division=0))
    rec = float(recall_score(y_true, y_pred, average=average, zero_division=0))
    try:
        present = sorted(set(y_true.tolist()))
        if len(present) < 2:
            auc = float("nan")
        else:
            # label_binarize always produces one column per class in `classes`.
            # Slice BOTH y_bin and y_proba by the same present-class indices
            # so the shapes match.
            y_bin = label_binarize(y_true, classes=classes)  # (N, n_classes)
            if y_bin.ndim == 1:
                # Happens when n_classes==2 — sklearn returns (N,) not (N,2)
                auc = float(roc_auc_score(y_true, y_proba[:, 1]))
            else:
                # Use only columns for classes that appear in this split
                auc = float(roc_auc_score(
                    y_bin[:, present],
                    y_proba[:, present],
                    average=average,
                    multi_class="ovr",
                ))
    except Exception as e:
        logger.debug(f"ROC-AUC failed: {e}")
        auc = float("nan")
    return {"accuracy": acc, "f1": f1, "precision": pre,
            "recall": rec, "roc_auc": auc}


def aggregate_cv_metrics(fold_metrics: List[Dict[str, float]]) -> Dict[str, Dict[str, float]]:
    if not fold_metrics:
        return {}
    result = {}
    for k in fold_metrics[0].keys():
        vals = [m[k] for m in fold_metrics
                if k in m and not (isinstance(m[k], float) and np.isnan(m[k]))]
        result[k] = {
            "mean":     float(np.mean(vals))   if vals else float("nan"),
            "std":      float(np.std(vals))    if vals else float("nan"),
            "min":      float(np.min(vals))    if vals else float("nan"),
            "max":      float(np.max(vals))    if vals else float("nan"),
            "per_fold": vals,
        }
    return result


# ─────────────────────────────────────────────────────────────────────────────
# Result containers
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class FoldResult:
    fold:          int
    train_metrics: Dict[str, float]
    val_metrics:   Dict[str, float]
    y_true_val:    List[int]
    y_pred_val:    List[int]
    y_proba_val:   List[List[float]]
    loss_history:  List[float]
    elapsed_s:     float


@dataclass
class CVResult:
    model_name:         str
    fold_results:       List[FoldResult]    = field(default_factory=list)
    cv_train_agg:       Dict[str, Dict]     = field(default_factory=dict)
    cv_val_agg:         Dict[str, Dict]     = field(default_factory=dict)
    final_model:        Any                 = None
    test_metrics:       Dict[str, float]    = field(default_factory=dict)
    y_true_test:        List[int]           = field(default_factory=list)
    y_pred_test:        List[int]           = field(default_factory=list)
    y_proba_test:       List[List[float]]   = field(default_factory=list)
    feature_importance: Dict[str, float]    = field(default_factory=dict)
    elapsed_total_s:    float               = 0.0


# ─────────────────────────────────────────────────────────────────────────────
# Rolling CV trainer
# ─────────────────────────────────────────────────────────────────────────────

class RollingCVTrainer:

    def __init__(
        self,
        pipeline:    OnlinePreprocessingPipeline,
        embedder:    Optional[WindowEmbedder],
        event_cb:    Optional[Callable] = None,
        device:      str                = "cpu",
        calibration: str                = "isotonic",
    ):
        self.pipeline    = pipeline
        self.embedder    = embedder
        self.event_cb    = event_cb or (lambda t, d: None)
        self.device      = device
        self.calibration = calibration
        self.n_features  = pipeline.n_features
        self.n_classes   = pipeline.n_classes
        self.embed_dim   = embedder.embed_dim if embedder else 0

    def _pack(self, X: pd.DataFrame, embed: np.ndarray) -> np.ndarray:
        Xnp = X.values.astype(np.float32)
        if self.embed_dim > 0 and len(embed) > 0:
            return np.concatenate([Xnp, np.tile(embed, (len(Xnp), 1))], axis=1)
        return Xnp

    def _get_embed(self, X, Y, fold_idx):
        if self.embedder is None or self.embed_dim == 0:
            return np.zeros(0, dtype=np.float32)
        return self.embedder.embed(X, Y, self.pipeline.class_names, fold_idx)

    def _emit(self, event_type, data):
        try:
            self.event_cb(event_type, data)
        except Exception:
            pass

    def _eval(self, model, X, Y) -> Tuple[Dict, np.ndarray, np.ndarray]:
        proba   = model.predict_proba(X)
        preds   = proba.argmax(axis=1)
        metrics = compute_metrics(Y, preds, proba, self.n_classes)
        return metrics, preds, proba

    # ── Train one neural-net fold ─────────────────────────────────────────────

    def _train_torch(self, model, Xtr, Ytr, Xval, Yval):
        """
        Train neural net on all of Xtr. No calibration by default —
        softmax already produces normalised probabilities, and isotonic
        calibration on small windows destroys predictions.
        """
        model.fit(Xtr, Ytr)
        loss_hist = model._loss_history.copy()
        cal_model = CalibratedModel(model, None, self.calibration)
        return cal_model, loss_hist

    # ── Train one XGBoost fold ────────────────────────────────────────────────

    def _train_xgb(self, model: XGBoostModel, Xtr: np.ndarray, Ytr: np.ndarray) -> "CalibratedModel":
        """
        Train XGBoost on ALL of Xtr — no calibration.

        Tree-based models with balanced classes produce well-calibrated
        probabilities natively.  Isotonic calibration on a small held-out
        subset actively DESTROYS the predictions (ROC-AUC 0.83 but
        accuracy 0.38) because the isotonic step function learned on
        ~200 samples per class is too noisy and flips correct argmax
        decisions when applied to the test set.
        """
        model.fit(Xtr, Ytr)
        return CalibratedModel(model, None, self.calibration)

    def _train_sklearn(self, model: SklearnModel, Xtr: np.ndarray, Ytr: np.ndarray) -> "CalibratedModel":
        """
        Train sklearn/LightGBM model on ALL of Xtr — no calibration.
        Same reasoning as _train_xgb.
        """
        model.fit(Xtr, Ytr)
        return CalibratedModel(model, None, self.calibration)

    # ── Main CV loop ──────────────────────────────────────────────────────────

    def run_model(self, model_name: str, model_cfg, model_builder_fn: Callable) -> CVResult:
        t0     = time.time()
        result = CVResult(model_name=model_name)
        folds  = self.pipeline.folds

        self._emit("training_start", {"model": model_name, "n_folds": len(folds)})

        for fold_idx, fold in enumerate(folds):
            fold_t0 = time.time()
            self._emit("fold_start", {"model": model_name, "fold": fold_idx, **fold})

            Xtr, Ytr, Xval, Yval = self.pipeline.get_fold_data(fold_idx)

            if len(Xtr) == 0 or len(Xval) == 0:
                logger.warning(f"Fold {fold_idx}: empty — skipping")
                continue

            Xtr_p  = self._pack(Xtr,  self._get_embed(Xtr,  Ytr,  fold_idx))
            Xval_p = self._pack(Xval, self._get_embed(Xval, Yval, fold_idx))
            Ytr_np  = Ytr.values.astype(int)
            Yval_np = Yval.values.astype(int)

            model = model_builder_fn(model_cfg)

            try:
                if isinstance(model, TorchWrapper):
                    cal_model, loss_hist = self._train_torch(
                        model, Xtr_p, Ytr_np, Xval_p, Yval_np)

                elif isinstance(model, XGBoostModel):
                    cal_model = self._train_xgb(model, Xtr_p, Ytr_np)
                    loss_hist = []

                elif isinstance(model, SklearnModel):
                    cal_model = self._train_sklearn(model, Xtr_p, Ytr_np)
                    loss_hist = []

                else:
                    raise TypeError(f"Unknown model type: {type(model)}")

                train_metrics, _, _             = self._eval(cal_model, Xtr_p, Ytr_np)
                val_metrics, val_preds, val_proba = self._eval(cal_model, Xval_p, Yval_np)

            except Exception as e:
                logger.error(f"Fold {fold_idx} {model_name} failed: {e}")
                self._emit("model_error", {"model": model_name, "error": str(e)})
                continue

            fold_elapsed = time.time() - fold_t0
            result.fold_results.append(FoldResult(
                fold=fold_idx,
                train_metrics=train_metrics,
                val_metrics=val_metrics,
                y_true_val=Yval_np.tolist(),
                y_pred_val=val_preds.tolist(),
                y_proba_val=val_proba.tolist(),
                loss_history=loss_hist,
                elapsed_s=fold_elapsed,
            ))
            self._emit("fold_done", {
                "model": model_name, "fold": fold_idx,
                "train_metrics": train_metrics,
                "val_metrics":   val_metrics,
                "loss_history":  loss_hist,
                "elapsed_s":     fold_elapsed,
            })

        result.cv_train_agg = aggregate_cv_metrics(
            [f.train_metrics for f in result.fold_results])
        result.cv_val_agg = aggregate_cv_metrics(
            [f.val_metrics for f in result.fold_results])

        # ── Refit on ALL training data ────────────────────────────────────────
        self._emit("final_fit_start", {"model": model_name})
        X_all = self._pack(
            self.pipeline.X_train,
            self._get_embed(self.pipeline.X_train, self.pipeline.Y_train, -1))
        Y_all = self.pipeline.Y_train.values.astype(int)

        final = model_builder_fn(model_cfg)
        try:
            if isinstance(final, TorchWrapper):
                cal_final, _ = self._train_torch(final, X_all, Y_all, X_all, Y_all)
                result.final_model = cal_final

            elif isinstance(final, XGBoostModel):
                result.final_model = self._train_xgb(final, X_all, Y_all)
                result.feature_importance = final.get_feature_importance(
                    self.pipeline.selected_features)

            elif isinstance(final, SklearnModel):
                result.final_model = self._train_sklearn(final, X_all, Y_all)
                result.feature_importance = final.get_feature_importance(
                    self.pipeline.selected_features)

        except Exception as e:
            logger.error(f"Final fit {model_name} failed: {e}")
            self._emit("model_error", {"model": model_name,
                                        "error": f"final fit: {e}"})
            result.final_model = None

        # ── Test set evaluation ───────────────────────────────────────────────
        if result.final_model is not None:
            X_test = self._pack(
                self.pipeline.X_test,
                self._get_embed(self.pipeline.X_test, self.pipeline.Y_test, -2))
            Y_test = self.pipeline.Y_test.values.astype(int)

            test_metrics, test_preds, test_proba = self._eval(
                result.final_model, X_test, Y_test)
            result.test_metrics  = test_metrics
            result.y_true_test   = Y_test.tolist()
            result.y_pred_test   = test_preds.tolist()
            result.y_proba_test  = test_proba.tolist()

        result.elapsed_total_s = time.time() - t0
        self._emit("model_done", {
            "model":        model_name,
            "test_metrics": result.test_metrics,
            "cv_val_agg":   {k: v["mean"] for k, v in result.cv_val_agg.items()},
            "elapsed_s":    result.elapsed_total_s,
        })
        return result

    def run_all(self, configs, builders) -> Dict[str, CVResult]:
        results = {}
        for name, cfg in configs.items():
            if name not in builders:
                continue
            self._emit("model_queued", {"model": name})
            try:
                results[name] = self.run_model(name, cfg, builders[name])
            except Exception as e:
                logger.error(f"Model {name} failed: {e}")
                self._emit("model_error", {"model": name, "error": str(e)})
        return results
