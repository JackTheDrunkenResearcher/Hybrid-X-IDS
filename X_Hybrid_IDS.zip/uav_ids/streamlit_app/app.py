"""
streamlit_app/app.py

Single-process Streamlit dashboard for the UAV Intrusion Detection System.

Reuses every backend module exactly as-is — preprocessing/pipeline.py,
models/embeddings.py, models/networks.py, training/rolling_cv.py,
training/optuna_engine.py, diagnostics/plots.py — with ZERO modifications.

Why Streamlit instead of FastAPI+React for a hackathon demo
-------------------------------------------------------------
One process, one command, one port. No SSE plumbing, no CORS, no risk
of the backend and frontend falling out of sync during a live demo.
Streamlit's own re-run model gives you live progress for free via
st.progress() and st.empty() placeholders updated in a training loop.

Run with:
    streamlit run streamlit_app/app.py
"""

from __future__ import annotations

import io
import sys
import time
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

# Make the project root importable regardless of where streamlit is launched from
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from preprocessing.pipeline import OnlinePreprocessingPipeline, PreprocessingConfig
from models.embeddings import WindowEmbedder, EmbeddingConfig
from models.networks import (
    build_mlp, build_cnn, build_lstm, XGBoostModel,
    MLPConfig, CNNConfig, LSTMConfig, XGBConfig,
    SklearnModel,
    build_rf, build_et, build_gb, build_hgb,
    build_ada, build_bagging, build_stacking1, build_stacking2, build_lgbm,
    RFConfig, ETConfig, GBConfig, HGBConfig,
    AdaConfig, BaggingConfig, Stacking1Config, Stacking2Config, LGBMConfig,
)
from training.rolling_cv import RollingCVTrainer, CVResult
from training.optuna_engine import OptunaConfig, run_optuna
from diagnostics import plots as P


# ─────────────────────────────────────────────────────────────────────────────
# Page config + theme
# ─────────────────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="UAV IDS — Intrusion Detection",
    page_icon="🛡",
    layout="wide",
    initial_sidebar_state="expanded",
)

MODEL_COLORS = {"mlp": "#3b82f6", "cnn": "#10b981", "lstm": "#f59e0b", "xgb": "#8b5cf6"}
METRICS = ["accuracy", "f1", "precision", "recall", "roc_auc"]


def render_plot(plot_dict: Optional[dict], height: int = 380, key: str = ""):
    """Reconstruct a go.Figure from the JSON dict our plots.py functions return."""
    if not plot_dict:
        st.info("No data yet for this plot.")
        return
    fig = go.Figure(data=plot_dict.get("data", []), layout=plot_dict.get("layout", {}))
    fig.update_layout(height=height)
    # key must be unique across the entire page — caller passes a descriptive string
    unique_key = f"plotly_{key}_{id(plot_dict)}"
    st.plotly_chart(fig, use_container_width=True, key=unique_key)


# ─────────────────────────────────────────────────────────────────────────────
# Session state
# ─────────────────────────────────────────────────────────────────────────────

def init_state():
    defaults = {
        "df":              None,
        "pipeline":        None,
        "prep_plots":      {},
        "cv_results":      {},   # {model_name: CVResult}
        "train_plots":     {},
        "hpo_result":       None,
        "hpo_plots":        {},
        "event_log":        [],
        "hpo_event_log":     [],
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_state()


def log_event(msg: str, store: str = "event_log"):
    st.session_state[store].append(f"[{time.strftime('%H:%M:%S')}] {msg}")


# ─────────────────────────────────────────────────────────────────────────────
# Sidebar — configuration
# ─────────────────────────────────────────────────────────────────────────────

st.sidebar.markdown("## 🛡 UAV IDS")
st.sidebar.caption("UAVIDS-2025 · Online Intrusion Detection")
st.sidebar.divider()

# ── Upload ──────────────────────────────────────────────────────────────────
st.sidebar.markdown("### Dataset")
uploaded = st.sidebar.file_uploader("Upload synthetic UAVIDS-2025 CSV", type=["csv"])
if uploaded is not None:
    try:
        st.session_state.df = pd.read_csv(uploaded)
        st.sidebar.success(f"✓ {st.session_state.df.shape[0]} rows, "
                           f"{st.session_state.df.shape[1]} columns")
    except Exception as e:
        st.sidebar.error(f"Could not read CSV: {e}")

st.sidebar.divider()

# ── Preprocessing config ───────────────────────────────────────────────────
st.sidebar.markdown("### Preprocessing")
window_size = st.sidebar.number_input("Window size", min_value=100, value=5000, step=500)
step_size   = st.sidebar.number_input("Step size (informational — folds use window_size)",
                                       min_value=50, value=5000, step=250,
                                       help="Folds always advance by window_size to prevent leakage. This value is stored but not used in fold arithmetic.")
n_folds     = st.sidebar.number_input("N folds",     min_value=2,   max_value=20, value=5)
gap         = st.sidebar.number_input("Gap (rows)",  min_value=0,   value=0,    step=10)
test_frac   = st.sidebar.slider("Test fraction", 0.05, 0.50, 0.20, 0.05)
rfe_thresh  = st.sidebar.number_input("RFE importance threshold",
                                       min_value=0.001, max_value=0.2,
                                       value=0.025, step=0.005, format="%.3f")

run_prep = st.sidebar.button(
    "Run Preprocessing", type="primary", use_container_width=True,
    disabled=st.session_state.df is None,
)

st.sidebar.divider()

# ── Training config ─────────────────────────────────────────────────────────
st.sidebar.markdown("### Training")
llm_provider = st.sidebar.selectbox("LLM provider", ["gpt-4o", "claude", "qwen", "llama"])
device       = st.sidebar.selectbox("Device", ["auto", "cpu", "cuda", "mps"])
ALL_MODELS = ["mlp", "cnn", "lstm", "xgb",
              "rf", "et", "gb", "hgb", "ada", "bagging",
              "stacking1", "stacking2", "lgbm"]

models_to_train = st.sidebar.multiselect(
    "Models",
    ALL_MODELS,
    default=["xgb", "rf", "lgbm"],
    format_func=lambda m: {
        "mlp":"MLP","cnn":"CNN","lstm":"LSTM","xgb":"XGBoost",
        "rf":"Random Forest","et":"Extra-Trees","gb":"Gradient Boosting",
        "hgb":"Hist Gradient Boosting","ada":"AdaBoost (DT)",
        "bagging":"Bagging (DT)","stacking1":"Stacking-1",
        "stacking2":"Stacking-2","lgbm":"LightGBM",
    }.get(m, m.upper()),
)

run_train = st.sidebar.button(
    "Start Training", type="primary", use_container_width=True,
    disabled=(st.session_state.pipeline is None or not models_to_train),
)

if st.session_state.pipeline is not None:
    art = st.session_state.pipeline.artifacts
    st.sidebar.divider()
    st.sidebar.markdown("### Pipeline status")
    c1, c2 = st.sidebar.columns(2)
    c1.metric("Train rows", art.n_train_rows)
    c2.metric("Test rows", art.n_test_rows)
    c1.metric("Features", art.n_features_final)
    c2.metric("Folds", len(st.session_state.pipeline.folds))


# ─────────────────────────────────────────────────────────────────────────────
# Device resolution
# ─────────────────────────────────────────────────────────────────────────────

def resolve_device(d: str) -> str:
    if d == "auto":
        try:
            import torch
            if torch.cuda.is_available():
                return "cuda"
            if torch.backends.mps.is_available():
                return "mps"
        except ImportError:
            pass
        return "cpu"
    return d


# ─────────────────────────────────────────────────────────────────────────────
# Preprocessing action
# ─────────────────────────────────────────────────────────────────────────────

if run_prep and st.session_state.df is not None:
    with st.spinner("Running online preprocessing…"):
        try:
            cfg = PreprocessingConfig(
                window_size=int(window_size),
                step_size=int(step_size),
                n_folds=int(n_folds),
                gap=int(gap),
                test_frac=float(test_frac),
                rfe_importance_threshold=float(rfe_thresh),
            )
            pipeline = OnlinePreprocessingPipeline()
            pipeline.fit(st.session_state.df.copy(), cfg)
            st.session_state.pipeline = pipeline

            art   = pipeline.artifacts
            plots = {}

            # ── class distribution ─────────────────────────────────────────
            plots["class_distribution"] = P.plot_class_distribution(
                art.label_counts, art.label_pct, pipeline.class_names)

            # ── feature diagnostics ────────────────────────────────────────
            if art.density_data:
                plots["density"]   = P.plot_density_grid(art.density_data, pipeline.class_names)
            if art.histogram_data:
                plots["histograms"]= P.plot_histogram_grid(art.histogram_data)
            if art.boxplot_data:
                plots["boxplots"]  = P.plot_boxplot_grid(art.boxplot_data)

            # ── IP frequency ───────────────────────────────────────────────
            if art.srcaddr_freq_dist:
                plots["ip_freq"] = P.plot_ip_freq_distribution(
                    art.srcaddr_freq_dist, art.dstaddr_freq_dist)

            # ── correlations BEFORE — all 3 methods ───────────────────────
            if art.pearson_before is not None:
                plots["pearson_before"]  = P.plot_correlation_heatmap(
                    art.pearson_before,  "Pearson Correlation — Before Feature Selection")
            if art.spearman_before is not None:
                plots["spearman_before"] = P.plot_correlation_heatmap(
                    art.spearman_before, "Spearman Correlation — Before Feature Selection")
            if art.kendall_before is not None:
                plots["kendall_before"]  = P.plot_correlation_heatmap(
                    art.kendall_before,  "Kendall Correlation — Before Feature Selection")

            # ── RFE importance bar plot ────────────────────────────────────
            if art.rfe_importances:
                plots["rfe_importance"] = P.plot_rfe_importance(
                    art.rfe_importances, float(rfe_thresh))

            # ── rolling window fold layout ─────────────────────────────────
            if art.folds:
                plots["rolling_folds"] = P.plot_rolling_folds(
                    art.folds, art.n_train_rows, art.n_test_rows)

            # ── correlations AFTER — all 3 methods ────────────────────────
            if art.pearson_after is not None:
                plots["pearson_after"]  = P.plot_correlation_heatmap(
                    art.pearson_after,  "Pearson Correlation — After Feature Selection")
            if art.spearman_after is not None:
                plots["spearman_after"] = P.plot_correlation_heatmap(
                    art.spearman_after, "Spearman Correlation — After Feature Selection")
            if art.kendall_after is not None:
                plots["kendall_after"]  = P.plot_correlation_heatmap(
                    art.kendall_after,  "Kendall Correlation — After Feature Selection")

            st.session_state.prep_plots = plots
            st.session_state.cv_results = {}
            st.session_state.train_plots = {}
            st.sidebar.success(
                f"Preprocessing complete. "
                f"{art.n_features_final} features selected, "
                f"{art.n_duplicates} duplicates removed."
            )
        except Exception as e:
            st.sidebar.error(f"Preprocessing failed: {e}")
            st.sidebar.code(traceback.format_exc())


# ─────────────────────────────────────────────────────────────────────────────
# Training action
# ─────────────────────────────────────────────────────────────────────────────

def build_model_configs_and_builders(n_feat, emb_dim, n_cls, dev):
    """
    Build config objects using the hyperparameter values stored in
    st.session_state (set by the hyperparameter UI below).
    """
    configs, builders = {}, {}
    hp = st.session_state.get("hp", {})

    def g(model, key, default):
        val = hp.get(f"{model}_{key}", default)
        # Convert string "None" from selectbox to Python None
        if val == "None":
            return None
        return val

    if "mlp" in models_to_train:
        configs["mlp"] = MLPConfig(
            n_layers      = g("mlp","n_layers",3),
            hidden_dim    = g("mlp","hidden_dim",128),
            dropout       = g("mlp","dropout",0.2),
            activation    = g("mlp","activation","relu"),
            use_batchnorm = g("mlp","use_batchnorm",True),
            lr            = g("mlp","lr",1e-3),
            batch_size    = g("mlp","batch_size",64),
            epochs        = g("mlp","epochs",30),
            proj_dim      = g("mlp","proj_dim",64),
            calibration   = g("mlp","calibration","isotonic"),
        )
        builders["mlp"] = lambda cfg, n=n_feat,e=emb_dim,c=n_cls,d=dev: build_mlp(n,e,c,cfg,d)

    if "cnn" in models_to_train:
        configs["cnn"] = CNNConfig(
            n_blocks      = g("cnn","n_blocks",3),
            out_channels  = g("cnn","out_channels",64),
            kernel_size   = g("cnn","kernel_size",3),
            dilation_base = g("cnn","dilation_base",2),
            use_residual  = g("cnn","use_residual",True),
            dropout       = g("cnn","dropout",0.2),
            lr            = g("cnn","lr",1e-3),
            batch_size    = g("cnn","batch_size",64),
            epochs        = g("cnn","epochs",30),
            proj_dim      = g("cnn","proj_dim",64),
            seq_len       = g("cnn","seq_len",16),
            calibration   = g("cnn","calibration","isotonic"),
        )
        builders["cnn"] = lambda cfg, n=n_feat,e=emb_dim,c=n_cls,d=dev: build_cnn(n,e,c,cfg,d)

    if "lstm" in models_to_train:
        configs["lstm"] = LSTMConfig(
            n_layers      = g("lstm","n_layers",2),
            hidden_size   = g("lstm","hidden_size",128),
            dropout       = g("lstm","dropout",0.2),
            bidirectional = g("lstm","bidirectional",True),
            lr            = g("lstm","lr",1e-3),
            batch_size    = g("lstm","batch_size",64),
            epochs        = g("lstm","epochs",30),
            proj_dim      = g("lstm","proj_dim",64),
            seq_len       = g("lstm","seq_len",16),
            calibration   = g("lstm","calibration","isotonic"),
        )
        builders["lstm"] = lambda cfg, n=n_feat,e=emb_dim,c=n_cls,d=dev: build_lstm(n,e,c,cfg,d)

    if "xgb" in models_to_train:
        configs["xgb"] = XGBConfig(
            n_estimators    = g("xgb","n_estimators",200),
            max_depth       = g("xgb","max_depth",6),
            learning_rate   = g("xgb","learning_rate",0.05),
            subsample       = g("xgb","subsample",0.8),
            colsample       = g("xgb","colsample",0.8),
            reg_alpha       = g("xgb","reg_alpha",0.1),
            reg_lambda      = g("xgb","reg_lambda",1.0),
            min_child_weight= g("xgb","min_child_weight",3),
            calibration     = g("xgb","calibration","isotonic"),
        )
        builders["xgb"] = lambda cfg, c=n_cls: XGBoostModel(c, cfg)

    if "rf" in models_to_train:
        configs["rf"] = RFConfig(
            n_estimators      = g("rf","n_estimators",200),
            max_depth         = g("rf","max_depth",8),
            min_samples_leaf  = g("rf","min_samples_leaf",4),
            min_samples_split = g("rf","min_samples_split",8),
            max_features      = g("rf","max_features","sqrt"),
            class_weight      = g("rf","class_weight","balanced_subsample"),
            calibration       = g("rf","calibration","isotonic"),
        )
        builders["rf"] = lambda cfg, c=n_cls: build_rf(c, cfg)

    if "et" in models_to_train:
        configs["et"] = ETConfig(
            n_estimators      = g("et","n_estimators",200),
            max_depth         = g("et","max_depth",8),
            min_samples_leaf  = g("et","min_samples_leaf",4),
            min_samples_split = g("et","min_samples_split",8),
            max_features      = g("et","max_features","sqrt"),
            class_weight      = g("et","class_weight","balanced_subsample"),
            calibration       = g("et","calibration","isotonic"),
        )
        builders["et"] = lambda cfg, c=n_cls: build_et(c, cfg)

    if "gb" in models_to_train:
        configs["gb"] = GBConfig(
            n_estimators    = g("gb","n_estimators",150),
            max_depth       = g("gb","max_depth",5),
            learning_rate   = g("gb","learning_rate",0.05),
            subsample       = g("gb","subsample",0.8),
            min_samples_leaf= g("gb","min_samples_leaf",3),
            calibration     = g("gb","calibration","isotonic"),
        )
        builders["gb"] = lambda cfg, c=n_cls: build_gb(c, cfg)

    if "hgb" in models_to_train:
        configs["hgb"] = HGBConfig(
            max_iter          = g("hgb","max_iter",150),
            max_depth         = g("hgb","max_depth",6),
            learning_rate     = g("hgb","learning_rate",0.05),
            min_samples_leaf  = g("hgb","min_samples_leaf",20),
            l2_regularization = g("hgb","l2_regularization",1e-4),
            calibration       = g("hgb","calibration","isotonic"),
        )
        builders["hgb"] = lambda cfg, c=n_cls: build_hgb(c, cfg)

    if "ada" in models_to_train:
        configs["ada"] = AdaConfig(
            n_estimators  = g("ada","n_estimators",100),
            learning_rate = g("ada","learning_rate",0.5),
            dt_max_depth  = g("ada","dt_max_depth",3),
            calibration   = g("ada","calibration","isotonic"),
        )
        builders["ada"] = lambda cfg, c=n_cls: build_ada(c, cfg)

    if "bagging" in models_to_train:
        configs["bagging"] = BaggingConfig(
            n_estimators  = g("bagging","n_estimators",20),
            max_samples   = g("bagging","max_samples",0.8),
            max_features  = g("bagging","max_features",0.8),
            dt_max_depth  = g("bagging","dt_max_depth",8),
            calibration   = g("bagging","calibration","isotonic"),
        )
        builders["bagging"] = lambda cfg, c=n_cls: build_bagging(c, cfg)

    if "stacking1" in models_to_train:
        configs["stacking1"] = Stacking1Config(
            dt_max_depth  = g("stacking1","dt_max_depth",8),
            hgb_max_iter  = g("stacking1","hgb_max_iter",100),
            ridge_alpha   = g("stacking1","ridge_alpha",1.0),
            calibration   = g("stacking1","calibration","isotonic"),
        )
        builders["stacking1"] = lambda cfg, c=n_cls: build_stacking1(c, cfg)

    if "stacking2" in models_to_train:
        configs["stacking2"] = Stacking2Config(
            dt_max_depth  = g("stacking2","dt_max_depth",8),
            lr_C          = g("stacking2","lr_C",1.0),
            lr_max_iter   = g("stacking2","lr_max_iter",1000),
            ridge_alpha   = g("stacking2","ridge_alpha",1.0),
            calibration   = g("stacking2","calibration","isotonic"),
        )
        builders["stacking2"] = lambda cfg, c=n_cls: build_stacking2(c, cfg)

    if "lgbm" in models_to_train:
        configs["lgbm"] = LGBMConfig(
            n_estimators      = g("lgbm","n_estimators",200),
            max_depth         = g("lgbm","max_depth",7),
            learning_rate     = g("lgbm","learning_rate",0.05),
            num_leaves        = g("lgbm","num_leaves",63),
            subsample         = g("lgbm","subsample",0.8),
            colsample_bytree  = g("lgbm","colsample_bytree",0.8),
            reg_alpha         = g("lgbm","reg_alpha",0.1),
            reg_lambda        = g("lgbm","reg_lambda",1.0),
            min_child_samples = g("lgbm","min_child_samples",10),
            calibration       = g("lgbm","calibration","isotonic"),
        )
        builders["lgbm"] = lambda cfg, c=n_cls: build_lgbm(c, cfg)

    return configs, builders


def build_all_train_plots(results: Dict[str, CVResult], class_names: List[str]) -> dict:
    plots = {}
    plots["table_cv"]   = P.plot_metrics_table(results, "cv")
    plots["table_test"] = P.plot_metrics_table(results, "test")

    for model_name, res in results.items():
        pfx = model_name
        fr_list = [
            {"fold": fr.fold, "train_metrics": fr.train_metrics,
             "val_metrics": fr.val_metrics, "loss_history": fr.loss_history}
            for fr in res.fold_results
        ]
        # All 5 CV metrics per fold
        for metric in ["f1", "roc_auc", "accuracy", "precision", "recall"]:
            plots[f"{pfx}_cv_{metric}"] = P.plot_cv_metrics_per_fold(
                fr_list, model_name, metric)

        if any(fr.loss_history for fr in res.fold_results):
            plots[f"{pfx}_loss"] = P.plot_loss_curves(fr_list, model_name)

        # Per-model confusion matrix, ROC, PR, calibration
        plots[f"{pfx}_cm_test"] = P.plot_confusion_matrix(
            res.y_true_test, res.y_pred_test, class_names,
            f"{model_name.upper()} — Confusion Matrix (Test)")
        plots[f"{pfx}_roc_test"] = P.plot_roc_curves(
            res.y_true_test, res.y_proba_test, class_names,
            f"{model_name.upper()} — ROC Curves (Test)")
        plots[f"{pfx}_pr_test"] = P.plot_pr_curves(
            res.y_true_test, res.y_proba_test, class_names,
            f"{model_name.upper()} — PR Curves (Test)")
        plots[f"{pfx}_cal_test"] = P.plot_calibration_curve(
            res.y_true_test, res.y_proba_test, class_names,
            title=f"{model_name.upper()} — Calibration (Test)")

        # Feature importance for any model that exposes it
        if res.feature_importance:
            plots[f"{pfx}_importance"] = P.plot_xgb_feature_importance(
                res.feature_importance)

    if len(results) > 1:
        plots["all_roc"] = P.plot_multi_model_roc(results, "test")
    return plots


if run_train and st.session_state.pipeline is not None:
    pipeline = st.session_state.pipeline
    dev = resolve_device(device)

    progress_bar = st.sidebar.progress(0, text="Starting training…")
    status_box   = st.sidebar.empty()
    log_box      = st.empty()
    st.session_state.event_log = []

    n_models_total = len(models_to_train)
    fold_total     = n_models_total * len(pipeline.folds)
    fold_counter   = {"n": 0}

    def streamlit_event_cb(event_type: str, data: dict):
        if event_type == "fold_done":
            fold_counter["n"] += 1
            pct = min(int(100 * fold_counter["n"] / max(fold_total, 1)), 99)
            progress_bar.progress(pct, text=f"Training… fold {fold_counter['n']}/{fold_total}")
            log_event(f"fold_done — {data.get('model')} fold {data.get('fold')} "
                      f"val_f1={data.get('val_metrics',{}).get('f1',0):.3f}")
        elif event_type == "training_start":
            log_event(f"training_start — {data.get('model')} ({data.get('n_folds')} folds)")
        elif event_type == "model_done":
            log_event(f"model_done — {data.get('model')} "
                      f"test_f1={data.get('test_metrics',{}).get('f1',0):.3f}")
        elif event_type == "status":
            log_event(data.get("message", ""))
        elif event_type == "model_error":
            log_event(f"ERROR — {data.get('model')}: {data.get('error')}")
        # Refresh the visible log every event (cheap, list is short)
        log_box.code("\n".join(st.session_state.event_log[-25:]), language=None)

    try:
        embed_cfg = EmbeddingConfig(provider=llm_provider, cache_dir="./embed_cache")
        embedder  = WindowEmbedder(embed_cfg)
        status_box.info(f"LLM embedder ready: {llm_provider}")

        configs, builders = build_model_configs_and_builders(
            pipeline.n_features, embedder.embed_dim, pipeline.n_classes, dev
        )

        trainer = RollingCVTrainer(
            pipeline=pipeline, embedder=embedder,
            event_cb=streamlit_event_cb, device=dev, calibration="isotonic",
        )

        results = trainer.run_all(configs, builders)
        st.session_state.cv_results = results

        progress_bar.progress(100, text="Done.")
        status_box.success(f"Training complete — {len(results)} model(s).")

        st.session_state.train_plots = build_all_train_plots(results, pipeline.class_names)

    except Exception as e:
        status_box.error(f"Training failed: {e}")
        st.code(traceback.format_exc())


# ─────────────────────────────────────────────────────────────────────────────
# Main area — tabs
# ─────────────────────────────────────────────────────────────────────────────

tab_data, tab_prep, tab_train, tab_hp, tab_hpo, tab_results = st.tabs(
    ["📁 Data", "🔧 Preprocessing", "🎯 Training", "⚙ Hyperparameters", "🧪 HPO", "📊 Results"]
)

# ── Hyperparameters tab ──────────────────────────────────────────────────
with tab_hp:
    st.markdown("### Model Hyperparameters")
    st.caption("Set hyperparameter values for each model. Changes take effect on the next training run.")

    # Store all values in session state under st.session_state.hp
    if "hp" not in st.session_state:
        st.session_state.hp = {}

    def hp_set(model, key, val):
        st.session_state.hp[f"{model}_{key}"] = val

    def hp_get(model, key, default):
        return st.session_state.hp.get(f"{model}_{key}", default)


    # ── MLP ──────────────────────────────────────────────────────────────────
    with st.expander("MLP — Residual Feedforward Network", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("mlp","n_layers",    c1.slider("N layers",      1, 6,   hp_get("mlp","n_layers",3),   key="hp_mlp_nl"))
        hp_set("mlp","hidden_dim",  c2.selectbox("Hidden dim",  [64,128,256,512], index=[64,128,256,512].index(hp_get("mlp","hidden_dim",128)), key="hp_mlp_hd"))
        hp_set("mlp","dropout",     c3.slider("Dropout",        0.0, 0.6, hp_get("mlp","dropout",0.2), step=0.05, key="hp_mlp_do"))
        hp_set("mlp","activation",  c1.selectbox("Activation",  ["relu","gelu","silu"], index=["relu","gelu","silu"].index(hp_get("mlp","activation","relu")), key="hp_mlp_act"))
        hp_set("mlp","use_batchnorm",c2.checkbox("BatchNorm",   hp_get("mlp","use_batchnorm",True), key="hp_mlp_bn"))
        hp_set("mlp","lr",          c3.number_input("Learning rate", 1e-5, 0.1, hp_get("mlp","lr",1e-3), format="%.5f", key="hp_mlp_lr"))
        hp_set("mlp","batch_size",  c1.selectbox("Batch size",  [32,64,128,256], index=[32,64,128,256].index(hp_get("mlp","batch_size",64)), key="hp_mlp_bs"))
        hp_set("mlp","epochs",      c2.slider("Epochs",         5, 100, hp_get("mlp","epochs",30), key="hp_mlp_ep"))
        hp_set("mlp","proj_dim",    c3.selectbox("Proj dim",    [32,64,128,256], index=[32,64,128,256].index(hp_get("mlp","proj_dim",64)), key="hp_mlp_pd"))

    # ── CNN ──────────────────────────────────────────────────────────────────
    with st.expander("CNN — Dilated Causal Convolutions", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("cnn","n_blocks",    c1.slider("N blocks",       1, 6,   hp_get("cnn","n_blocks",3),   key="hp_cnn_nb"))
        hp_set("cnn","out_channels",c2.selectbox("Out channels",[32,64,128,256], index=[32,64,128,256].index(hp_get("cnn","out_channels",64)), key="hp_cnn_oc"))
        hp_set("cnn","kernel_size", c3.selectbox("Kernel size", [3,5,7,9], index=[3,5,7,9].index(hp_get("cnn","kernel_size",3)), key="hp_cnn_ks"))
        hp_set("cnn","dilation_base",c1.selectbox("Dilation base",[1,2,4,8], index=[1,2,4,8].index(hp_get("cnn","dilation_base",2)), key="hp_cnn_db"))
        hp_set("cnn","use_residual",c2.checkbox("Residual",     hp_get("cnn","use_residual",True), key="hp_cnn_res"))
        hp_set("cnn","dropout",     c3.slider("Dropout",        0.0, 0.6, hp_get("cnn","dropout",0.2), step=0.05, key="hp_cnn_do"))
        hp_set("cnn","lr",          c1.number_input("Learning rate", 1e-5, 0.1, hp_get("cnn","lr",1e-3), format="%.5f", key="hp_cnn_lr"))
        hp_set("cnn","batch_size",  c2.selectbox("Batch size",  [32,64,128,256], index=[32,64,128,256].index(hp_get("cnn","batch_size",64)), key="hp_cnn_bs"))
        hp_set("cnn","epochs",      c3.slider("Epochs",         5, 100, hp_get("cnn","epochs",30), key="hp_cnn_ep"))
        hp_set("cnn","seq_len",     c1.selectbox("Seq len",     [8,16,32,64], index=[8,16,32,64].index(hp_get("cnn","seq_len",16)), key="hp_cnn_sl"))
        hp_set("cnn","proj_dim",    c2.selectbox("Proj dim",    [32,64,128], index=[32,64,128].index(hp_get("cnn","proj_dim",64)), key="hp_cnn_pd"))

    # ── LSTM ─────────────────────────────────────────────────────────────────
    with st.expander("LSTM — Bidirectional with LayerNorm", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("lstm","n_layers",   c1.slider("N layers",       1, 5,   hp_get("lstm","n_layers",2),  key="hp_lstm_nl"))
        hp_set("lstm","hidden_size",c2.selectbox("Hidden size",  [64,128,256,512], index=[64,128,256,512].index(hp_get("lstm","hidden_size",128)), key="hp_lstm_hs"))
        hp_set("lstm","dropout",    c3.slider("Dropout",         0.0, 0.6, hp_get("lstm","dropout",0.2), step=0.05, key="hp_lstm_do"))
        hp_set("lstm","bidirectional",c1.checkbox("Bidirectional",hp_get("lstm","bidirectional",True), key="hp_lstm_bi"))
        hp_set("lstm","lr",         c2.number_input("Learning rate",1e-5,0.1,hp_get("lstm","lr",1e-3),format="%.5f",key="hp_lstm_lr"))
        hp_set("lstm","batch_size", c3.selectbox("Batch size",   [32,64,128,256], index=[32,64,128,256].index(hp_get("lstm","batch_size",64)), key="hp_lstm_bs"))
        hp_set("lstm","epochs",     c1.slider("Epochs",          5, 100, hp_get("lstm","epochs",30), key="hp_lstm_ep"))
        hp_set("lstm","seq_len",    c2.selectbox("Seq len",      [8,16,32,64], index=[8,16,32,64].index(hp_get("lstm","seq_len",16)), key="hp_lstm_sl"))
        hp_set("lstm","proj_dim",   c3.selectbox("Proj dim",     [32,64,128], index=[32,64,128].index(hp_get("lstm","proj_dim",64)), key="hp_lstm_pd"))

    # ── XGBoost ──────────────────────────────────────────────────────────────
    with st.expander("XGBoost", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("xgb","n_estimators",    c1.slider("N estimators",    1, 1000, hp_get("xgb","n_estimators",200),    step=10,  key="hp_xgb_ne"))
        hp_set("xgb","max_depth",       c2.slider("Max depth",       1,  30,  hp_get("xgb","max_depth",6),                  key="hp_xgb_md"))
        hp_set("xgb","learning_rate",   c3.number_input("Learning rate",0.001,0.5,hp_get("xgb","learning_rate",0.05),format="%.4f",key="hp_xgb_lr"))
        hp_set("xgb","subsample",       c1.slider("Subsample",       0.4, 1.0, hp_get("xgb","subsample",0.8),     step=0.05,key="hp_xgb_ss"))
        hp_set("xgb","colsample",       c2.slider("Colsample bytree",0.4, 1.0, hp_get("xgb","colsample",0.8),     step=0.05,key="hp_xgb_cs"))
        hp_set("xgb","reg_alpha",       c3.number_input("reg_alpha", 0.0, 20.0,hp_get("xgb","reg_alpha",0.1),    format="%.3f",key="hp_xgb_ra"))
        hp_set("xgb","reg_lambda",      c1.number_input("reg_lambda",0.0, 20.0,hp_get("xgb","reg_lambda",1.0),   format="%.3f",key="hp_xgb_rl"))
        hp_set("xgb","min_child_weight",c2.slider("Min child weight",1,  20,   hp_get("xgb","min_child_weight",3),          key="hp_xgb_cw"))

    # ── Random Forest ─────────────────────────────────────────────────────────
    with st.expander("Random Forest", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("rf","n_estimators",     c1.slider("N estimators",    1, 1000, hp_get("rf","n_estimators",200),     step=10, key="hp_rf_ne"))
        hp_set("rf","max_depth",        c2.slider("Max depth",       1,  30,  hp_get("rf","max_depth",8),                  key="hp_rf_md"))
        hp_set("rf","min_samples_leaf", c3.slider("Min samples leaf",1,  30,  hp_get("rf","min_samples_leaf",4),           key="hp_rf_msl"))
        hp_set("rf","min_samples_split",c1.slider("Min samples split",2, 30,  hp_get("rf","min_samples_split",8),          key="hp_rf_mss"))
        hp_set("rf","max_features",     c2.selectbox("Max features", ["sqrt","log2","None"], index=["sqrt","log2","None"].index(hp_get("rf","max_features","sqrt")), key="hp_rf_mf"))
        hp_set("rf","class_weight",     c3.selectbox("Class weight", ["balanced","balanced_subsample"], index=["balanced","balanced_subsample"].index(hp_get("rf","class_weight","balanced_subsample")), key="hp_rf_cw"))

    # ── Extra-Trees ───────────────────────────────────────────────────────────
    with st.expander("Extra-Trees", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("et","n_estimators",     c1.slider("N estimators",    1, 1000, hp_get("et","n_estimators",200),     step=10, key="hp_et_ne"))
        hp_set("et","max_depth",        c2.slider("Max depth",       1,  30,  hp_get("et","max_depth",8),                  key="hp_et_md"))
        hp_set("et","min_samples_leaf", c3.slider("Min samples leaf",1,  30,  hp_get("et","min_samples_leaf",4),           key="hp_et_msl"))
        hp_set("et","min_samples_split",c1.slider("Min samples split",2, 30,  hp_get("et","min_samples_split",8),          key="hp_et_mss"))
        hp_set("et","max_features",     c2.selectbox("Max features", ["sqrt","log2","None"], index=["sqrt","log2","None"].index(hp_get("et","max_features","sqrt")), key="hp_et_mf"))
        hp_set("et","class_weight",     c3.selectbox("Class weight", ["balanced","balanced_subsample"], index=["balanced","balanced_subsample"].index(hp_get("et","class_weight","balanced_subsample")), key="hp_et_cw"))

    # ── Gradient Boosting ─────────────────────────────────────────────────────
    with st.expander("Gradient Boosting", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("gb","n_estimators",    c1.slider("N estimators",    50, 500, hp_get("gb","n_estimators",150),     step=10, key="hp_gb_ne"))
        hp_set("gb","max_depth",       c2.slider("Max depth",        1,  30,  hp_get("gb","max_depth",5),                  key="hp_gb_md"))
        hp_set("gb","learning_rate",   c3.number_input("Learning rate",0.001,0.5,hp_get("gb","learning_rate",0.05),format="%.4f",key="hp_gb_lr"))
        hp_set("gb","subsample",       c1.slider("Subsample",        0.4, 1.0, hp_get("gb","subsample",0.8),     step=0.05,key="hp_gb_ss"))
        hp_set("gb","min_samples_leaf",c2.slider("Min samples leaf", 1,  20,  hp_get("gb","min_samples_leaf",3),           key="hp_gb_msl"))

    # ── Hist Gradient Boosting ────────────────────────────────────────────────
    with st.expander("Histogram-Based Gradient Boosting", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("hgb","max_iter",         c1.slider("Max iter",        50, 500, hp_get("hgb","max_iter",150),       step=10, key="hp_hgb_mi"))
        hp_set("hgb","max_depth",        c2.slider("Max depth",        1,  30,  hp_get("hgb","max_depth",6),                key="hp_hgb_md"))
        hp_set("hgb","learning_rate",    c3.number_input("Learning rate",0.001,0.5,hp_get("hgb","learning_rate",0.05),format="%.4f",key="hp_hgb_lr"))
        hp_set("hgb","min_samples_leaf", c1.slider("Min samples leaf", 5,  100, hp_get("hgb","min_samples_leaf",20),        key="hp_hgb_msl"))
        hp_set("hgb","l2_regularization",c2.number_input("L2 reg",    0.0, 10.0,hp_get("hgb","l2_regularization",1e-4),format="%.6f",key="hp_hgb_l2"))

    # ── AdaBoost ──────────────────────────────────────────────────────────────
    with st.expander("AdaBoost (Decision Tree base)", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("ada","n_estimators",  c1.slider("N estimators",   1, 1000, hp_get("ada","n_estimators",100), step=10, key="hp_ada_ne"))
        hp_set("ada","learning_rate", c2.number_input("Learning rate",0.01,3.0,hp_get("ada","learning_rate",0.5),format="%.3f",key="hp_ada_lr"))
        hp_set("ada","dt_max_depth",  c3.slider("DT max depth",   1,  30,  hp_get("ada","dt_max_depth",3),            key="hp_ada_md"))

    # ── Bagging ───────────────────────────────────────────────────────────────
    with st.expander("Bagging (Decision Tree base)", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("bagging","n_estimators", c1.slider("N estimators",  1, 500, hp_get("bagging","n_estimators",20),  step=5, key="hp_bag_ne"))
        hp_set("bagging","max_samples",  c2.slider("Max samples",   0.3, 1.0, hp_get("bagging","max_samples",0.8), step=0.05, key="hp_bag_ms"))
        hp_set("bagging","max_features", c3.slider("Max features",  0.3, 1.0, hp_get("bagging","max_features",0.8),step=0.05, key="hp_bag_mf"))
        hp_set("bagging","dt_max_depth", c1.slider("DT max depth",  1,  30,  hp_get("bagging","dt_max_depth",8),           key="hp_bag_md"))

    # ── Stacking-1 ────────────────────────────────────────────────────────────
    with st.expander("Stacking-1 (DT + HGB + GNB → Ridge)", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("stacking1","dt_max_depth", c1.slider("DT max depth",  1,  30,  hp_get("stacking1","dt_max_depth",8),         key="hp_s1_md"))
        hp_set("stacking1","hgb_max_iter", c2.slider("HGB max iter",  50, 400, hp_get("stacking1","hgb_max_iter",100),step=10,key="hp_s1_hmi"))
        hp_set("stacking1","ridge_alpha",  c3.number_input("Ridge alpha",0.001,200.0,hp_get("stacking1","ridge_alpha",1.0),format="%.4f",key="hp_s1_ra"))

    # ── Stacking-2 ────────────────────────────────────────────────────────────
    with st.expander("Stacking-2 (DT + LR + GNB → Ridge)", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("stacking2","dt_max_depth", c1.slider("DT max depth",  1,  30,   hp_get("stacking2","dt_max_depth",8),          key="hp_s2_md"))
        hp_set("stacking2","lr_C",         c2.number_input("LR C",    0.001,200.0,hp_get("stacking2","lr_C",1.0),format="%.4f",key="hp_s2_c"))
        hp_set("stacking2","lr_max_iter",  c3.slider("LR max iter",   100, 3000,hp_get("stacking2","lr_max_iter",1000),step=100,key="hp_s2_mi"))
        hp_set("stacking2","ridge_alpha",  c1.number_input("Ridge alpha",0.001,200.0,hp_get("stacking2","ridge_alpha",1.0),format="%.4f",key="hp_s2_ra"))

    # ── LightGBM ──────────────────────────────────────────────────────────────
    with st.expander("LightGBM", expanded=False):
        c1, c2, c3 = st.columns(3)
        hp_set("lgbm","n_estimators",     c1.slider("N estimators",     1, 1000, hp_get("lgbm","n_estimators",200),    step=10, key="hp_lgbm_ne"))
        hp_set("lgbm","max_depth",        c2.slider("Max depth",        1,  30,  hp_get("lgbm","max_depth",7),                  key="hp_lgbm_md"))
        hp_set("lgbm","learning_rate",    c3.number_input("Learning rate",0.001,0.5,hp_get("lgbm","learning_rate",0.05),format="%.4f",key="hp_lgbm_lr"))
        hp_set("lgbm","num_leaves",       c1.slider("Num leaves",       10, 300, hp_get("lgbm","num_leaves",63),                key="hp_lgbm_nl"))
        hp_set("lgbm","subsample",        c2.slider("Subsample",        0.4, 1.0, hp_get("lgbm","subsample",0.8),    step=0.05, key="hp_lgbm_ss"))
        hp_set("lgbm","colsample_bytree", c3.slider("Colsample bytree", 0.4, 1.0, hp_get("lgbm","colsample_bytree",0.8),step=0.05,key="hp_lgbm_cs"))
        hp_set("lgbm","reg_alpha",        c1.number_input("reg_alpha",  0.0, 20.0,hp_get("lgbm","reg_alpha",0.1),   format="%.4f",key="hp_lgbm_ra"))
        hp_set("lgbm","reg_lambda",       c2.number_input("reg_lambda", 0.0, 20.0,hp_get("lgbm","reg_lambda",1.0),  format="%.4f",key="hp_lgbm_rl"))
        hp_set("lgbm","min_child_samples",c3.slider("Min child samples",5, 200,  hp_get("lgbm","min_child_samples",10),          key="hp_lgbm_mcs"))

    st.info("After adjusting hyperparameters, click **Start Training** in the sidebar to run with these settings. Or run **HPO** to let Optuna find the best values automatically.")

# ── Data tab ──────────────────────────────────────────────────────────────
with tab_data:
    if st.session_state.df is not None:
        df = st.session_state.df
        c1, c2, c3 = st.columns(3)
        c1.metric("Rows", df.shape[0])
        c2.metric("Columns", df.shape[1])
        c3.metric("Missing values", int(df.isna().sum().sum()))

        st.markdown("**Columns**")
        st.write(", ".join(f"`{c}`" for c in df.columns))

        st.markdown("**Preview**")
        st.dataframe(df.head(20), use_container_width=True)
    else:
        st.info("Upload your synthetic UAVIDS-2025 CSV in the sidebar to get started.")

# ── Preprocessing tab ────────────────────────────────────────────────────
with tab_prep:
    if st.session_state.pipeline is not None:
        pipeline = st.session_state.pipeline
        art = pipeline.artifacts

        # ── Summary metrics ────────────────────────────────────────────────
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Train rows",       art.n_train_rows)
        c2.metric("Test rows",        art.n_test_rows)
        c3.metric("Features selected",art.n_features_final)
        c4.metric("CV folds",         len(pipeline.folds))

        c5, c6, c7, c8 = st.columns(4)
        c5.metric("Duplicates removed", art.n_duplicates)
        c6.metric("Missing values",     sum(art.missing_values.values()) if art.missing_values else 0)
        c7.metric("SrcAddr freq nunique", art.srcaddr_nunique_freq)
        c8.metric("DstAddr freq nunique", art.dstaddr_nunique_freq)

        if art.missing_values:
            with st.expander("Missing values per column"):
                st.json(art.missing_values)

        if art.selected_features:
            with st.expander(f"Selected features ({art.n_features_final})"):
                st.write(", ".join(f"`{f}`" for f in art.selected_features))

        plots = st.session_state.prep_plots

        # ── All preprocessing plots in order ───────────────────────────────
        plot_order = [
            ("class_distribution", "Class Distribution",                        320),
            ("density",            "Feature Density by Class",                  520),
            ("histograms",         "Histograms (multi-bin overlay)",             520),
            ("boxplots",           "Boxplots — Outlier Detection",              520),
            ("ip_freq",            "IP Address Frequency Distribution",          360),
            ("pearson_before",     "Pearson Correlation — Before Feature Selection", 460),
            ("spearman_before",    "Spearman Correlation — Before Feature Selection",460),
            ("kendall_before",     "Kendall Correlation — Before Feature Selection",  460),
            ("rfe_importance",     "RFE Feature Importance",                    460),
            ("rolling_folds",      "Rolling Window CV — Fold Layout",           360),
            ("pearson_after",      "Pearson Correlation — After Feature Selection",  420),
            ("spearman_after",     "Spearman Correlation — After Feature Selection", 420),
            ("kendall_after",      "Kendall Correlation — After Feature Selection",  420),
        ]
        for key, title, height in plot_order:
            if key in plots:
                st.markdown(f"#### {title}")
                render_plot(plots[key], height, key=f"prep_{key}")
    else:
        st.info("Run preprocessing from the sidebar first.")

# ── Training tab ──────────────────────────────────────────────────────────
with tab_train:
    if st.session_state.cv_results:
        results  = st.session_state.cv_results
        tplots   = st.session_state.train_plots
        selected = st.selectbox("Model", list(results.keys()),
                                 format_func=lambda m: m.upper())

        # ── Per-fold metrics TABLE (train + val) ──────────────────────────
        res = results[selected]
        if res.fold_results:
            st.markdown(f"#### {selected.upper()} — Per-Fold Metrics Table")
            METRICS_LIST = ["accuracy", "f1", "precision", "recall", "roc_auc"]

            table_rows = []
            for fr in res.fold_results:
                row = {"Fold": fr.fold}
                for m in METRICS_LIST:
                    tv = fr.train_metrics.get(m, float("nan"))
                    vv = fr.val_metrics.get(m, float("nan"))
                    row[f"Train {m.upper()}"] = f"{tv:.4f}" if not (isinstance(tv, float) and np.isnan(tv)) else "N/A"
                    row[f"Val {m.upper()}"]   = f"{vv:.4f}" if not (isinstance(vv, float) and np.isnan(vv)) else "N/A"
                table_rows.append(row)

            fold_df = pd.DataFrame(table_rows)
            st.dataframe(fold_df, use_container_width=True, hide_index=True)

        # ── Per-fold metric PLOTS (all 5 metrics) ────────────────────────
        cv_metric_order = [
            ("cv_f1",        "CV Weighted F1 per Fold",        380),
            ("cv_roc_auc",   "CV Weighted ROC-AUC per Fold",   380),
            ("cv_accuracy",  "CV Accuracy per Fold",            380),
            ("cv_precision", "CV Weighted Precision per Fold",  380),
            ("cv_recall",    "CV Weighted Recall per Fold",     380),
            ("loss",         "Training Loss per Fold",          320),
        ]
        for key, title, height in cv_metric_order:
            full_key = f"{selected}_{key}"
            if full_key in tplots:
                st.markdown(f"#### {title}")
                render_plot(tplots[full_key], height,
                            key=f"train_{selected}_{key}")

        # ── Test set diagnostic plots ────────────────────────────────────
        for key, title, height in [
            ("cm_test",  "Confusion Matrix (Test)",          420),
            ("roc_test", "ROC Curves (Test)",                460),
            ("pr_test",  "Precision-Recall Curves (Test)",   420),
            ("cal_test", "Calibration Curve (Test)",         420),
            ("importance","Feature Importance",              460),
        ]:
            full_key = f"{selected}_{key}"
            if full_key in tplots:
                st.markdown(f"#### {title}")
                render_plot(tplots[full_key], height,
                            key=f"train_{selected}_{key}")

        if "all_roc" in tplots:
            st.markdown("#### All Models — ROC (Macro Average)")
            render_plot(tplots["all_roc"], 440, key="train_all_roc")
    else:
        st.info("Start training from the sidebar to see live results here.")
        if st.session_state.event_log:
            st.code("\n".join(st.session_state.event_log[-25:]), language=None)

# ── HPO tab ───────────────────────────────────────────────────────────────
with tab_hpo:
    st.markdown("### Bayesian Hyperparameter Optimisation")

    hc1, hc2, hc3 = st.columns(3)
    hpo_model  = hc1.selectbox("Model", ALL_MODELS, key="hpo_model",
                                format_func=lambda m: {
                                    "mlp":"MLP","cnn":"CNN","lstm":"LSTM","xgb":"XGBoost",
                                    "rf":"Random Forest","et":"Extra-Trees",
                                    "gb":"Gradient Boosting","hgb":"Hist GB",
                                    "ada":"AdaBoost","bagging":"Bagging",
                                    "stacking1":"Stacking-1","stacking2":"Stacking-2",
                                    "lgbm":"LightGBM",
                                }.get(m, m.upper()))
    hpo_mode   = hc2.selectbox("Mode", ["uni", "multi"], key="hpo_mode",
                                format_func=lambda m: "Uni-objective (TPE)" if m == "uni"
                                else "Multi-objective (NSGA-II)")
    hpo_trials = hc3.number_input("Trials", min_value=5, max_value=500, value=40, key="hpo_trials")

    if hpo_mode == "uni":
        hc4, hc5, hc6 = st.columns(3)
        hpo_sampler   = hc4.selectbox("Sampler", ["tpe", "cmaes", "random"])
        hpo_pruner    = hc5.selectbox("Pruner",  ["hyperband", "median", "nop"])
        hpo_objective = hc6.selectbox("Objective", ["f1", "roc_auc", "accuracy"])
        hpo_objectives = [hpo_objective]
    else:
        hpo_objectives = st.multiselect(
            "Objectives (pick two)",
            ["f1", "roc_auc", "accuracy", "precision", "recall"],
            default=["f1", "roc_auc"],
        )
        hpo_sampler, hpo_pruner, hpo_objective = "tpe", "nop", "f1"

    run_hpo = st.button("Start HPO", type="primary",
                        disabled=st.session_state.pipeline is None)

    if run_hpo and st.session_state.pipeline is not None:
        pipeline = st.session_state.pipeline
        dev = resolve_device(device)
        hpo_progress = st.progress(0, text="Starting HPO…")
        hpo_log_box  = st.empty()
        st.session_state.hpo_event_log = []

        trial_counter = {"n": 0}

        def hpo_event_cb(event_type: str, data: dict):
            if event_type == "trial_done":
                trial_counter["n"] += 1
                pct = min(int(100 * trial_counter["n"] / max(hpo_trials, 1)), 99)
                hpo_progress.progress(pct, text=f"Trial {trial_counter['n']}/{hpo_trials}")
                m = data.get("metrics", {})
                log_event(f"trial {data.get('trial')} — "
                         f"f1={m.get('f1',0):.3f} auc={m.get('roc_auc',0):.3f}",
                         "hpo_event_log")
            elif event_type in ("hpo_start", "hpo_done"):
                log_event(event_type, "hpo_event_log")
            hpo_log_box.code("\n".join(st.session_state.hpo_event_log[-25:]), language=None)

        try:
            embed_cfg = EmbeddingConfig(provider=llm_provider)
            embedder  = WindowEmbedder(embed_cfg)

            optuna_cfg = OptunaConfig(
                mode=hpo_mode, model_name=hpo_model, n_trials=int(hpo_trials),
                sampler=hpo_sampler, pruner=hpo_pruner,
                objective=hpo_objective, objectives=hpo_objectives,
            )

            hpo_result = run_optuna(
                optuna_cfg=optuna_cfg, pipeline=pipeline, embedder=embedder,
                device=dev, event_cb=hpo_event_cb,
            )
            st.session_state.hpo_result = hpo_result
            st.session_state.hpo_last_objective = hpo_objective

            primary_obj = hpo_objective if hpo_mode == "uni" else hpo_objectives[0]
            hplots = {}

            # ── Standard Optuna plots ─────────────────────────────────────
            hplots["history"]     = P.plot_optuna_history(hpo_result.all_trials_df, primary_obj)
            hplots["importance"]  = P.plot_param_importance(hpo_result.importance_df)
            hplots["parallel"]    = P.plot_parallel_coordinates(hpo_result.all_trials_df, primary_obj)
            hplots["edf"]         = P.plot_optuna_edf(hpo_result.all_trials_df, primary_obj)
            hplots["intermediate"]= P.plot_optuna_intermediate_values(hpo_result.all_trials_df, primary_obj)
            hplots["rank"]        = P.plot_optuna_rank(hpo_result.all_trials_df, primary_obj)

            if hpo_mode == "multi" and hpo_result.pareto_front is not None:
                hplots["pareto"] = P.plot_pareto_front(hpo_result.pareto_front, hpo_objectives)

            # ── Slice plots — top 5 params ────────────────────────────────
            top_params = (
                hpo_result.importance_df["parameter"].tolist()[:5]
                if hpo_result.importance_df is not None else []
            )
            for param in top_params:
                hplots[f"slice_{param}"] = P.plot_slice(
                    hpo_result.all_trials_df, param, primary_obj)

            # ── Contour plots — top 2 param pairs ────────────────────────
            if len(top_params) >= 2:
                for i in range(min(2, len(top_params) - 1)):
                    px_, py_ = top_params[i], top_params[i + 1]
                    key = f"contour_{px_}_vs_{py_}"
                    hplots[key] = P.plot_optuna_contour(
                        hpo_result.all_trials_df, px_, py_, primary_obj)

            st.session_state.hpo_plots = hplots
            hpo_progress.progress(100, text="HPO complete.")

        except Exception as e:
            st.error(f"HPO failed: {e}")
            st.code(traceback.format_exc())

    if st.session_state.hpo_result is not None:
        st.markdown("#### Best parameters found")
        st.json(st.session_state.hpo_result.best_params)

        hplots = st.session_state.hpo_plots
        primary_obj = st.session_state.get("hpo_last_objective", "f1")

        all_hpo_plots = [
            ("history",             "Optimisation History"),
            ("importance",          "Parameter Importance (fANOVA)"),
            ("parallel",            "Parallel Coordinates"),
            ("edf",                 "Empirical Distribution Function (EDF)"),
            ("intermediate",        "Intermediate Values per Trial"),
            ("rank",                "Rank Plot"),
            ("pareto",              "Pareto Front"),
        ]
        for key, title in all_hpo_plots:
            if key in hplots:
                st.markdown(f"#### {title}")
                render_plot(hplots[key], 400, key=f"hpo_{key}")

        # Slice plots
        for key, plot in hplots.items():
            if key.startswith("slice_"):
                st.markdown(f"#### Slice — {key.replace('slice_', '')}")
                render_plot(plot, 360, key=f"hpo_{key}")

        # Contour plots (top 2 params)
        for key, plot in hplots.items():
            if key.startswith("contour_"):
                label = key.replace("contour_", "").replace("_vs_", " vs ")
                st.markdown(f"#### Contour — {label}")
                render_plot(plot, 420, key=f"hpo_{key}")

# ── Results tab ──────────────────────────────────────────────────────────
with tab_results:
    if st.session_state.cv_results:
        results = st.session_state.cv_results
        tplots  = st.session_state.train_plots

        st.markdown("#### Table 1 — Rolling CV Validation Results (mean ± std, weighted)")
        cv_rows = []
        for name, res in results.items():
            row = {"Model": name.upper()}
            for m in METRICS:
                agg = res.cv_val_agg.get(m, {})
                row[m.upper()] = f"{agg.get('mean',0):.4f} ± {agg.get('std',0):.4f}"
            cv_rows.append(row)
        st.dataframe(pd.DataFrame(cv_rows), use_container_width=True, hide_index=True)

        st.markdown("#### Table 2 — Final Model Test Results (weighted)")
        test_rows = []
        for name, res in results.items():
            row = {"Model": name.upper()}
            for m in METRICS:
                row[m.upper()] = f"{res.test_metrics.get(m, float('nan')):.4f}"
            test_rows.append(row)
        st.dataframe(pd.DataFrame(test_rows), use_container_width=True, hide_index=True)

        if "all_roc" in tplots:
            st.markdown("#### All Models — ROC Curves (Test)")
            render_plot(tplots["all_roc"], 460, key="results_all_roc")

        # ── Confusion matrices for ALL trained models ──────────────────────
        st.markdown("---")
        st.markdown("### Confusion Matrices — All Models (Test Set)")
        cm_keys = [(m, f"{m}_cm_test") for m in results.keys()
                   if f"{m}_cm_test" in tplots]
        if cm_keys:
            # Two per row
            for i in range(0, len(cm_keys), 2):
                cols = st.columns(2)
                for j, (mname, cm_key) in enumerate(cm_keys[i:i+2]):
                    with cols[j]:
                        st.markdown(f"##### {mname.upper()}")
                        render_plot(tplots[cm_key], 380,
                                    key=f"results_cm_{mname}")

        # ── Per-model detail ───────────────────────────────────────────────
        st.markdown("---")
        st.markdown("### Per-Model Detail")
        sel = st.selectbox("Select model", list(results.keys()),
                           format_func=lambda m: m.upper(), key="results_model")
        for key, title, height in [
            ("cm_test",    "Confusion Matrix (Test)",        420),
            ("roc_test",   "ROC Curves (Test)",              460),
            ("pr_test",    "PR Curves (Test)",               420),
            ("cal_test",   "Calibration Curve (Test)",       420),
            ("importance", "Feature Importance",             460),
        ]:
            full_key = f"{sel}_{key}"
            if full_key in tplots:
                st.markdown(f"#### {title}")
                render_plot(tplots[full_key], height,
                            key=f"results_{sel}_{key}")
    else:
        st.info("Complete a training run to see results here.")
