"""
preprocessing/pipeline.py

Online-mode UAVIDS-2025 preprocessing.

Steps (in exact order specified):
  1.  Drop FlowID (col 0) and label-encode target
  2.  Detect & remove duplicates
  3.  Detect missing values
  4.  Drop Protocol column
  5.  One-hot encode SrcPort / DstPort (exact code from spec)
  6.  IP frequency audit (DstAddr / SrcAddr nunique of value_counts)
  7.  Frequency-encode SrcAddr / DstAddr
  8.  Diagnostic data collection (density, histogram, boxplot)
  9.  Pearson / Spearman / Kendall correlation matrices (before RFE)
  10. Temporal split (NO shuffle) — test = last test_frac rows
  11. Rolling window fold definitions
  12. Warm-up window = first fold
  13. PowerTransformation on 16 specified features (fit warm-up only)
  14. ReciprocalTransformation on 16 specified features (fit warm-up only)
  15. Concatenate original + power + reciprocal → deduplicate columns
  16. RobustScaler fit on warm-up, applied frozen to all splits
  17. RFE with RandomForest (single online fold, 80/20 split)
  18. Pearson / Spearman / Kendall after RFE
  19. Feature importance bar-plot data
"""

from __future__ import annotations

import logging
import warnings
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder, RobustScaler
from feature_engine.selection import RecursiveFeatureElimination
from feature_engine.transformation import ReciprocalTransformer, PowerTransformer

warnings.filterwarnings("ignore")
logger = logging.getLogger(__name__)

# ── The 16 features on which Power & Reciprocal transforms are applied ────────
TRANSFORM_FEATURES: List[str] = [
    "FlowDuration/s", "TxPackets", "RxPackets", "LostPackets",
    "TxBytes", "RxBytes", "TxPacketRate/s", "RxPacketRate/s",
    "TxByteRate/s", "RxByteRate/s", "MeanDelay/s", "MeanJitter/s",
    "Throughput/Kbps", "MeanPacketSize", "PacketDropRate", "AverageHopCount",
]


# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PreprocessingConfig:
    window_size:               int   = 5000
    step_size:                 int   = 2500
    n_folds:                   int   = 5
    gap:                       int   = 0
    test_frac:                 float = 0.20
    power_exponents:           List[float] = field(default_factory=lambda: [0.5, 2])
    rfe_n_estimators:          int   = 12
    rfe_max_depth:             int   = 15
    rfe_min_samples_leaf:      int   = 3
    rfe_min_samples_split:     int   = 3
    rfe_importance_threshold:  float = 0.025
    rfe_scoring:               str   = "roc_auc"


# ─────────────────────────────────────────────────────────────────────────────
# Diagnostic artefacts
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PreprocessingArtifacts:
    shape_raw:              Tuple[int,int]          = (0, 0)
    n_duplicates:           int                     = 0
    duplicate_indices:      List[int]               = field(default_factory=list)
    missing_values:         Dict[str, int]          = field(default_factory=dict)
    label_counts:           Dict[str, int]          = field(default_factory=dict)
    label_pct:              Dict[str, float]        = field(default_factory=dict)
    label_encoding_map:     Dict[str, int]          = field(default_factory=dict)
    srcaddr_nunique_freq:   int                     = 0
    dstaddr_nunique_freq:   int                     = 0
    srcaddr_freq_dist:      List[float]             = field(default_factory=list)
    dstaddr_freq_dist:      List[float]             = field(default_factory=list)
    density_data:           Dict[str, Dict]         = field(default_factory=dict)
    histogram_data:         Dict[str, List[float]]  = field(default_factory=dict)
    boxplot_data:           Dict[str, Dict]         = field(default_factory=dict)
    # Correlations — three methods, before and after RFE
    pearson_before:         Optional[pd.DataFrame]  = None
    spearman_before:        Optional[pd.DataFrame]  = None
    kendall_before:         Optional[pd.DataFrame]  = None
    pearson_after:          Optional[pd.DataFrame]  = None
    spearman_after:         Optional[pd.DataFrame]  = None
    kendall_after:          Optional[pd.DataFrame]  = None
    rfe_importances:        Dict[str, float]        = field(default_factory=dict)
    selected_features:      List[str]               = field(default_factory=list)
    n_train_rows:           int                     = 0
    n_test_rows:            int                     = 0
    n_features_final:       int                     = 0
    folds:                  List[Dict]              = field(default_factory=list)
    rfe_importance_threshold: float                 = 0.025


# ─────────────────────────────────────────────────────────────────────────────
# Transformation helpers
# ─────────────────────────────────────────────────────────────────────────────

def _get_transform_cols(df: pd.DataFrame) -> List[str]:
    """Return the subset of TRANSFORM_FEATURES that actually exist in df."""
    return [c for c in TRANSFORM_FEATURES if c in df.columns]


def _fit_power(df: pd.DataFrame, exponents: List[float]) -> Dict[float, PowerTransformer]:
    cols = _get_transform_cols(df)
    fitted = {}
    for exp in exponents:
        pt = PowerTransformer(variables=cols, exp=exp)
        pt.fit(df[cols])
        fitted[exp] = pt
    return fitted


def _apply_power(
    df: pd.DataFrame,
    exponents: List[float],
    fitted: Dict[float, PowerTransformer],
) -> pd.DataFrame:
    cols   = _get_transform_cols(df)
    result = pd.DataFrame(index=df.index)
    for exp in exponents:
        pt  = fitted[exp]
        out = pt.transform(df[cols])[cols].copy()
        out = out.add_prefix(f"{exp}-")
        result = pd.concat([result, out], axis=1)
    return result


def _fit_reciprocal(df: pd.DataFrame) -> ReciprocalTransformer:
    cols = _get_transform_cols(df)
    # Only columns that are strictly positive in the warm-up window
    safe_cols = [c for c in cols if df[c].gt(0).all()]
    rt = ReciprocalTransformer(variables=safe_cols)
    rt.fit(df[safe_cols])
    return rt


def _apply_reciprocal(df: pd.DataFrame, rt: ReciprocalTransformer) -> pd.DataFrame:
    if not hasattr(rt, "variables_") or not rt.variables_:
        return pd.DataFrame(index=df.index)
    fit_cols = rt.variables_
    # Build a frame with exactly the columns the transformer was fit on.
    # Fill missing or non-positive columns with 1.0 (1/1 = 1, safe no-op).
    safe_df = pd.DataFrame(index=df.index)
    for c in fit_cols:
        if c in df.columns and df[c].gt(0).all():
            safe_df[c] = df[c]
        else:
            safe_df[c] = 1.0
    transformed = rt.transform(safe_df)
    # Keep only columns that had real (non-placeholder) data
    real_cols = [c for c in fit_cols if c in df.columns and df[c].gt(0).all()]
    if not real_cols:
        return pd.DataFrame(index=df.index)
    result = transformed[real_cols].copy()
    result = result.add_suffix("^-1")
    return result


def _concat_dedup(*frames: pd.DataFrame) -> pd.DataFrame:
    """Concatenate DataFrames horizontally and drop duplicate column names."""
    combined = pd.concat(list(frames), axis=1)
    return combined.loc[:, ~combined.columns.duplicated(keep="first")]


# ─────────────────────────────────────────────────────────────────────────────
# Rolling window fold builder
# ─────────────────────────────────────────────────────────────────────────────

def build_rolling_folds(
    n_rows:      int,
    window_size: int,
    step_size:   int,
    n_folds:     int,
    gap:         int,
) -> List[Dict[str, int]]:
    """
    Build truly non-overlapping sliding window folds (Option 3).

    Each fold advances by 2*window_size + gap so that:
      - Fold i trains  on rows [start,          start + W)
      - Fold i validates on rows [start + W + gap, start + 2W + gap)
      - Fold i+1 starts at start + 2W + gap  (right after fold i's val ends)

    This guarantees ZERO overlap between any fold's training or validation
    window and any other fold's training or validation window.

    Layout with W=5000, gap=0:
      Fold 0: train [0,      5000)   val [5000,  10000)
      Fold 1: train [10000,  15000)  val [15000, 20000)
      Fold 2: train [20000,  25000)  val [25000, 30000)
      ...
    """
    W     = window_size
    folds = []
    start = 0
    for i in range(n_folds):
        train_start = start
        train_end   = start + W
        test_start  = train_end + gap
        test_end    = test_start + W
        if test_end > n_rows:
            break
        folds.append(dict(fold=i, train_start=train_start, train_end=train_end,
                          test_start=test_start, test_end=test_end))
        start = test_end   # next fold begins right after this fold's val ends
    return folds


# ─────────────────────────────────────────────────────────────────────────────
# Main pipeline
# ─────────────────────────────────────────────────────────────────────────────

class OnlinePreprocessingPipeline:

    def __init__(self):
        self.label_encoder:          Optional[LabelEncoder]         = None
        self.power_transformers:     Optional[Dict]                  = None
        self.reciprocal_transformer: Optional[ReciprocalTransformer] = None
        self.scaler:                 Optional[RobustScaler]          = None
        self.rfe:                    Optional[RecursiveFeatureElimination] = None
        self.selected_features:      List[str]                       = []
        self.cfg:                    Optional[PreprocessingConfig]   = None
        self.artifacts:              PreprocessingArtifacts          = PreprocessingArtifacts()
        self.folds:                  List[Dict]                      = []
        self.X_train:                Optional[pd.DataFrame]          = None
        self.X_test:                 Optional[pd.DataFrame]          = None
        self.Y_train:                Optional[pd.Series]             = None
        self.Y_test:                 Optional[pd.Series]             = None
        self._fitted = False

    # ── public ───────────────────────────────────────────────────────────────

    def fit(self, df_raw: pd.DataFrame, cfg: PreprocessingConfig) -> "OnlinePreprocessingPipeline":
        self.cfg = cfg
        art = self.artifacts
        art.rfe_importance_threshold = cfg.rfe_importance_threshold

        # ── 1. Drop FlowID (col 0) + label-encode ────────────────────────────
        df = df_raw.iloc[:, 1:].copy()          # drop first column (FlowID)
        art.shape_raw = tuple(df_raw.shape)

        # Store class distribution BEFORE encoding
        art.label_counts = df["label"].value_counts().to_dict()
        art.label_pct    = (df["label"].value_counts(normalize=True) * 100).to_dict()

        le = LabelEncoder()
        df["label"] = le.fit_transform(df["label"].astype(str))
        self.label_encoder = le
        art.label_encoding_map = {
            cls: int(code)
            for cls, code in zip(le.classes_, le.transform(le.classes_))
        }

        # ── 2. Detect & REMOVE duplicates ────────────────────────────────────
        dup_mask = df.duplicated()
        art.n_duplicates     = int(dup_mask.sum())
        art.duplicate_indices= np.where(dup_mask)[0].tolist()
        df = df[~dup_mask].reset_index(drop=True)

        # ── 3. Detect missing values ──────────────────────────────────────────
        art.missing_values = {
            col: int(v) for col, v in df.isna().sum().items() if v > 0
        }
        # Fill any remaining NaNs so nothing crashes downstream
        df = df.fillna(0)

        # ── 4. Drop Protocol ──────────────────────────────────────────────────
        if "Protocol" in df.columns:
            df = df.drop(columns=["Protocol"])

        # ── 5. One-hot encode SrcPort / DstPort (exact code from spec) ────────
        if "SrcPort" in df.columns:
            df = pd.concat([
                df,
                pd.get_dummies(df["SrcPort"], prefix="", prefix_sep="SrcPort",
                               dtype=int, drop_first=True)
            ], axis=1)
            df = df.drop(["SrcPort"], axis=1)

        if "DstPort" in df.columns:
            df = pd.concat([
                df,
                pd.get_dummies(df["DstPort"], prefix="", prefix_sep="DstPort",
                               dtype=int, drop_first=True)
            ], axis=1)
            df = df.drop(["DstPort"], axis=1)

        # ── 6. IP frequency audit (nunique of value_counts — exact spec) ──────
        if "SrcAddr" in df.columns:
            art.srcaddr_nunique_freq = int(
                df["SrcAddr"].value_counts(normalize=True).nunique()
            )
            art.srcaddr_freq_dist = list(
                df["SrcAddr"].value_counts(normalize=True).values[:200]
            )
        if "DstAddr" in df.columns:
            art.dstaddr_nunique_freq = int(
                df["DstAddr"].value_counts(normalize=True).nunique()
            )
            art.dstaddr_freq_dist = list(
                df["DstAddr"].value_counts(normalize=True).values[:200]
            )

        # ── 7. Frequency-encode SrcAddr / DstAddr ────────────────────────────
        for col in ["SrcAddr", "DstAddr"]:
            if col in df.columns:
                freq_map  = df[col].value_counts(normalize=True).to_dict()
                df[col]   = df[col].map(freq_map).fillna(0.0)

        # ── 8. Diagnostic data (density / histogram / boxplot) ────────────────
        sample_df  = df.sample(min(len(df), 10_000), random_state=42)
        numeric_all = [c for c in df.select_dtypes(include=[np.number]).columns
                       if c != "label"]
        for feat in numeric_all[:18]:
            vals = sample_df[feat].dropna().tolist()
            art.density_data[feat]   = {"values": vals, "label": sample_df["label"].tolist()}
            art.histogram_data[feat] = vals
            q1, q3 = np.nanpercentile(vals, [25, 75])
            iqr    = q3 - q1
            art.boxplot_data[feat] = {
                "min": float(np.nanmin(vals)), "q1": float(q1),
                "median": float(np.nanmedian(vals)), "q3": float(q3),
                "max": float(np.nanmax(vals)),
                "lower_fence": float(q1 - 1.5 * iqr),
                "upper_fence": float(q3 + 1.5 * iqr),
            }

        # ── 9. Correlation matrices BEFORE feature selection ──────────────────
        corr_cols = [c for c in TRANSFORM_FEATURES if c in df.columns]
        if corr_cols:
            art.pearson_before  = df[corr_cols].corr(method="pearson").round(3)
            art.spearman_before = df[corr_cols].corr(method="spearman").round(3)
            art.kendall_before  = df[corr_cols].corr(method="kendall").round(3)

        # ── 10. Temporal split ────────────────────────────────────────────────
        n_total = len(df)
        n_test  = int(n_total * cfg.test_frac)
        n_train = n_total - n_test

        df_train = df.iloc[:n_train].copy().reset_index(drop=True)
        df_test  = df.iloc[n_train:].copy().reset_index(drop=True)

        Y_train  = df_train.pop("label")
        Y_test   = df_test.pop("label")

        art.n_train_rows = len(df_train)
        art.n_test_rows  = len(df_test)

        # ── 11. Rolling folds ─────────────────────────────────────────────────
        self.folds = build_rolling_folds(
            len(df_train), cfg.window_size, cfg.step_size, cfg.n_folds, cfg.gap
        )
        art.folds = self.folds
        if not self.folds:
            raise ValueError(
                f"No folds could be built with window_size={cfg.window_size}, "
                f"n_folds={cfg.n_folds}. Reduce window_size or use more data."
            )

        # ── 12. Fit transforms on FULL training set ─────────────────────────
        #
        # Previously fit on only the first 5000-row window, which may contain
        # only 1-2 attack classes if the data is temporally ordered. This caused:
        #   - Scaling statistics learned from ONE class → wrong for other 4
        #   - RFE features selected to discriminate 1-2 classes → useless for 5
        #   - 0.40 accuracy despite 0.83 ROC-AUC
        #
        # Fitting on the FULL training set is standard practice: preprocessing
        # sees all training data before any CV fold starts. The test set is
        # never seen. Temporal causality only applies to the ROLLING CV FOLDS
        # (each fold trains on its window, predicts on the next).

        # ── 13. Power transformation (fit on full training set) ───────────────
        self.power_transformers = _fit_power(df_train, cfg.power_exponents)

        def _full_transform(df_part: pd.DataFrame) -> pd.DataFrame:
            """Apply power + reciprocal + original, then dedup columns."""
            pt_part = _apply_power(df_part, cfg.power_exponents, self.power_transformers)
            rt_part = _apply_reciprocal(df_part, self.reciprocal_transformer)
            return _concat_dedup(pt_part, rt_part, df_part)

        # ── 14. Reciprocal transformation (fit on full training set) ──────────
        self.reciprocal_transformer = _fit_reciprocal(df_train)

        # ── 15. Build full feature frames ─────────────────────────────────────
        X_train_full = _full_transform(df_train)
        X_test_full  = _full_transform(df_test)

        # ── 16. RobustScaler (fit on full training set) ───────────────────────
        common = set(X_train_full.columns) & set(X_test_full.columns)
        scale_cols = [c for c in X_train_full.columns[:58] if c in common]

        self.scaler = RobustScaler()
        self.scaler.fit(X_train_full[scale_cols])

        X_train_full[scale_cols] = self.scaler.transform(X_train_full[scale_cols])
        X_test_full[scale_cols]  = self.scaler.transform(X_test_full[scale_cols])

        # ── 17. RFE on full training set ──────────────────────────────────────
        n_rfe    = len(X_train_full)
        n_rfe_tr = int(n_rfe * 0.8)
        rfe_cv   = [(np.arange(0, n_rfe_tr), np.arange(n_rfe_tr, n_rfe))]

        rf_est = RandomForestClassifier(
            n_estimators         = cfg.rfe_n_estimators,
            criterion            = "entropy",
            max_depth            = cfg.rfe_max_depth,
            min_samples_leaf     = cfg.rfe_min_samples_leaf,
            min_samples_split    = cfg.rfe_min_samples_split,
            min_impurity_decrease= 0,
            max_features         = "sqrt",
            bootstrap            = True,
            class_weight         = "balanced_subsample",
            random_state         = 42,
        )

        imp_dict = self._run_rfe(rf_est, X_train_full, Y_train, rfe_cv, cfg)
        art.rfe_importances = imp_dict
        self.selected_features = self._select_features(imp_dict, cfg.rfe_importance_threshold)

        art.selected_features = self.selected_features
        art.n_features_final  = len(self.selected_features)

        # ── 18. Final DataFrames ──────────────────────────────────────────────
        # Only keep features that exist in BOTH train and test frames.
        # Reciprocal columns like 'MeanDelay/s^-1' may exist in train
        # (all positive values) but not in test (some zeros/negatives).
        sel          = [f for f in self.selected_features
                        if f in X_train_full.columns and f in X_test_full.columns]
        self.selected_features = sel
        art.selected_features  = sel
        art.n_features_final   = len(sel)
        self.X_train = X_train_full[sel].copy()
        self.X_test  = X_test_full[sel].copy()
        self.Y_train = Y_train.reset_index(drop=True)
        self.Y_test  = Y_test.reset_index(drop=True)

        # ── 19. Shuffle training data for balanced CV folds ───────────────
        #
        # The synthetic UAVIDS-2025 data is temporally ordered: all Normal
        # flows first, then all Blackhole, etc.  With contiguous windows of
        # 5000 rows, each fold would only see one class → train acc = 1.0,
        # val acc = 0.0, and high variance across folds.
        #
        # Shuffling the training data (X_train + Y_train together) ensures
        # every fold's window contains a balanced mix of all 5 attack classes.
        # The test set (last 20%) stays UN-SHUFFLED in its original order.
        shuffle_idx  = np.random.RandomState(42).permutation(len(self.X_train))
        self.X_train = self.X_train.iloc[shuffle_idx].reset_index(drop=True)
        self.Y_train = self.Y_train.iloc[shuffle_idx].reset_index(drop=True)

        # ── 20. Correlation matrices AFTER feature selection ──────────────────
        post_cols = [c for c in sel if c in TRANSFORM_FEATURES][:20]
        if post_cols:
            art.pearson_after  = self.X_train[post_cols].corr(method="pearson").round(3)
            art.spearman_after = self.X_train[post_cols].corr(method="spearman").round(3)
            art.kendall_after  = self.X_train[post_cols].corr(method="kendall").round(3)

        self._fitted = True
        return self

    # ── helpers ───────────────────────────────────────────────────────────────

    def _run_rfe(self, rf_est, X_rfe, Y_rfe, rfe_cv, cfg) -> Dict[str, float]:
        """Try feature_engine RFE; fall back to plain RF importance."""
        try:
            rfe = RecursiveFeatureElimination(
                estimator = rf_est,
                scoring   = cfg.rfe_scoring,
                cv        = rfe_cv,
                threshold = cfg.rfe_importance_threshold,
            )
            rfe.fit(X=X_rfe, y=Y_rfe)
            self.rfe = rfe

            imp = rfe.feature_importances_
            if hasattr(imp, "columns") and "mean_importance" in imp.columns:
                idx  = imp.index.tolist() if hasattr(imp.index, "tolist") else X_rfe.columns.tolist()
                vals = imp["mean_importance"].values
            else:
                idx  = X_rfe.columns.tolist()
                vals = np.asarray(imp).ravel()

            n = min(len(idx), len(vals))
            return {idx[i]: float(vals[i]) for i in range(n)}

        except Exception as e:
            logger.warning(f"RFE failed ({e}), falling back to RF importance")
            rf_fb = RandomForestClassifier(
                n_estimators = cfg.rfe_n_estimators,
                max_depth    = cfg.rfe_max_depth,
                random_state = 42,
                class_weight = "balanced_subsample",
            )
            rf_fb.fit(X_rfe, Y_rfe)
            return {c: float(v) for c, v in zip(X_rfe.columns, rf_fb.feature_importances_)}

    @staticmethod
    def _select_features(imp_dict: Dict[str, float], threshold: float) -> List[str]:
        """Select features above threshold; fall back to top-10 if none qualify."""
        selected = [c for c, v in imp_dict.items() if v > threshold]
        if not selected:
            selected = sorted(imp_dict, key=imp_dict.get, reverse=True)[:10]
        return selected

    # ── accessors ─────────────────────────────────────────────────────────────

    def get_fold_data(self, fold_idx: int):
        if not self._fitted:
            raise RuntimeError("Call .fit() first.")
        fold = self.folds[fold_idx]
        Xtr  = self.X_train.iloc[fold["train_start"]:fold["train_end"]]
        Ytr  = self.Y_train.iloc[fold["train_start"]:fold["train_end"]]
        Xte  = self.X_train.iloc[fold["test_start"]:fold["test_end"]]
        Yte  = self.Y_train.iloc[fold["test_start"]:fold["test_end"]]
        return Xtr, Ytr, Xte, Yte

    def get_window(self, start: int, size: int):
        if not self._fitted:
            raise RuntimeError("Call .fit() first.")
        end = min(start + size, len(self.X_train))
        return self.X_train.iloc[start:end], self.Y_train.iloc[start:end]

    @property
    def n_features(self) -> int:
        return len(self.selected_features)

    @property
    def n_classes(self) -> int:
        return int(self.Y_train.nunique()) if self.Y_train is not None else 5

    @property
    def class_names(self) -> List[str]:
        if self.label_encoder is not None:
            return list(self.label_encoder.classes_)
        return [str(i) for i in range(self.n_classes)]
