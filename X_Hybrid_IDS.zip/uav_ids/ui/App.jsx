import { useState, useEffect, useRef, useCallback } from "react";
import Plot from "react-plotly.js";

const API = "http://localhost:8000";

// ── palette ──────────────────────────────────────────────────────────────────
const ATTACK_COLORS = {
  Normal:"#10b981", Blackhole:"#ef4444",
  Flooding:"#f59e0b", Sybil:"#8b5cf6", Wormhole:"#3b82f6",
};
const MODEL_COLORS = {mlp:"#3b82f6",cnn:"#10b981",lstm:"#f59e0b",xgb:"#8b5cf6"};
const METRICS = ["accuracy","f1","precision","recall","roc_auc"];

// ── helpers ───────────────────────────────────────────────────────────────────
const fmt4 = v => typeof v==="number" ? v.toFixed(4) : "—";
const pct  = v => typeof v==="number" ? `${(v*100).toFixed(1)}%` : "—";

function Badge({children,color="#3b82f6",small=false}){
  return <span style={{
    background:color+"22",color,border:`1px solid ${color}44`,
    borderRadius:6,padding:small?"1px 7px":"3px 11px",
    fontSize:small?11:12,fontWeight:500,whiteSpace:"nowrap"
  }}>{children}</span>;
}

function Card({title,children,accent,style={}}){
  return <div style={{
    background:"#111827",border:`1px solid ${accent||"#374151"}`,
    borderRadius:12,padding:20,...style
  }}>
    {title&&<h3 style={{margin:"0 0 14px",fontSize:14,fontWeight:600,
                        color:"#e5e7eb"}}>{title}</h3>}
    {children}
  </div>;
}

function Spinner(){
  return <div style={{display:"flex",alignItems:"center",justifyContent:"center",
                      padding:40,color:"#6b7280",fontSize:13}}>
    <div style={{width:20,height:20,border:"2px solid #374151",
                 borderTopColor:"#3b82f6",borderRadius:"50%",
                 animation:"spin 0.8s linear infinite",marginRight:10}}/>
    Running…
    <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
  </div>;
}

function ProgressBar({pct:p,color="#3b82f6"}){
  return <div style={{background:"#1f2937",borderRadius:99,height:8,overflow:"hidden"}}>
    <div style={{width:`${p}%`,height:"100%",background:color,
                 borderRadius:99,transition:"width .4s ease"}}/>
  </div>;
}

function PlotCard({title,plotData,height=380}){
  if(!plotData) return null;
  return <Card title={title}>
    <Plot
      data={plotData.data||[]}
      layout={{...plotData.layout,height,autosize:true,
               paper_bgcolor:"rgba(0,0,0,0)",plot_bgcolor:"rgba(0,0,0,0)"}}
      config={{responsive:true,displayModeBar:true}}
      style={{width:"100%"}}
    />
  </Card>;
}

// ── Metrics Table component ────────────────────────────────────────────────────
function MetricsTable({title,rows}){
  if(!rows||!rows.length) return null;
  return <Card title={title}>
    <div style={{overflowX:"auto"}}>
      <table style={{width:"100%",borderCollapse:"collapse",fontSize:12}}>
        <thead>
          <tr style={{borderBottom:"1px solid #374151"}}>
            <th style={{textAlign:"left",padding:"8px 10px",color:"#9ca3af",fontWeight:500}}>Model</th>
            {METRICS.map(m=><th key={m} style={{textAlign:"right",padding:"8px 10px",
              color:"#9ca3af",fontWeight:500}}>{m.replace("_"," ").toUpperCase()}</th>)}
          </tr>
        </thead>
        <tbody>
          {rows.map((row,i)=><tr key={i} style={{borderBottom:"1px solid #1f2937"}}>
            <td style={{padding:"8px 10px"}}>
              <Badge color={MODEL_COLORS[row.model]||"#6b7280"}>{row.model.toUpperCase()}</Badge>
            </td>
            {METRICS.map(m=><td key={m} style={{textAlign:"right",padding:"8px 10px",
              color:"#d1d5db",fontFamily:"monospace"}}>{row[m]}</td>)}
          </tr>)}
        </tbody>
      </table>
    </div>
  </Card>;
}

// ── Tabs ─────────────────────────────────────────────────────────────────────
function Tabs({tabs,active,onSelect}){
  return <div style={{display:"flex",gap:4,borderBottom:"1px solid #374151",
                      marginBottom:16}}>
    {tabs.map(t=><button key={t} onClick={()=>onSelect(t)} style={{
      padding:"8px 16px",border:"none",background:"none",cursor:"pointer",
      fontSize:13,color:active===t?"#60a5fa":"#6b7280",
      borderBottom:active===t?"2px solid #3b82f6":"2px solid transparent",
      fontFamily:"inherit",fontWeight:active===t?500:400,
      transition:"all .15s"
    }}>{t}</button>}
  </div>;
}

// ── Sidebar config panel ──────────────────────────────────────────────────────
function SidebarField({label,children}){
  return <div style={{marginBottom:12}}>
    <label style={{fontSize:11,color:"#9ca3af",display:"block",
                   marginBottom:4,textTransform:"uppercase",letterSpacing:.05}}>{label}</label>
    {children}
  </div>;
}

function SInput({value,onChange,type="text",min,max,step}){
  return <input type={type} value={value} min={min} max={max} step={step}
    onChange={e=>onChange(type==="number"?Number(e.target.value):e.target.value)}
    style={{width:"100%",padding:"7px 10px",borderRadius:8,
            background:"#1f2937",border:"1px solid #374151",
            color:"#e5e7eb",fontSize:12,boxSizing:"border-box",fontFamily:"inherit"}}/>;
}

function SSelect({value,onChange,options}){
  return <select value={value} onChange={e=>onChange(e.target.value)}
    style={{width:"100%",padding:"7px 10px",borderRadius:8,
            background:"#1f2937",border:"1px solid #374151",
            color:"#e5e7eb",fontSize:12,fontFamily:"inherit"}}>
    {options.map(o=><option key={o.value||o} value={o.value||o}>{o.label||o}</option>)}
  </select>;
}

// ── Event log ─────────────────────────────────────────────────────────────────
function EventLog({events}){
  const ref = useRef();
  useEffect(()=>{if(ref.current) ref.current.scrollTop=ref.current.scrollHeight},[events]);
  return <div ref={ref} style={{height:160,overflowY:"auto",background:"#0f1117",
    borderRadius:8,padding:12,fontSize:11,fontFamily:"monospace",lineHeight:1.7,
    border:"1px solid #374151"}}>
    {events.slice(-60).map((e,i)=><div key={i} style={{color:
      e.type==="error"?"#ef4444":e.type==="done"?"#10b981":"#9ca3af"}}>
      <span style={{color:"#4b5563"}}>[{new Date(e.ts*1000).toLocaleTimeString()}] </span>
      <span style={{color:"#60a5fa"}}>{e.type}</span>
      {e.data?.message&&<span> — {e.data.message}</span>}
      {e.data?.model&&<span> [{e.data.model}]</span>}
      {e.data?.fold!==undefined&&<span> fold {e.data.fold}</span>}
    </div>)}
  </div>;
}

// ═══════════════════════════════════════════════════════════════════
// Main App
// ═══════════════════════════════════════════════════════════════════
export default function App(){
  const [tab, setTab] = useState("Data");

  // Upload
  const [datasetId, setDatasetId] = useState(null);
  const [datasetInfo, setDatasetInfo] = useState(null);

  // Preprocessing
  const [pipelineId, setPipelineId] = useState(null);
  const [pipelineInfo, setPipelineInfo] = useState(null);
  const [prepPlots, setPrepPlots] = useState({});
  const [prepRunning, setPrepRunning] = useState(false);

  // Preprocessing config
  const [windowSize, setWindowSize]   = useState(5000);
  const [stepSize,   setStepSize]     = useState(2500);
  const [nFolds,     setNFolds]       = useState(5);
  const [gap,        setGap]          = useState(0);
  const [testFrac,   setTestFrac]     = useState(0.20);
  const [rfeThresh,  setRfeThresh]    = useState(0.025);

  // Training
  const [trainRunId,    setTrainRunId]    = useState(null);
  const [trainStatus,   setTrainStatus]   = useState("idle");
  const [trainProgress, setTrainProgress] = useState(0);
  const [trainPlots,    setTrainPlots]    = useState({});
  const [trainSummary,  setTrainSummary]  = useState(null);
  const [cvTable,       setCvTable]       = useState([]);
  const [testTable,     setTestTable]     = useState([]);
  const [selectedModel, setSelectedModel] = useState("mlp");
  const [liveEvents,    setLiveEvents]    = useState([]);
  const [modelsToTrain, setModelsToTrain] = useState(["mlp","cnn","lstm","xgb"]);

  // LLM
  const [llmProvider, setLlmProvider] = useState("gpt-4o");
  const [calibration, setCalibration] = useState("isotonic");
  const [device,      setDevice]      = useState("auto");

  // HPO
  const [hpoModel,     setHpoModel]     = useState("mlp");
  const [hpoMode,      setHpoMode]      = useState("uni");
  const [hpoObjective, setHpoObjective] = useState("f1");
  const [hpoObjectives,setHpoObjectives]= useState(["f1","roc_auc"]);
  const [hpoTrials,    setHpoTrials]    = useState(40);
  const [hpoSampler,   setHpoSampler]   = useState("tpe");
  const [hpoPruner,    setHpoPruner]    = useState("hyperband");
  const [hpoRunId,     setHpoRunId]     = useState(null);
  const [hpoStatus,    setHpoStatus]    = useState("idle");
  const [hpoPlots,     setHpoPlots]     = useState({});
  const [hpoBestParams,setHpoBestParams]= useState(null);
  const [hpoEvents,    setHpoEvents]    = useState([]);

  const esRef  = useRef(null);
  const esHRef = useRef(null);

  // ── SSE connect ─────────────────────────────────────────────────────────────
  const connectSSE = useCallback((runId, isTrain) => {
    const ref = isTrain ? esRef : esHRef;
    if(ref.current) ref.current.close();
    const es = new EventSource(`${API}/api/stream/${runId}`);

    const addEvent = (type, data, ts) => {
      const entry = {type, data: typeof data==="string"?JSON.parse(data||"{}"):data, ts};
      if(isTrain) setLiveEvents(p=>[...p, entry]);
      else        setHpoEvents(p=>[...p, entry]);
    };

    for(const evt of ["status","fold_start","fold_done","training_start",
                       "model_done","final_fit_start","model_queued",
                       "trial_done","hpo_start","hpo_done","error"]){
      es.addEventListener(evt, e => {
        try{
          const d = JSON.parse(e.data);
          addEvent(evt, d, Date.now()/1000);
          if(evt==="fold_done" && isTrain){
            const p = d.progress_pct || 0;
            setTrainProgress(p);
          }
          if(evt==="model_done" && isTrain){
            setTrainSummary(prev=>({...prev,[d.model]:d}));
          }
        }catch(err){}
      });
    }

    es.addEventListener("done", e => {
      if(isTrain){
        setTrainStatus("done");
        setTrainProgress(100);
        fetchResults(runId, true);
      } else {
        setHpoStatus("done");
        fetchResults(runId, false);
      }
      es.close();
    });

    es.onerror = () => {
      if(isTrain) setTrainStatus("error");
      else        setHpoStatus("error");
      es.close();
    };

    ref.current = es;
  }, []);

  const fetchResults = async (runId, isTrain) => {
    try{
      const r = await fetch(`${API}/api/results/${runId}`);
      const d = await r.json();
      if(isTrain){
        setTrainPlots(d.plots||{});
        // Build metric table rows from summary
        if(d.summary){
          const cvRows = [], testRows = [];
          Object.entries(d.summary).forEach(([model, info])=>{
            const cv_agg = info.cv_val_agg||{};
            cvRows.push({model,...Object.fromEntries(
              METRICS.map(m=>[m, `${fmt4(cv_agg[m]?.mean||0)} ± ${fmt4(cv_agg[m]?.std||0)}`])
            )});
            const tm = info.test_metrics||{};
            testRows.push({model,...Object.fromEntries(
              METRICS.map(m=>[m, fmt4(tm[m])])
            )});
          });
          setCvTable(cvRows);
          setTestTable(testRows);
        }
      } else {
        setHpoPlots(d.plots||{});
        setHpoBestParams(d.best_params||null);
      }
    }catch(e){
      console.error("fetchResults:", e);
    }
  };

  // ── Upload handler ─────────────────────────────────────────────────────────
  const handleUpload = async e => {
    const file = e.target.files[0];
    if(!file) return;
    const form = new FormData();
    form.append("file", file);
    const r = await fetch(`${API}/api/upload`, {method:"POST", body:form});
    const d = await r.json();
    setDatasetId(d.dataset_id);
    setDatasetInfo(d);
  };

  // ── Preprocessing ──────────────────────────────────────────────────────────
  const runPreprocess = async () => {
    if(!datasetId) return;
    setPrepRunning(true);
    try{
      const r = await fetch(`${API}/api/preprocess`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body:JSON.stringify({
          dataset_id: datasetId,
          window_size: windowSize, step_size: stepSize,
          n_folds: nFolds, gap, test_frac: testFrac,
          rfe_importance_threshold: rfeThresh,
        }),
      });
      const d = await r.json();
      setPipelineId(d.pipeline_id);
      setPipelineInfo(d);

      // Fetch plots
      const rp = await fetch(`${API}/api/preprocess/${d.pipeline_id}/plots`);
      const dp = await rp.json();
      setPrepPlots(dp);
      setTab("Preprocessing");
    }catch(err){
      console.error(err);
    }finally{
      setPrepRunning(false);
    }
  };

  // ── Training ───────────────────────────────────────────────────────────────
  const startTraining = async () => {
    if(!pipelineId) return;
    setLiveEvents([]);
    setTrainPlots({});
    setCvTable([]);
    setTestTable([]);
    setTrainProgress(0);
    setTrainStatus("running");

    const r = await fetch(`${API}/api/train`, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        pipeline_id: pipelineId,
        llm_provider: llmProvider,
        device, calibration,
        models: modelsToTrain,
      }),
    });
    const d = await r.json();
    setTrainRunId(d.run_id);
    connectSSE(d.run_id, true);
  };

  // ── HPO ────────────────────────────────────────────────────────────────────
  const startHPO = async () => {
    if(!pipelineId) return;
    setHpoEvents([]);
    setHpoPlots({});
    setHpoBestParams(null);
    setHpoStatus("running");

    const r = await fetch(`${API}/api/hpo`, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({
        pipeline_id: pipelineId,
        model_name: hpoModel,
        mode: hpoMode,
        n_trials: hpoTrials,
        sampler: hpoSampler,
        pruner: hpoPruner,
        objective: hpoObjective,
        objectives: hpoObjectives,
        llm_provider: llmProvider,
        device,
      }),
    });
    const d = await r.json();
    setHpoRunId(d.run_id);
    connectSSE(d.run_id, false);
  };

  // ── Render ─────────────────────────────────────────────────────────────────
  const isTrainRunning = trainStatus === "running";
  const isHpoRunning   = hpoStatus   === "running";

  return <div style={{minHeight:"100vh",background:"#0f1117",color:"#e5e7eb",
    fontFamily:"-apple-system,BlinkMacSystemFont,'Inter',sans-serif",display:"flex"}}>

    {/* Sidebar */}
    <div style={{width:280,background:"#111827",borderRight:"1px solid #1f2937",
                 padding:20,overflowY:"auto",flexShrink:0,display:"flex",
                 flexDirection:"column",gap:16}}>

      {/* Header */}
      <div>
        <div style={{fontSize:15,fontWeight:700,letterSpacing:-.01,
                     display:"flex",alignItems:"center",gap:8}}>
          <span style={{fontSize:20}}>🛡</span>
          UAV IDS
        </div>
        <div style={{fontSize:11,color:"#6b7280",marginTop:2}}>
          UAVIDS-2025 · Online Intrusion Detection
        </div>
      </div>

      {/* Upload */}
      <Card accent={datasetId?"#10b981":undefined}>
        <SidebarField label="Dataset (synthetic CSV)">
          <label style={{display:"block",cursor:"pointer"}}>
            <input type="file" accept=".csv" onChange={handleUpload}
                   style={{display:"none"}}/>
            <div style={{padding:"8px 12px",borderRadius:8,border:"1px dashed #374151",
                         fontSize:12,color:"#6b7280",textAlign:"center",cursor:"pointer"}}>
              {datasetInfo ? `✓ ${datasetInfo.shape[0]} rows, ${datasetInfo.shape[1]} cols`
                           : "Click to upload CSV"}
            </div>
          </label>
        </SidebarField>
      </Card>

      {/* Preprocessing config */}
      <Card title="Preprocessing" accent="#374151">
        <SidebarField label="Window size">
          <SInput type="number" value={windowSize} onChange={setWindowSize} min={100}/>
        </SidebarField>
        <SidebarField label="Step size">
          <SInput type="number" value={stepSize} onChange={setStepSize} min={50}/>
        </SidebarField>
        <SidebarField label="N folds">
          <SInput type="number" value={nFolds} onChange={setNFolds} min={2} max={20}/>
        </SidebarField>
        <SidebarField label="Gap (rows)">
          <SInput type="number" value={gap} onChange={setGap} min={0}/>
        </SidebarField>
        <SidebarField label="Test fraction">
          <SInput type="number" value={testFrac} onChange={setTestFrac}
                  min={0.05} max={0.5} step={0.05}/>
        </SidebarField>
        <SidebarField label="RFE threshold">
          <SInput type="number" value={rfeThresh} onChange={setRfeThresh}
                  min={0.001} max={0.2} step={0.005}/>
        </SidebarField>
        <button onClick={runPreprocess} disabled={!datasetId||prepRunning}
          style={{width:"100%",padding:"9px 0",borderRadius:8,border:"none",
                  cursor:datasetId&&!prepRunning?"pointer":"not-allowed",fontSize:13,
                  fontWeight:600,background:datasetId?"#3b82f6":"#374151",
                  color:datasetId?"#fff":"#6b7280",fontFamily:"inherit"}}>
          {prepRunning ? "Running…" : "Run Preprocessing"}
        </button>
      </Card>

      {/* Training config */}
      <Card title="Training" accent="#374151">
        <SidebarField label="LLM provider">
          <SSelect value={llmProvider} onChange={setLlmProvider}
            options={["gpt-4o","claude","qwen","llama"]}/>
        </SidebarField>
        <SidebarField label="Calibration">
          <SSelect value={calibration} onChange={setCalibration}
            options={["isotonic","sigmoid"]}/>
        </SidebarField>
        <SidebarField label="Device">
          <SSelect value={device} onChange={setDevice}
            options={["auto","cpu","cuda","mps"]}/>
        </SidebarField>
        <SidebarField label="Models">
          <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
            {["mlp","cnn","lstm","xgb"].map(m=>{
              const on = modelsToTrain.includes(m);
              const c  = MODEL_COLORS[m];
              return <button key={m} onClick={()=>
                setModelsToTrain(on?modelsToTrain.filter(x=>x!==m):[...modelsToTrain,m])
              } style={{padding:"4px 12px",borderRadius:6,border:`1.5px solid ${on?c:"#374151"}`,
                background:on?c+"22":"transparent",color:on?c:"#6b7280",
                fontSize:12,fontWeight:600,cursor:"pointer",fontFamily:"inherit"}}>
                {m.toUpperCase()}
              </button>;
            })}
          </div>
        </SidebarField>
        <button onClick={startTraining}
          disabled={!pipelineId||isTrainRunning||modelsToTrain.length===0}
          style={{width:"100%",padding:"9px 0",borderRadius:8,border:"none",
                  cursor:pipelineId&&!isTrainRunning?"pointer":"not-allowed",fontSize:13,
                  fontWeight:600,background:isTrainRunning?"#7f1d1d":pipelineId?"#10b981":"#374151",
                  color:pipelineId?"#fff":"#6b7280",fontFamily:"inherit"}}>
          {isTrainRunning?"⏳ Training…":"▶ Start Training"}
        </button>
      </Card>

      {/* Pipeline info */}
      {pipelineInfo && <Card accent="#374151" style={{fontSize:12}}>
        <div style={{color:"#9ca3af",marginBottom:8}}>Pipeline ready</div>
        {[
          ["Train rows",  pipelineInfo.n_train],
          ["Test rows",   pipelineInfo.n_test],
          ["Features",    pipelineInfo.n_features],
          ["Folds",       pipelineInfo.n_folds],
        ].map(([k,v])=><div key={k} style={{display:"flex",justifyContent:"space-between",
          padding:"3px 0",borderBottom:"1px solid #1f2937"}}>
          <span style={{color:"#6b7280"}}>{k}</span>
          <span style={{fontWeight:500}}>{v}</span>
        </div>)}
      </Card>}
    </div>

    {/* Main area */}
    <div style={{flex:1,overflowY:"auto",padding:24}}>
      <Tabs
        tabs={["Data","Preprocessing","Training","HPO","Results"]}
        active={tab} onSelect={setTab}
      />

      {/* ── DATA tab ── */}
      {tab==="Data" && <div style={{display:"flex",flexDirection:"column",gap:16}}>
        {datasetInfo ? <>
          <Card title="Dataset Overview">
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16,marginBottom:16}}>
              {[["Rows",datasetInfo.shape[0]],["Columns",datasetInfo.shape[1]],
                ["Dataset ID",datasetInfo.dataset_id]].map(([k,v])=>
                <div key={k} style={{background:"#0f1117",borderRadius:8,padding:14}}>
                  <div style={{fontSize:11,color:"#6b7280",marginBottom:4}}>{k}</div>
                  <div style={{fontSize:20,fontWeight:600,color:"#60a5fa"}}>{v}</div>
                </div>
              )}
            </div>
            <div style={{fontSize:12,color:"#9ca3af",marginBottom:8}}>Columns:</div>
            <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
              {datasetInfo.columns.map(c=><Badge key={c} color="#374151" small>{c}</Badge>)}
            </div>
          </Card>
          <Card title="Preview (first 5 rows)">
            <div style={{overflowX:"auto"}}>
              <table style={{width:"100%",borderCollapse:"collapse",fontSize:11,
                             fontFamily:"monospace"}}>
                <thead><tr style={{borderBottom:"1px solid #374151"}}>
                  {datasetInfo.columns.map(c=><th key={c} style={{textAlign:"left",
                    padding:"6px 8px",color:"#9ca3af",fontWeight:500,whiteSpace:"nowrap"}}>
                    {c}
                  </th>)}
                </tr></thead>
                <tbody>
                  {datasetInfo.preview.map((row,i)=><tr key={i}
                    style={{borderBottom:"1px solid #1f2937"}}>
                    {datasetInfo.columns.map(c=><td key={c} style={{padding:"5px 8px",
                      color:"#d1d5db",whiteSpace:"nowrap"}}>{String(row[c]??"")}
                    </td>)}
                  </tr>)}
                </tbody>
              </table>
            </div>
          </Card>
        </> : <div style={{textAlign:"center",padding:60,color:"#6b7280"}}>
          Upload your synthetic UAVIDS-2025 CSV to get started.
        </div>}
      </div>}

      {/* ── PREPROCESSING tab ── */}
      {tab==="Preprocessing" && <div style={{display:"flex",flexDirection:"column",gap:16}}>
        {prepRunning && <Card><Spinner/></Card>}
        {pipelineInfo && <Card title="Preprocessing Summary">
          <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>
            {[["Train rows",pipelineInfo.n_train],["Test rows",pipelineInfo.n_test],
              ["Features selected",pipelineInfo.n_features],
              ["CV Folds",pipelineInfo.n_folds]].map(([k,v])=>
              <div key={k} style={{background:"#0f1117",borderRadius:8,padding:12,textAlign:"center"}}>
                <div style={{fontSize:22,fontWeight:700,color:"#60a5fa"}}>{v}</div>
                <div style={{fontSize:11,color:"#6b7280",marginTop:3}}>{k}</div>
              </div>
            )}
          </div>
          {pipelineInfo.selected?.length>0&&<div style={{marginTop:14}}>
            <div style={{fontSize:12,color:"#9ca3af",marginBottom:6}}>Selected features:</div>
            <div style={{display:"flex",flexWrap:"wrap",gap:5}}>
              {pipelineInfo.selected.map(f=><Badge key={f} color="#3b82f6" small>{f}</Badge>)}
            </div>
          </div>}
        </Card>}
        {Object.entries({
          "Class Distribution":    prepPlots.class_distribution,
          "Feature Density":       prepPlots.density,
          "Histograms":            prepPlots.histograms,
          "Boxplots":              prepPlots.boxplots,
          "IP Frequency":          prepPlots.ip_freq,
          "RFE Importance":        prepPlots.rfe_importance,
          "Rolling Window Folds":  prepPlots.rolling_folds,
          "Pearson (before)":      prepPlots.pearson_before,
          "Kendall (before)":      prepPlots.kendall_before,
          "Pearson (after RFE)":   prepPlots.pearson_after,
          "Kendall (after RFE)":   prepPlots.kendall_after,
        }).filter(([,v])=>v).map(([title,data])=>
          <PlotCard key={title} title={title} plotData={data}
                    height={title.includes("Density")||title.includes("Histo")||title.includes("Box")?500:380}/>
        )}
      </div>}

      {/* ── TRAINING tab ── */}
      {tab==="Training" && <div style={{display:"flex",flexDirection:"column",gap:16}}>
        {isTrainRunning&&<Card accent="#f59e0b">
          <div style={{display:"flex",justifyContent:"space-between",
                       alignItems:"center",marginBottom:10}}>
            <span style={{fontSize:13}}>Training in progress…</span>
            <span style={{fontSize:13,fontWeight:700,color:"#f59e0b"}}>{trainProgress}%</span>
          </div>
          <ProgressBar pct={trainProgress} color="#f59e0b"/>
        </Card>}

        {liveEvents.length>0&&<Card title="Live Events">
          <EventLog events={liveEvents}/>
        </Card>}

        {/* Model selector for per-model plots */}
        {trainStatus==="done"&&<div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
          {modelsToTrain.map(m=><button key={m} onClick={()=>setSelectedModel(m)} style={{
            padding:"6px 16px",borderRadius:8,border:`1.5px solid ${selectedModel===m?MODEL_COLORS[m]:"#374151"}`,
            background:selectedModel===m?MODEL_COLORS[m]+"22":"transparent",
            color:selectedModel===m?MODEL_COLORS[m]:"#6b7280",
            fontSize:13,fontWeight:600,cursor:"pointer",fontFamily:"inherit"
          }}>{m.toUpperCase()}</button>)}
        </div>}

        {/* Per-model plots */}
        {["cv_f1","cv_auc","loss"].filter(k=>trainPlots[`${selectedModel}_${k}`]).map(k=>
          <PlotCard key={k}
            title={k==="cv_f1"?"CV F1 per Fold":k==="cv_auc"?"CV ROC-AUC per Fold":"Training Loss"}
            plotData={trainPlots[`${selectedModel}_${k}`]} height={340}/>
        )}
        {["cm_test","roc_test","pr_test","cal_test"].filter(k=>trainPlots[`${selectedModel}_${k}`]).map(k=>
          <PlotCard key={k}
            title={k==="cm_test"?"Confusion Matrix":k==="roc_test"?"ROC Curves":k==="pr_test"?"Precision-Recall Curves":"Calibration Curves"}
            plotData={trainPlots[`${selectedModel}_${k}`]} height={440}/>
        )}
        {trainPlots.all_roc&&<PlotCard title="All Models — ROC (Macro)" plotData={trainPlots.all_roc} height={440}/>}
        {trainPlots.xgb_importance&&<PlotCard title="XGBoost Feature Importance" plotData={trainPlots.xgb_importance} height={440}/>}
      </div>}

      {/* ── HPO tab ── */}
      {tab==="HPO" && <div style={{display:"flex",flexDirection:"column",gap:16}}>
        <Card title="Hyperparameter Optimisation">
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12,marginBottom:16}}>
            <div>
              <SidebarField label="Model">
                <SSelect value={hpoModel} onChange={setHpoModel}
                  options={["mlp","cnn","lstm","xgb"]}/>
              </SidebarField>
            </div>
            <div>
              <SidebarField label="Mode">
                <SSelect value={hpoMode} onChange={setHpoMode}
                  options={[{value:"uni",label:"Uni-objective (TPE)"},{value:"multi",label:"Multi-objective (NSGA-II)"}]}/>
              </SidebarField>
            </div>
            <div>
              <SidebarField label="Trials">
                <SInput type="number" value={hpoTrials} onChange={setHpoTrials} min={5} max={500}/>
              </SidebarField>
            </div>
            {hpoMode==="uni"&&<>
              <div><SidebarField label="Sampler">
                <SSelect value={hpoSampler} onChange={setHpoSampler}
                  options={["tpe","cmaes","random"]}/>
              </SidebarField></div>
              <div><SidebarField label="Pruner">
                <SSelect value={hpoPruner} onChange={setHpoPruner}
                  options={["hyperband","median","nop"]}/>
              </SidebarField></div>
              <div><SidebarField label="Objective">
                <SSelect value={hpoObjective} onChange={setHpoObjective}
                  options={["f1","roc_auc","accuracy"]}/>
              </SidebarField></div>
            </>}
            {hpoMode==="multi"&&<div style={{gridColumn:"span 3"}}>
              <SidebarField label="Objectives (select 2)">
                <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                  {["f1","roc_auc","accuracy","precision","recall"].map(obj=>{
                    const on=hpoObjectives.includes(obj);
                    return <button key={obj} onClick={()=>
                      setHpoObjectives(on&&hpoObjectives.length>1
                        ?hpoObjectives.filter(x=>x!==obj)
                        :on?hpoObjectives:[...hpoObjectives,obj])
                    } style={{padding:"4px 12px",borderRadius:6,fontSize:12,cursor:"pointer",
                      border:`1.5px solid ${on?"#3b82f6":"#374151"}`,
                      background:on?"#3b82f622":"transparent",
                      color:on?"#60a5fa":"#6b7280",fontFamily:"inherit"}}>
                      {obj.toUpperCase()}
                    </button>;
                  })}
                </div>
              </SidebarField>
            </div>}
          </div>
          <button onClick={startHPO}
            disabled={!pipelineId||isHpoRunning}
            style={{padding:"10px 24px",borderRadius:8,border:"none",
                    cursor:pipelineId&&!isHpoRunning?"pointer":"not-allowed",fontSize:13,
                    fontWeight:600,background:isHpoRunning?"#7f1d1d":pipelineId?"#8b5cf6":"#374151",
                    color:"#fff",fontFamily:"inherit"}}>
            {isHpoRunning?"⏳ Optimising…":"▶ Start HPO"}
          </button>
        </Card>

        {hpoEvents.length>0&&<Card title="HPO Events">
          <EventLog events={hpoEvents}/>
        </Card>}

        {hpoBestParams&&<Card title="Best Parameters Found" accent="#8b5cf6">
          <div style={{display:"flex",flexWrap:"wrap",gap:8}}>
            {Object.entries(hpoBestParams).map(([k,v])=>
              <div key={k} style={{background:"#0f1117",borderRadius:6,padding:"6px 12px",
                                   fontSize:12,fontFamily:"monospace"}}>
                <span style={{color:"#9ca3af"}}>{k}:</span>
                <span style={{color:"#a78bfa",marginLeft:4}}>{String(v)}</span>
              </div>
            )}
          </div>
        </Card>}

        {Object.entries({
          "Optimisation History":    hpoPlots.history,
          "Parameter Importance":    hpoPlots.importance,
          "Parallel Coordinates":    hpoPlots.parallel,
          "Pareto Front":            hpoPlots.pareto,
          ...Object.fromEntries(Object.entries(hpoPlots).filter(([k])=>k.startsWith("slice_"))
            .map(([k,v])=>[`Slice — ${k.replace("slice_","").replace("_"," ")}`,v])),
        }).filter(([,v])=>v).map(([title,data])=>
          <PlotCard key={title} title={title} plotData={data} height={380}/>
        )}
      </div>}

      {/* ── RESULTS tab ── */}
      {tab==="Results" && <div style={{display:"flex",flexDirection:"column",gap:16}}>
        {cvTable.length===0&&testTable.length===0&&<div style={{
          textAlign:"center",padding:60,color:"#6b7280"}}>
          Complete a training run to see results.
        </div>}
        <MetricsTable title="Table 1 — Rolling CV Validation Results (mean ± std, weighted)" rows={cvTable}/>
        <MetricsTable title="Table 2 — Final Calibrated Model Test Results (weighted)" rows={testTable}/>
        {trainPlots.all_roc&&<PlotCard title="All Models — ROC Curves (Test)" plotData={trainPlots.all_roc} height={460}/>}
        {trainPlots[`${selectedModel}_cm_test`]&&
          <PlotCard title={`${selectedModel.toUpperCase()} — Confusion Matrix (Test)`}
            plotData={trainPlots[`${selectedModel}_cm_test`]} height={440}/>}
        {trainPlots[`${selectedModel}_cal_test`]&&
          <PlotCard title={`${selectedModel.toUpperCase()} — Calibration Curve (Test)`}
            plotData={trainPlots[`${selectedModel}_cal_test`]} height={420}/>}
        {trainPlots.xgb_importance&&
          <PlotCard title="XGBoost Feature Importance" plotData={trainPlots.xgb_importance} height={460}/>}
      </div>}
    </div>
  </div>;
}
