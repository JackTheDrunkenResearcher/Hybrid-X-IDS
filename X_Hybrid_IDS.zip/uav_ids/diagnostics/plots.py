"""
diagnostics/plots.py

All Plotly interactive diagnostic figures for the UAV IDS dashboard.

Every function returns a dict (Plotly JSON-serialisable via plotly.io.to_json)
so the FastAPI backend can send them directly to React, which renders
them with <Plot data={fig.data} layout={fig.layout} />.

Covers:
  Preprocessing
    1.  Class distribution horizontal bar
    2.  Density plots (per feature, by class)
    3.  Histogram plots (multi-bin overlay per feature)
    4.  Boxplot grid (all features)
    5.  Pearson correlation heatmap
    6.  Kendall correlation heatmap
    7.  IP address frequency distribution
    8.  RFE feature importance bar
    9.  Rolling window fold visualisation

  Training / CV
    10. Rolling CV metrics per fold (line + error bands)
    11. Train vs validation metric comparison table figure
    12. Loss curves per fold per model
    13. Confusion matrix heatmap
    14. ROC curves (per class + micro/macro)
    15. Precision-Recall curves
    16. Calibration curves (reliability diagrams)

  Optuna HPO
    17. Optimisation history (best value per trial)
    18. Parameter importance (fANOVA bar chart)
    19. Parallel coordinates (all trials, coloured by objective)
    20. Pareto front scatter (multi-objective)
    21. Slice plots (one per hyperparameter)

  Feature importance
    22. XGBoost feature importance bar chart
"""

from __future__ import annotations

from typing import Dict, List, Optional, Any

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
from sklearn.metrics import roc_curve, auc, precision_recall_curve
from sklearn.preprocessing import label_binarize

# ── colour palette ─────────────────────────────────────────────────────────
ATTACK_COLORS = {
    "Normal":    "#10b981",
    "Blackhole": "#ef4444",
    "Flooding":  "#f59e0b",
    "Sybil":     "#8b5cf6",
    "Wormhole":  "#3b82f6",
}
MODEL_COLORS = {"mlp":"#3b82f6","cnn":"#10b981","lstm":"#f59e0b","xgb":"#8b5cf6"}
FOLD_PALETTE = px.colors.qualitative.Set2

DARK_BG  = "#0f1117"
CARD_BG  = "#1a1d2e"
GRID_CLR = "#2d2f45"
TEXT_CLR = "#e2e8f0"

BASE_LAYOUT = dict(
    paper_bgcolor = "rgba(0,0,0,0)",
    plot_bgcolor  = "rgba(0,0,0,0)",
    font          = dict(color=TEXT_CLR, family="Inter, sans-serif", size=12),
    margin        = dict(l=50, r=30, t=50, b=40),
)

# Applied via fig.update_layout(**AXIS_STYLE) only in plots that don't
# set their own axis/legend overrides.
AXIS_STYLE = dict(
    xaxis_gridcolor     = GRID_CLR,
    xaxis_zerolinecolor = GRID_CLR,
    yaxis_gridcolor     = GRID_CLR,
    yaxis_zerolinecolor = GRID_CLR,
    legend_bgcolor      = "rgba(0,0,0,0)",
    legend_bordercolor  = GRID_CLR,
)

def _fig(fig: go.Figure) -> dict:
    """Convert to JSON-serialisable dict for API response."""
    import plotly.io as pio
    import json
    return json.loads(pio.to_json(fig))


# ═══════════════════════════════════════════════════════════════════
# PREPROCESSING PLOTS
# ═══════════════════════════════════════════════════════════════════

def plot_class_distribution(
    label_counts: Dict[str, int],
    label_pct:    Dict[str, float],
    class_names:  List[str],
) -> dict:
    categories = list(label_counts.keys())
    counts     = [label_counts[c] for c in categories]
    pcts       = [label_pct.get(c, 0) for c in categories]
    colors     = [ATTACK_COLORS.get(c, "#6b7280") for c in categories]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        y           = categories,
        x           = counts,
        orientation = "h",
        marker_color= colors,
        text        = [f"{p:.1f}%" for p in pcts],
        textposition= "outside",
        hovertemplate = "<b>%{y}</b><br>Count: %{x}<br>%{text}<extra></extra>",
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title     = "Class Distribution",
        xaxis_title = "Count",
        height    = 320,
    )
    return _fig(fig)


def plot_density_grid(density_data: Dict[str, Dict], class_names: List[str]) -> dict:
    feats = list(density_data.keys())[:12]
    n_cols = 4
    n_rows = int(np.ceil(len(feats) / n_cols))
    fig = make_subplots(rows=n_rows, cols=n_cols,
                         subplot_titles=feats, vertical_spacing=0.08)
    for i, feat in enumerate(feats):
        row, col = divmod(i, n_cols)
        d = density_data[feat]
        vals   = np.array(d["values"])
        labels = np.array(d["label"])
        for cls_id in np.unique(labels):
            cls_vals = vals[labels == cls_id]
            cls_name = class_names[int(cls_id)] if int(cls_id) < len(class_names) else str(cls_id)
            fig.add_trace(
                go.Violin(
                    x         = cls_vals,
                    name      = cls_name,
                    line_color= list(ATTACK_COLORS.values())[int(cls_id) % 5],
                    showlegend= (i == 0),
                    opacity   = 0.7,
                    side      = "positive",
                ),
                row=row+1, col=col+1,
            )
    fig.update_layout(**BASE_LAYOUT, title="Feature Density by Class",
                       height=300*n_rows, showlegend=True)
    return _fig(fig)


def plot_histogram_grid(histogram_data: Dict[str, List[float]]) -> dict:
    feats  = list(histogram_data.keys())[:12]
    n_cols = 4
    n_rows = int(np.ceil(len(feats) / n_cols))
    fig = make_subplots(rows=n_rows, cols=n_cols, subplot_titles=feats,
                         vertical_spacing=0.08)
    bins_list = [20, 40, 60, 80]
    for i, feat in enumerate(feats):
        row, col = divmod(i, n_cols)
        vals = histogram_data[feat]
        for b, bins in enumerate(bins_list):
            fig.add_trace(
                go.Histogram(
                    x       = vals,
                    nbinsx  = bins,
                    name    = f"{bins} bins",
                    opacity = 0.6,
                    showlegend=(i == 0),
                    marker_color=px.colors.qualitative.Plotly[b],
                ),
                row=row+1, col=col+1,
            )
    fig.update_layout(**BASE_LAYOUT, title="Feature Histograms (multi-bin)",
                       height=300*n_rows, barmode="overlay")
    return _fig(fig)


def plot_boxplot_grid(boxplot_data: Dict[str, Dict]) -> dict:
    feats  = list(boxplot_data.keys())
    n_cols = 4
    n_rows = int(np.ceil(len(feats) / n_cols))
    fig = make_subplots(rows=n_rows, cols=n_cols, subplot_titles=feats,
                         vertical_spacing=0.08)
    for i, (feat, stats) in enumerate(boxplot_data.items()):
        row, col = divmod(i, n_cols)
        fig.add_trace(
            go.Box(
                q1        = [stats["q1"]],
                median    = [stats["median"]],
                q3        = [stats["q3"]],
                lowerfence= [stats["lower_fence"]],
                upperfence= [stats["upper_fence"]],
                name      = feat,
                showlegend= False,
                marker_color = "#3b82f6",
            ),
            row=row+1, col=col+1,
        )
    fig.update_layout(**BASE_LAYOUT, title="Boxplots — Outlier Detection",
                       height=280*n_rows)
    return _fig(fig)


def plot_correlation_heatmap(
    corr_matrix: pd.DataFrame,
    title: str = "Correlation Heatmap",
) -> dict:
    z     = corr_matrix.values
    cols  = corr_matrix.columns.tolist()
    fig = go.Figure(go.Heatmap(
        z            = z,
        x            = cols,
        y            = cols,
        colorscale   = "YlGnBu",
        text         = np.round(z, 2),
        texttemplate = "%{text}",
        colorbar     = dict(title="r"),
        zmin=-1, zmax=1,
    ))
    fig.update_layout(**BASE_LAYOUT, title=title,
                       height=max(400, len(cols) * 35))
    return _fig(fig)


def plot_ip_freq_distribution(
    srcaddr_dist: List[float],
    dstaddr_dist: List[float],
) -> dict:
    fig = make_subplots(rows=1, cols=2,
                         subplot_titles=["SrcAddr Frequency", "DstAddr Frequency"])
    for col, dist in enumerate([srcaddr_dist, dstaddr_dist], 1):
        for bins in [10, 20, 30, 40]:
            counts, edges = np.histogram(dist, bins=bins)
            fig.add_trace(
                go.Bar(x=edges[:-1], y=counts, name=f"{bins} bins",
                       opacity=0.6, showlegend=(col==1)),
                row=1, col=col,
            )
    fig.update_layout(**BASE_LAYOUT, barmode="overlay",
                       title="IP Address Frequency Encoding Distribution", height=340)
    return _fig(fig)


def plot_rfe_importance(importance: Dict[str, float], threshold: float = 0.025) -> dict:
    if not importance:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT,
                    title="RFE Feature Importances — no data"))
    df  = pd.DataFrame(list(importance.items()), columns=["feature", "importance"])
    df  = df.sort_values("importance", ascending=True)

    # Colour: green if above threshold, red if below
    clr = ["#10b981" if v >= threshold else "#ef4444" for v in df["importance"]]

    fig = go.Figure(go.Bar(
        x            = df["importance"],
        y            = df["feature"],
        orientation  = "h",
        marker_color = clr,
        text         = [f"{v:.4f}" for v in df["importance"]],
        textposition = "outside",
        hovertemplate= "<b>%{y}</b><br>Importance: %{x:.5f}<extra></extra>",
    ))
    # Add threshold line
    fig.add_vline(
        x=threshold, line_dash="dash", line_color="#f59e0b",
        annotation_text=f"threshold={threshold}",
        annotation_position="top right",
    )
    # X-axis: start from 0, add a little padding on the right for text labels
    max_val = float(df["importance"].max()) if len(df) > 0 else threshold
    x_max   = max(max_val * 1.25, threshold * 2)
    fig.update_layout(
        **BASE_LAYOUT,
        title       = "RFE Feature Importances (RandomForest)",
        xaxis_title = "Mean Importance",
        yaxis_title = "Feature",
        xaxis_range = [0, x_max],
        height      = max(420, len(df) * 22 + 80),
    )
    return _fig(fig)


def plot_rolling_folds(
    folds: List[Dict],
    n_train: int,
    n_test:  int,
) -> dict:
    fig = go.Figure()
    for fold in folds:
        fi = fold["fold"]
        fig.add_trace(go.Bar(
            x    = [fold["train_end"] - fold["train_start"]],
            base = [fold["train_start"]],
            y    = [f"Fold {fi}"],
            orientation = "h",
            name = "Train",
            marker_color = "#3b82f6",
            showlegend = (fi == 0),
            hovertemplate = f"Fold {fi} train: [{fold['train_start']}, {fold['train_end']})<extra></extra>",
        ))
        gap_size = fold["test_start"] - fold["train_end"]
        if gap_size > 0:
            fig.add_trace(go.Bar(
                x    = [gap_size],
                base = [fold["train_end"]],
                y    = [f"Fold {fi}"],
                orientation = "h",
                name = "Gap",
                marker_color = "#6b7280",
                showlegend = (fi == 0),
            ))
        fig.add_trace(go.Bar(
            x    = [fold["test_end"] - fold["test_start"]],
            base = [fold["test_start"]],
            y    = [f"Fold {fi}"],
            orientation = "h",
            name = "Validation",
            marker_color = "#f59e0b",
            showlegend = (fi == 0),
        ))

    fig.add_vline(x=n_train, line_dash="dash", line_color="#ef4444",
                  annotation_text="Test set starts")
    fig.update_layout(
        **BASE_LAYOUT,
        barmode     = "overlay",
        title       = "Rolling Window CV — Fold Layout",
        xaxis_title = "Row index",
        height      = max(250, len(folds) * 50 + 80),
    )
    return _fig(fig)


# ═══════════════════════════════════════════════════════════════════
# TRAINING / CV PLOTS
# ═══════════════════════════════════════════════════════════════════

def plot_cv_metrics_per_fold(
    fold_results: List[Dict],
    model_name:   str,
    metric:       str = "f1",
) -> dict:
    if not fold_results:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT,
                    title=f"{model_name.upper()} — {metric.upper()} per Fold (no data)"))

    fold_labels = [f"Fold {fr['fold']}" for fr in fold_results]

    def _get_val(fr, split, m):
        v = fr[f"{split}_metrics"].get(m, 0)
        if v is None or (isinstance(v, float) and np.isnan(v)):
            return None
        return round(v, 4)

    train_vals = [_get_val(fr, "train", metric) for fr in fold_results]
    val_vals   = [_get_val(fr, "val",   metric) for fr in fold_results]

    # Text labels — show "N/A" for None values
    train_text = [f"{v:.4f}" if v is not None else "N/A" for v in train_vals]
    val_text   = [f"{v:.4f}" if v is not None else "N/A" for v in val_vals]

    # Replace None with 0 for plotting (Plotly skips None in line mode)
    # but keep markers visible with distinct color for N/A points
    train_plot = [v if v is not None else 0.0 for v in train_vals]
    val_plot   = [v if v is not None else 0.0 for v in val_vals]
    train_colors = ["#3b82f6" if v is not None else "#ef4444" for v in train_vals]
    val_colors   = ["#f59e0b" if v is not None else "#ef4444" for v in val_vals]

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x           = fold_labels,
        y           = train_plot,
        mode        = "lines+markers+text",
        name        = "Train",
        line        = dict(color="#3b82f6", width=2.5),
        marker      = dict(size=10, symbol="circle", color=train_colors),
        text        = train_text,
        textposition= "top center",
        textfont    = dict(size=10, color="#3b82f6"),
    ))
    fig.add_trace(go.Scatter(
        x           = fold_labels,
        y           = val_plot,
        mode        = "lines+markers+text",
        name        = "Validation",
        line        = dict(color="#f59e0b", width=2.5),
        marker      = dict(size=10, symbol="diamond", color=val_colors),
        text        = val_text,
        textposition= "bottom center",
        textfont    = dict(size=10, color="#f59e0b"),
    ))

    # Add note if any N/A values exist
    has_na = any(v is None for v in train_vals + val_vals)
    title_suffix = " (red = N/A, too few classes)" if has_na else ""

    fig.update_layout(
        **BASE_LAYOUT,
        title       = f"{model_name.upper()} — {metric.upper()} per Fold{title_suffix}",
        xaxis_title = "Fold",
        yaxis_title = metric.upper(),
        yaxis_range = [0, 1.15],
        xaxis_type  = "category",
        height      = 380,
        legend      = dict(orientation="h", y=1.08, x=0.5, xanchor="center",
                           bgcolor="rgba(0,0,0,0)"),
    )
    return _fig(fig)


def plot_loss_curves(fold_results: List[Dict], model_name: str) -> dict:
    fig = go.Figure()
    for fr in fold_results:
        hist = fr.get("loss_history", [])
        if not hist:
            continue
        fig.add_trace(go.Scatter(
            y    = hist,
            name = f"Fold {fr['fold']}",
            mode = "lines",
            line = dict(color=FOLD_PALETTE[fr["fold"] % len(FOLD_PALETTE)], width=1.5),
        ))
    fig.update_layout(
        **BASE_LAYOUT,
        title       = f"{model_name.upper()} — Training Loss per Fold",
        xaxis_title = "Epoch",
        yaxis_title = "Cross-entropy loss",
        height      = 320,
    )
    return _fig(fig)


def plot_confusion_matrix(
    y_true:      List[int],
    y_pred:      List[int],
    class_names: List[str],
    title:       str = "Confusion Matrix",
) -> dict:
    from sklearn.metrics import confusion_matrix
    cm     = confusion_matrix(y_true, y_pred, labels=list(range(len(class_names))))
    cm_pct = cm.astype(float) / (cm.sum(axis=1, keepdims=True) + 1e-9)

    text = [[f"{cm[i,j]}<br>({cm_pct[i,j]:.1%})"
             for j in range(len(class_names))]
            for i in range(len(class_names))]

    fig = go.Figure(go.Heatmap(
        z            = cm_pct,
        x            = class_names,
        y            = class_names,
        text         = text,
        texttemplate = "%{text}",
        colorscale   = "Blues",
        zmin=0, zmax=1,
        colorbar     = dict(title="Recall"),
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title       = title,
        xaxis_title = "Predicted",
        yaxis_title = "True",
        height      = 420,
    )
    return _fig(fig)


def plot_roc_curves(
    y_true:      List[int],
    y_proba:     List[List[float]],
    class_names: List[str],
    title:       str = "ROC Curves",
) -> dict:
    y_true_arr  = np.array(y_true)
    y_proba_arr = np.array(y_proba)
    n_classes   = len(class_names)
    y_bin       = label_binarize(y_true_arr, classes=list(range(n_classes)))

    fig = go.Figure()

    # Per-class curves
    for i, cls_name in enumerate(class_names):
        fpr, tpr, _ = roc_curve(y_bin[:, i], y_proba_arr[:, i])
        roc_auc     = auc(fpr, tpr)
        fig.add_trace(go.Scatter(
            x=fpr, y=tpr,
            name=f"{cls_name} (AUC={roc_auc:.3f})",
            mode="lines",
            line=dict(color=list(ATTACK_COLORS.values())[i], width=2),
        ))

    # Macro average
    all_fpr    = np.unique(np.concatenate([
        roc_curve(y_bin[:, i], y_proba_arr[:, i])[0]
        for i in range(n_classes)
    ]))
    mean_tpr   = np.zeros_like(all_fpr)
    for i in range(n_classes):
        fpr, tpr, _ = roc_curve(y_bin[:, i], y_proba_arr[:, i])
        mean_tpr   += np.interp(all_fpr, fpr, tpr)
    mean_tpr  /= n_classes
    macro_auc  = auc(all_fpr, mean_tpr)
    fig.add_trace(go.Scatter(
        x=all_fpr, y=mean_tpr,
        name=f"Macro avg (AUC={macro_auc:.3f})",
        mode="lines",
        line=dict(color="#ffffff", width=3, dash="dash"),
    ))
    fig.add_trace(go.Scatter(
        x=[0,1], y=[0,1], mode="lines",
        line=dict(color="#6b7280", dash="dot", width=1),
        showlegend=False,
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title       = title,
        xaxis_title = "False Positive Rate",
        yaxis_title = "True Positive Rate",
        xaxis_range=[0, 1],
        yaxis_range=[0, 1.02],
        height      = 460,
    )
    return _fig(fig)


def plot_pr_curves(
    y_true:      List[int],
    y_proba:     List[List[float]],
    class_names: List[str],
    title:       str = "Precision-Recall Curves",
) -> dict:
    y_true_arr  = np.array(y_true)
    y_proba_arr = np.array(y_proba)
    n_classes   = len(class_names)
    y_bin       = label_binarize(y_true_arr, classes=list(range(n_classes)))

    fig = go.Figure()
    for i, cls_name in enumerate(class_names):
        prec, rec, _ = precision_recall_curve(y_bin[:, i], y_proba_arr[:, i])
        pr_auc       = auc(rec, prec)
        fig.add_trace(go.Scatter(
            x=rec, y=prec,
            name=f"{cls_name} (AUC={pr_auc:.3f})",
            mode="lines",
            line=dict(color=list(ATTACK_COLORS.values())[i], width=2),
        ))
    fig.update_layout(
        **BASE_LAYOUT,
        title       = title,
        xaxis_title = "Recall",
        yaxis_title = "Precision",
        xaxis_range=[0, 1],
        yaxis_range=[0, 1.02],
        height      = 420,
    )
    return _fig(fig)


def plot_calibration_curve(
    y_true:      List[int],
    y_proba:     List[List[float]],
    class_names: List[str],
    n_bins:      int = 10,
    title:       str = "Calibration Curves (Reliability Diagram)",
) -> dict:
    from sklearn.calibration import calibration_curve
    y_true_arr  = np.array(y_true)
    y_proba_arr = np.array(y_proba)
    n_classes   = len(class_names)
    y_bin       = label_binarize(y_true_arr, classes=list(range(n_classes)))

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=[0,1], y=[0,1], mode="lines",
        name="Perfectly calibrated",
        line=dict(color="#6b7280", dash="dash", width=1),
    ))
    for i, cls_name in enumerate(class_names):
        try:
            frac_pos, mean_pred = calibration_curve(
                y_bin[:, i], y_proba_arr[:, i], n_bins=n_bins, strategy="uniform"
            )
            fig.add_trace(go.Scatter(
                x=mean_pred, y=frac_pos,
                name=cls_name,
                mode="lines+markers",
                line=dict(color=list(ATTACK_COLORS.values())[i], width=2),
                marker=dict(size=7),
            ))
        except Exception:
            pass
    fig.update_layout(
        **BASE_LAYOUT,
        title       = title,
        xaxis_title = "Mean predicted probability",
        yaxis_title = "Fraction of positives",
        xaxis_range=[0, 1],
        yaxis_range=[0, 1.02],
        height      = 420,
    )
    return _fig(fig)


def plot_metrics_table(
    cv_results:    Dict[str, Any],   # {model_name: CVResult}
    table_type:    str = "cv",       # "cv" | "test"
) -> dict:
    """
    Render a Plotly Table figure for either:
      - CV results (mean ± std across folds per model)
      - Test results (final calibrated model scores)
    """
    METRICS = ["accuracy","f1","precision","recall","roc_auc"]
    rows    = []
    headers = ["Model"] + [m.upper() for m in METRICS]

    for model_name, result in cv_results.items():
        if table_type == "cv":
            agg = result.cv_val_agg
            row = [model_name.upper()] + [
                f"{agg.get(m,{}).get('mean',float('nan')):.4f} ± {agg.get(m,{}).get('std',float('nan')):.4f}"
                for m in METRICS
            ]
        else:
            tm = result.test_metrics
            row = [model_name.upper()] + [f"{tm.get(m,float('nan')):.4f}" for m in METRICS]
        rows.append(row)

    cols_data = list(zip(*rows)) if rows else [[] for _ in headers]
    fig = go.Figure(go.Table(
        header=dict(
            values    = headers,
            fill_color= "#1e3a5f",
            font      = dict(color="white", size=13),
            align     = "center",
            height    = 36,
        ),
        cells=dict(
            values      = cols_data,
            fill_color  = [["#1a1d2e","#111827"] * (len(rows)//2 + 1)] * len(headers),
            font        = dict(color=TEXT_CLR, size=12),
            align       = ["left"] + ["center"] * len(METRICS),
            height      = 32,
        ),
    ))
    title_map = {
        "cv":   "Table 1 — Rolling CV Results (mean ± std, weighted)",
        "test": "Table 2 — Final Model Test Results (weighted)",
    }
    fig.update_layout(**BASE_LAYOUT, title=title_map.get(table_type, ""),
                       height=max(200, len(rows) * 36 + 100))
    return _fig(fig)


def plot_multi_model_roc(cv_results: Dict[str, Any], split: str = "test") -> dict:
    """Overlay ROC curves for all models on the same axes."""
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=[0,1], y=[0,1], mode="lines",
                              line=dict(color="#6b7280",dash="dot",width=1),
                              showlegend=False))
    for model_name, result in cv_results.items():
        y_true  = np.array(result.y_true_test)
        y_proba = np.array(result.y_proba_test)
        n_cls   = y_proba.shape[1]
        y_bin   = label_binarize(y_true, classes=list(range(n_cls)))
        # Macro AUC
        all_fpr  = np.linspace(0, 1, 200)
        mean_tpr = np.zeros(200)
        for i in range(n_cls):
            fpr, tpr, _ = roc_curve(y_bin[:, i], y_proba[:, i])
            mean_tpr   += np.interp(all_fpr, fpr, tpr)
        mean_tpr /= n_cls
        macro_auc = auc(all_fpr, mean_tpr)
        fig.add_trace(go.Scatter(
            x=all_fpr, y=mean_tpr,
            name=f"{model_name.upper()} (AUC={macro_auc:.3f})",
            mode="lines",
            line=dict(color=MODEL_COLORS.get(model_name,"#6b7280"), width=2.5),
        ))
    fig.update_layout(
        **BASE_LAYOUT,
        title="ROC — All Models (Macro Average)", height=440,
        xaxis_title="FPR", yaxis_title="TPR",
        xaxis_range=[0, 1],
        yaxis_range=[0, 1.02],
    )
    return _fig(fig)


# ═══════════════════════════════════════════════════════════════════
# OPTUNA HPO PLOTS
# ═══════════════════════════════════════════════════════════════════

def plot_optuna_history(trials_df: pd.DataFrame, objective: str = "f1") -> dict:
    if trials_df.empty or objective not in trials_df.columns:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT, title="No HPO data yet"))

    df = trials_df.dropna(subset=[objective]).copy()
    df["best_so_far"] = df[objective].cummax()

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df["trial"], y=df[objective],
        mode="markers", name="Trial value",
        marker=dict(color="#3b82f6", size=6, opacity=0.6),
    ))
    fig.add_trace(go.Scatter(
        x=df["trial"], y=df["best_so_far"],
        mode="lines", name="Best so far",
        line=dict(color="#10b981", width=2.5),
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title       = f"Optimisation History — {objective.upper()}",
        xaxis_title = "Trial",
        yaxis_title = objective.upper(),
        height      = 340,
    )
    return _fig(fig)


def plot_param_importance(importance_df: pd.DataFrame) -> dict:
    if importance_df is None or importance_df.empty:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT, title="No importance data"))
    df = importance_df.sort_values("importance", ascending=True)
    fig = go.Figure(go.Bar(
        x=df["importance"], y=df["parameter"],
        orientation="h",
        marker_color="#8b5cf6",
        hovertemplate="<b>%{y}</b><br>Importance: %{x:.4f}<extra></extra>",
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title  = "Hyperparameter Importance (fANOVA)",
        height = max(300, len(df) * 28 + 80),
    )
    return _fig(fig)


def plot_parallel_coordinates(
    trials_df:  pd.DataFrame,
    objective:  str = "f1",
    n_params:   int = 8,
) -> dict:
    if trials_df.empty:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT, title="No HPO data yet"))

    param_cols = [c for c in trials_df.columns
                  if c not in ("trial","state") and c != objective][:n_params]
    all_cols   = param_cols + ([objective] if objective in trials_df.columns else [])

    df = trials_df[all_cols].dropna()
    dims = []
    for col in all_cols:
        vals = df[col]
        if vals.dtype == object or str(vals.dtype) == "bool":
            cats   = vals.astype(str).unique().tolist()
            c_map  = {v: i for i, v in enumerate(cats)}
            dims.append(dict(
                label      = col,
                values     = vals.astype(str).map(c_map).tolist(),
                tickvals   = list(c_map.values()),
                ticktext   = list(c_map.keys()),
            ))
        else:
            dims.append(dict(label=col, values=vals.tolist()))

    line_color = df[objective].tolist() if objective in df.columns else None
    fig = go.Figure(go.Parcoords(
        line       = dict(color=line_color, colorscale="Viridis",
                          showscale=True,
                          colorbar=dict(title=objective.upper())),
        dimensions = dims,
    ))
    fig.update_layout(**BASE_LAYOUT, title="HPO Parallel Coordinates", height=420)
    return _fig(fig)


def plot_pareto_front(
    pareto_df:   pd.DataFrame,
    objectives:  List[str],
) -> dict:
    if pareto_df is None or pareto_df.empty or len(objectives) < 2:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT, title="No Pareto data"))

    obj0, obj1 = objectives[0], objectives[1]
    if obj0 not in pareto_df.columns or obj1 not in pareto_df.columns:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT, title="Missing objective columns"))

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x         = pareto_df[obj0],
        y         = pareto_df[obj1],
        mode      = "markers+text",
        text      = pareto_df["trial"].astype(str),
        textposition="top center",
        marker    = dict(size=10, color="#f59e0b",
                         line=dict(width=1.5, color="white")),
        name      = "Pareto front",
        hovertemplate=f"{obj0}: %{{x:.4f}}<br>{obj1}: %{{y:.4f}}<br>Trial %{{text}}<extra></extra>",
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title       = f"Pareto Front — {obj0.upper()} vs {obj1.upper()}",
        xaxis_title = obj0.upper(),
        yaxis_title = obj1.upper(),
        height      = 440,
    )
    return _fig(fig)


def plot_slice(trials_df: pd.DataFrame, param: str, objective: str = "f1") -> dict:
    if trials_df.empty or param not in trials_df.columns:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT, title=f"No data for {param}"))

    df = trials_df[[param, objective]].dropna()
    if df[param].dtype == object or str(df[param].dtype) == "bool":
        fig = px.box(df, x=param, y=objective)
    else:
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=df[param], y=df[objective], mode="markers",
            marker=dict(color="#3b82f6", size=7, opacity=0.7),
        ))
    fig.update_layout(
        **BASE_LAYOUT,
        title       = f"Slice — {param} vs {objective.upper()}",
        xaxis_title = param,
        yaxis_title = objective.upper(),
        height      = 340,
    )
    return _fig(fig)


# ═══════════════════════════════════════════════════════════════════
# FEATURE IMPORTANCE
# ═══════════════════════════════════════════════════════════════════

def plot_xgb_feature_importance(importance: Dict[str, float]) -> dict:
    if not importance:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT, title="No XGBoost importances"))
    df  = pd.DataFrame(list(importance.items()), columns=["feature","importance"])
    df  = df.sort_values("importance", ascending=True).tail(30)
    fig = go.Figure(go.Bar(
        x=df["importance"], y=df["feature"],
        orientation="h",
        marker=dict(
            color=df["importance"],
            colorscale="Viridis",
            colorbar=dict(title="Importance"),
        ),
        hovertemplate="<b>%{y}</b><br>Importance: %{x:.5f}<extra></extra>",
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title  = "XGBoost Feature Importance",
        height = max(400, len(df) * 18),
    )
    return _fig(fig)


# ═══════════════════════════════════════════════════════════════════
# SPEARMAN CORRELATION (separate from existing Pearson/Kendall)
# ═══════════════════════════════════════════════════════════════════

def plot_spearman_heatmap(
    corr_matrix: pd.DataFrame,
    title: str = "Spearman Correlation Heatmap",
) -> dict:
    """Identical layout to plot_correlation_heatmap — just a named alias."""
    return plot_correlation_heatmap(corr_matrix, title)


# ═══════════════════════════════════════════════════════════════════
# OPTUNA ADDITIONAL PLOTS
# ═══════════════════════════════════════════════════════════════════

def plot_optuna_contour(
    trials_df: pd.DataFrame,
    param_x:   str,
    param_y:   str,
    objective: str = "f1",
) -> dict:
    """Contour plot of objective value over two hyperparameter dimensions."""
    if trials_df.empty:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT, title="No HPO data"))

    df = trials_df[[param_x, param_y, objective]].dropna()
    if df.empty or df[param_x].dtype == object or df[param_y].dtype == object:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT,
                    title=f"Contour — {param_x} vs {param_y} (non-numeric params)"))

    fig = go.Figure(go.Contour(
        x=df[param_x], y=df[param_y], z=df[objective],
        colorscale="Viridis",
        colorbar=dict(title=objective.upper()),
        contours=dict(coloring="heatmap", showlabels=True),
    ))
    fig.add_trace(go.Scatter(
        x=df[param_x], y=df[param_y],
        mode="markers",
        marker=dict(color=df[objective], colorscale="Viridis",
                    size=7, line=dict(width=1, color="white")),
        showlegend=False,
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title=f"Contour — {param_x} vs {param_y} ({objective.upper()})",
        xaxis_title=param_x, yaxis_title=param_y, height=420,
    )
    return _fig(fig)


def plot_optuna_edf(
    trials_df:  pd.DataFrame,
    objective:  str = "f1",
) -> dict:
    """Empirical Distribution Function of the objective across trials."""
    if trials_df.empty or objective not in trials_df.columns:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT, title="No HPO data"))

    vals = trials_df[objective].dropna().sort_values().values
    cdf  = np.arange(1, len(vals) + 1) / len(vals)

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=vals, y=cdf, mode="lines",
        line=dict(color="#3b82f6", width=2.5),
        name="EDF",
        hovertemplate=f"{objective.upper()}: %{{x:.4f}}<br>CDF: %{{y:.3f}}<extra></extra>",
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title=f"Empirical Distribution Function — {objective.upper()}",
        xaxis_title=objective.upper(), yaxis_title="Cumulative probability",
        height=360,
    )
    return _fig(fig)


def plot_optuna_intermediate_values(
    trials_df:  pd.DataFrame,
    objective:  str = "f1",
) -> dict:
    """
    Intermediate values chart — shows objective value reported at each fold
    inside each trial (proxy: per-trial value, one point per trial).
    """
    if trials_df.empty or objective not in trials_df.columns:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT, title="No HPO data"))

    df = trials_df[["trial", objective]].dropna()

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df["trial"], y=df[objective],
        mode="lines+markers",
        line=dict(color="#3b82f6", width=1.5),
        marker=dict(size=5, color=df[objective],
                    colorscale="Viridis", showscale=True,
                    colorbar=dict(title=objective.upper())),
        name="Trial value",
        hovertemplate="Trial %{x}<br>" + objective.upper() + ": %{y:.4f}<extra></extra>",
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title=f"Intermediate Values — {objective.upper()} per Trial",
        xaxis_title="Trial", yaxis_title=objective.upper(), height=360,
    )
    return _fig(fig)


def plot_optuna_rank(
    trials_df:  pd.DataFrame,
    objective:  str = "f1",
) -> dict:
    """
    Rank plot — ranks each trial by objective value and plots rank vs value.
    Useful for seeing how quickly the search finds good configurations.
    """
    if trials_df.empty or objective not in trials_df.columns:
        return _fig(go.Figure().update_layout(**BASE_LAYOUT, title="No HPO data"))

    df = trials_df[["trial", objective]].dropna().copy()
    df["rank"] = df[objective].rank(ascending=False, method="first").astype(int)

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df["rank"], y=df[objective],
        mode="markers",
        marker=dict(
            size=8, color=df["trial"],
            colorscale="Plasma", showscale=True,
            colorbar=dict(title="Trial #"),
            line=dict(width=0.5, color="white"),
        ),
        hovertemplate="Rank %{x}<br>" + objective.upper() + ": %{y:.4f}<br>Trial %{marker.color}<extra></extra>",
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title=f"Rank Plot — {objective.upper()}",
        xaxis_title="Rank (1 = best)", yaxis_title=objective.upper(), height=360,
    )
    return _fig(fig)
