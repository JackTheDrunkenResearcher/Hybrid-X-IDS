"""
server.py — FastAPI backend for the UAV IDS dashboard.

Endpoints
---------
POST /api/upload              Upload synthetic CSV dataset
POST /api/preprocess          Run online preprocessing pipeline
GET  /api/preprocess/plots    Get all preprocessing diagnostic plots
POST /api/train               Start rolling CV training for all models
GET  /api/stream/{run_id}     SSE stream of live training events
POST /api/hpo                 Start Optuna HPO for a model
GET  /api/results/{run_id}    Get full results (metrics tables + plots)
GET  /api/status/{run_id}     Poll run status
DELETE /api/run/{run_id}      Cancel a run
"""

from __future__ import annotations

import asyncio
import io
import json
import logging
import os
import threading
import time
import traceback
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="UAV IDS — Intrusion Detection API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], allow_methods=["*"], allow_headers=["*"],
)

# ── in-memory stores ──────────────────────────────────────────────────────────
DATASETS:   Dict[str, pd.DataFrame]  = {}
PIPELINES:  Dict[str, Any]           = {}   # run_id → OnlinePreprocessingPipeline
RUNS:       Dict[str, "RunState"]    = {}


@dataclass
class RunState:
    run_id:      str
    status:      str            # queued | running | done | error | cancelled
    events:      asyncio.Queue
    result:      Optional[dict]
    error:       Optional[str]
    progress:    int
    started_at:  float
    cancel_flag: threading.Event


# ─────────────────────────────────────────────────────────────────────────────
# Pydantic request models
# ─────────────────────────────────────────────────────────────────────────────

class PreprocessRequest(BaseModel):
    dataset_id:              str
    window_size:             int   = 5000
    step_size:               int   = 2500
    n_folds:                 int   = 5
    gap:                     int   = 0
    test_frac:               float = 0.20
    power_exponents:         List[float] = [0.5, 2.0]
    rfe_n_estimators:        int   = 12
    rfe_max_depth:           int   = 15
    rfe_min_samples_leaf:    int   = 3
    rfe_min_samples_split:   int   = 3
    rfe_importance_threshold:float = 0.025
    rfe_scoring:             str   = "roc_auc"
    categorical_unique_threshold: int = 20


class TrainRequest(BaseModel):
    pipeline_id:    str
    llm_provider:   str   = "gpt-4o"    # claude | gpt-4o | qwen | llama
    embed_cache_dir:str   = "./embed_cache"
    device:         str   = "auto"
    calibration:    str   = "isotonic"
    models:         List[str] = ["mlp", "cnn", "lstm", "xgb"]
    # per-model overrides (optional, Optuna fills best params if HPO was run)
    mlp_params:     Dict  = {}
    cnn_params:     Dict  = {}
    lstm_params:    Dict  = {}
    xgb_params:     Dict  = {}


class HPORequest(BaseModel):
    pipeline_id:    str
    model_name:     str   = "mlp"
    mode:           str   = "uni"       # uni | multi
    n_trials:       int   = 40
    timeout_s:      Optional[float] = None
    sampler:        str   = "tpe"
    pruner:         str   = "hyperband"
    objective:      str   = "f1"
    objectives:     List[str] = ["f1", "roc_auc"]
    fast_n_folds:   int   = 2
    fast_epochs:    int   = 10
    llm_provider:   str   = "gpt-4o"
    device:         str   = "auto"


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _get_device(device: str) -> str:
    if device == "auto":
        try:
            import torch
            if torch.cuda.is_available():    return "cuda"
            if torch.backends.mps.is_available(): return "mps"
        except ImportError:
            pass
        return "cpu"
    return device


def _make_run(loop) -> RunState:
    rid = str(uuid.uuid4())[:8]
    state = RunState(
        run_id      = rid,
        status      = "queued",
        events      = asyncio.Queue(),
        result      = None,
        error       = None,
        progress    = 0,
        started_at  = time.time(),
        cancel_flag = threading.Event(),
    )
    RUNS[rid] = state
    return state


def _emit(state: RunState, loop, event_type: str, data: Any):
    payload = json.dumps({"type": event_type, "data": data, "ts": time.time()},
                          default=str)
    try:
        asyncio.run_coroutine_threadsafe(state.events.put(payload), loop)
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
# Upload
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/api/upload")
async def upload_dataset(file: UploadFile = File(...)):
    content = await file.read()
    try:
        df = pd.read_csv(io.BytesIO(content))
    except Exception as e:
        raise HTTPException(400, f"Cannot parse CSV: {e}")
    ds_id = str(uuid.uuid4())[:8]
    DATASETS[ds_id] = df
    return {
        "dataset_id": ds_id,
        "shape":      list(df.shape),
        "columns":    df.columns.tolist(),
        "preview":    df.head(5).to_dict(orient="records"),
    }


# ─────────────────────────────────────────────────────────────────────────────
# Preprocessing
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/api/preprocess")
async def run_preprocess(req: PreprocessRequest):
    if req.dataset_id not in DATASETS:
        raise HTTPException(404, "Dataset not found. Upload first.")

    from preprocessing.pipeline import OnlinePreprocessingPipeline, PreprocessingConfig

    cfg = PreprocessingConfig(
        window_size              = req.window_size,
        step_size                = req.step_size,
        n_folds                  = req.n_folds,
        gap                      = req.gap,
        test_frac                = req.test_frac,
        power_exponents          = req.power_exponents,
        rfe_n_estimators         = req.rfe_n_estimators,
        rfe_max_depth            = req.rfe_max_depth,
        rfe_min_samples_leaf     = req.rfe_min_samples_leaf,
        rfe_min_samples_split    = req.rfe_min_samples_split,
        rfe_importance_threshold = req.rfe_importance_threshold,
        rfe_scoring              = req.rfe_scoring,
        categorical_unique_threshold = req.categorical_unique_threshold,
    )

    df  = DATASETS[req.dataset_id].copy()
    try:
        pipeline = OnlinePreprocessingPipeline()
        pipeline.fit(df, cfg)
    except Exception as e:
        raise HTTPException(500, f"Preprocessing failed: {traceback.format_exc()}")

    pipe_id = str(uuid.uuid4())[:8]
    PIPELINES[pipe_id] = pipeline

    art = pipeline.artifacts
    return {
        "pipeline_id":    pipe_id,
        "n_train":        art.n_train_rows,
        "n_test":         art.n_test_rows,
        "n_features":     art.n_features_final,
        "selected":       art.selected_features,
        "n_folds":        len(pipeline.folds),
        "folds":          pipeline.folds,
        "label_map":      art.label_encoding_map,
        "class_names":    pipeline.class_names,
        "duplicates":     art.duplicate_count,
        "missing":        art.missing_values,
        "shape_raw":      art.shape_raw,
    }


@app.get("/api/preprocess/{pipeline_id}/plots")
async def get_preprocess_plots(pipeline_id: str):
    if pipeline_id not in PIPELINES:
        raise HTTPException(404, "Pipeline not found.")

    from diagnostics.plots import (
        plot_class_distribution, plot_density_grid, plot_histogram_grid,
        plot_boxplot_grid, plot_correlation_heatmap, plot_ip_freq_distribution,
        plot_rfe_importance, plot_rolling_folds,
    )
    p   = PIPELINES[pipeline_id]
    art = p.artifacts

    plots = {}

    plots["class_distribution"] = plot_class_distribution(
        art.label_counts, art.label_pct, p.class_names,
    )
    if art.density_data:
        plots["density"] = plot_density_grid(art.density_data, p.class_names)
    if art.histogram_data:
        plots["histograms"] = plot_histogram_grid(art.histogram_data)
    if art.boxplot_data:
        plots["boxplots"] = plot_boxplot_grid(art.boxplot_data)
    if art.pearson_before is not None:
        plots["pearson_before"] = plot_correlation_heatmap(
            art.pearson_before, "Pearson Correlation — Before Feature Selection"
        )
    if art.kendall_before is not None:
        plots["kendall_before"] = plot_correlation_heatmap(
            art.kendall_before, "Kendall Correlation — Before Feature Selection"
        )
    if art.srcaddr_freq_dist:
        plots["ip_freq"] = plot_ip_freq_distribution(
            art.srcaddr_freq_dist, art.dstaddr_freq_dist
        )
    if art.rfe_importances:
        plots["rfe_importance"] = plot_rfe_importance(
            art.rfe_importances, art.rfe_importance_threshold
            if hasattr(art, "rfe_importance_threshold") else 0.025
        )
    if art.folds:
        plots["rolling_folds"] = plot_rolling_folds(
            art.folds, art.n_train_rows, art.n_test_rows
        )
    if art.pearson_after is not None:
        plots["pearson_after"] = plot_correlation_heatmap(
            art.pearson_after, "Pearson Correlation — After Feature Selection"
        )
    if art.kendall_after is not None:
        plots["kendall_after"] = plot_correlation_heatmap(
            art.kendall_after, "Kendall Correlation — After Feature Selection"
        )

    return plots


# ─────────────────────────────────────────────────────────────────────────────
# Training
# ─────────────────────────────────────────────────────────────────────────────

def _train_job(state: RunState, req: TrainRequest, loop):
    from models.embeddings import WindowEmbedder, EmbeddingConfig
    from models.networks import (
        build_mlp, build_cnn, build_lstm, XGBoostModel,
        MLPConfig, CNNConfig, LSTMConfig, XGBConfig,
    )
    from training.rolling_cv import RollingCVTrainer

    emit = lambda t, d: _emit(state, loop, t, d)

    try:
        state.status = "running"
        pipeline = PIPELINES.get(req.pipeline_id)
        if pipeline is None:
            raise ValueError("Pipeline not found.")

        device = _get_device(req.device)
        emit("status", {"message": f"Using device: {device}"})

        # Build embedder
        embed_cfg = EmbeddingConfig(
            provider  = req.llm_provider,
            cache_dir = req.embed_cache_dir,
        )
        embedder = WindowEmbedder(embed_cfg)
        emit("status", {"message": f"LLM embedder ready: {req.llm_provider}"})

        n_feat   = pipeline.n_features
        n_cls    = pipeline.n_classes
        emb_dim  = embedder.embed_dim

        # Model configs (use HPO best params if provided, else defaults)
        model_configs = {}
        model_builders = {}

        if "mlp" in req.models:
            mlp_cfg = MLPConfig(**(req.mlp_params or {}))
            model_configs["mlp"]  = mlp_cfg
            model_builders["mlp"] = lambda cfg: build_mlp(n_feat, emb_dim, n_cls, cfg, device)

        if "cnn" in req.models:
            cnn_cfg = CNNConfig(**(req.cnn_params or {}))
            model_configs["cnn"]  = cnn_cfg
            model_builders["cnn"] = lambda cfg: build_cnn(n_feat, emb_dim, n_cls, cfg, device)

        if "lstm" in req.models:
            lstm_cfg = LSTMConfig(**(req.lstm_params or {}))
            model_configs["lstm"]  = lstm_cfg
            model_builders["lstm"] = lambda cfg: build_lstm(n_feat, emb_dim, n_cls, cfg, device)

        if "xgb" in req.models:
            xgb_cfg = XGBConfig(**(req.xgb_params or {}))
            model_configs["xgb"]  = xgb_cfg
            model_builders["xgb"] = lambda cfg: XGBoostModel(n_cls, cfg)

        trainer = RollingCVTrainer(
            pipeline    = pipeline,
            embedder    = embedder,
            event_cb    = emit,
            device      = device,
            calibration = req.calibration,
        )

        results = trainer.run_all(model_configs, model_builders)

        # Build result plots
        from diagnostics.plots import (
            plot_metrics_table, plot_confusion_matrix, plot_roc_curves,
            plot_pr_curves, plot_calibration_curve, plot_cv_metrics_per_fold,
            plot_loss_curves, plot_multi_model_roc, plot_xgb_feature_importance,
        )

        class_names = pipeline.class_names
        plots = {}

        # Metric tables
        plots["table_cv"]   = plot_metrics_table(results, "cv")
        plots["table_test"] = plot_metrics_table(results, "test")

        for model_name, res in results.items():
            pfx = model_name
            fr_list = [
                {"fold": fr.fold,
                 "train_metrics": fr.train_metrics,
                 "val_metrics": fr.val_metrics,
                 "loss_history": fr.loss_history}
                for fr in res.fold_results
            ]

            plots[f"{pfx}_cv_f1"]  = plot_cv_metrics_per_fold(fr_list, model_name, "f1")
            plots[f"{pfx}_cv_auc"] = plot_cv_metrics_per_fold(fr_list, model_name, "roc_auc")
            if any(fr.loss_history for fr in res.fold_results):
                plots[f"{pfx}_loss"] = plot_loss_curves(fr_list, model_name)

            plots[f"{pfx}_cm_test"] = plot_confusion_matrix(
                res.y_true_test, res.y_pred_test, class_names,
                f"{model_name.upper()} — Confusion Matrix (Test)"
            )
            plots[f"{pfx}_roc_test"] = plot_roc_curves(
                res.y_true_test, res.y_proba_test, class_names,
                f"{model_name.upper()} — ROC Curves (Test)"
            )
            plots[f"{pfx}_pr_test"] = plot_pr_curves(
                res.y_true_test, res.y_proba_test, class_names,
                f"{model_name.upper()} — PR Curves (Test)"
            )
            plots[f"{pfx}_cal_test"] = plot_calibration_curve(
                res.y_true_test, res.y_proba_test, class_names,
                title=f"{model_name.upper()} — Calibration (Test)"
            )
            if model_name == "xgb" and res.feature_importance:
                plots["xgb_importance"] = plot_xgb_feature_importance(res.feature_importance)

        if len(results) > 1:
            plots["all_roc"] = plot_multi_model_roc(results, "test")

        # Build serialisable result summary
        summary = {}
        for name, res in results.items():
            summary[name] = {
                "cv_val_agg":   {k: v for k, v in res.cv_val_agg.items()},
                "test_metrics": res.test_metrics,
                "elapsed_s":    res.elapsed_total_s,
            }

        state.result = {"summary": summary, "plots": plots}
        state.status = "done"
        state.progress = 100
        emit("done", {"summary": summary})

    except Exception as e:
        state.status = "error"
        state.error  = traceback.format_exc()
        emit("error", {"message": str(e), "traceback": state.error})
    finally:
        asyncio.run_coroutine_threadsafe(state.events.put("__DONE__"), loop)


@app.post("/api/train")
async def start_training(req: TrainRequest):
    if req.pipeline_id not in PIPELINES:
        raise HTTPException(404, "Pipeline not found. Run preprocessing first.")

    loop  = asyncio.get_event_loop()
    state = _make_run(loop)
    t = threading.Thread(target=_train_job, args=(state, req, loop), daemon=True)
    t.start()
    return {"run_id": state.run_id, "status": "queued"}


# ─────────────────────────────────────────────────────────────────────────────
# HPO
# ─────────────────────────────────────────────────────────────────────────────

def _hpo_job(state: RunState, req: HPORequest, loop):
    from models.embeddings import WindowEmbedder, EmbeddingConfig
    from training.optuna_engine import OptunaConfig, run_optuna
    from diagnostics.plots import (
        plot_optuna_history, plot_param_importance,
        plot_parallel_coordinates, plot_pareto_front, plot_slice,
    )

    emit = lambda t, d: _emit(state, loop, t, d)

    try:
        state.status = "running"
        pipeline = PIPELINES.get(req.pipeline_id)
        if pipeline is None:
            raise ValueError("Pipeline not found.")

        device = _get_device(req.device)
        embed_cfg = EmbeddingConfig(provider=req.llm_provider)
        embedder  = WindowEmbedder(embed_cfg)

        optuna_cfg = OptunaConfig(
            mode        = req.mode,
            model_name  = req.model_name,
            n_trials    = req.n_trials,
            timeout_s   = req.timeout_s,
            sampler     = req.sampler,
            pruner      = req.pruner,
            objective   = req.objective,
            objectives  = req.objectives,
            fast_n_folds= req.fast_n_folds,
            fast_epochs = req.fast_epochs,
        )

        hpo_result = run_optuna(
            optuna_cfg  = optuna_cfg,
            pipeline    = pipeline,
            embedder    = embedder,
            device      = device,
            event_cb    = emit,
        )

        # Build HPO plots
        plots = {}
        primary_obj = req.objective if req.mode == "uni" else req.objectives[0]

        plots["history"]   = plot_optuna_history(hpo_result.all_trials_df, primary_obj)
        plots["importance"]= plot_param_importance(hpo_result.importance_df)
        plots["parallel"]  = plot_parallel_coordinates(
            hpo_result.all_trials_df, primary_obj
        )
        if req.mode == "multi" and hpo_result.pareto_front is not None:
            plots["pareto"] = plot_pareto_front(hpo_result.pareto_front, req.objectives)

        for param in (hpo_result.importance_df["parameter"].tolist()[:5]
                      if hpo_result.importance_df is not None else []):
            plots[f"slice_{param}"] = plot_slice(
                hpo_result.all_trials_df, param, primary_obj
            )

        state.result = {
            "best_params":  hpo_result.best_params,
            "best_values":  hpo_result.best_values,
            "n_trials":     hpo_result.n_trials_done,
            "elapsed_s":    hpo_result.elapsed_s,
            "pareto":       hpo_result.pareto_front.to_dict("records")
                            if hpo_result.pareto_front is not None else None,
            "trials_df":    hpo_result.all_trials_df.to_dict("records"),
            "plots":        plots,
        }
        state.status = "done"
        state.progress = 100
        emit("done", state.result)

    except Exception as e:
        state.status = "error"
        state.error  = traceback.format_exc()
        emit("error", {"message": str(e), "traceback": state.error})
    finally:
        asyncio.run_coroutine_threadsafe(state.events.put("__DONE__"), loop)


@app.post("/api/hpo")
async def start_hpo(req: HPORequest):
    if req.pipeline_id not in PIPELINES:
        raise HTTPException(404, "Pipeline not found.")
    loop  = asyncio.get_event_loop()
    state = _make_run(loop)
    t = threading.Thread(target=_hpo_job, args=(state, req, loop), daemon=True)
    t.start()
    return {"run_id": state.run_id, "status": "queued"}


# ─────────────────────────────────────────────────────────────────────────────
# SSE stream
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/api/stream/{run_id}")
async def stream_events(run_id: str):
    state = RUNS.get(run_id)
    if not state:
        raise HTTPException(404, "Run not found.")

    async def generator():
        while True:
            try:
                msg = await asyncio.wait_for(state.events.get(), timeout=25.0)
            except asyncio.TimeoutError:
                yield "event: ping\ndata: {}\n\n"
                continue
            if msg == "__DONE__":
                yield "event: done\ndata: {}\n\n"
                break
            try:
                parsed = json.loads(msg)
                evt    = parsed.get("type", "message")
                data   = json.dumps(parsed.get("data", {}), default=str)
                yield f"event: {evt}\ndata: {data}\n\n"
            except Exception:
                yield f"data: {msg}\n\n"

    return StreamingResponse(generator(), media_type="text/event-stream",
                              headers={"Cache-Control":"no-cache",
                                       "X-Accel-Buffering":"no"})


@app.get("/api/status/{run_id}")
def get_status(run_id: str):
    state = RUNS.get(run_id)
    if not state:
        raise HTTPException(404, "Run not found.")
    return {
        "run_id":    run_id,
        "status":    state.status,
        "progress":  state.progress,
        "result":    state.result,
        "error":     state.error,
        "elapsed_s": time.time() - state.started_at,
    }


@app.get("/api/results/{run_id}")
def get_results(run_id: str):
    state = RUNS.get(run_id)
    if not state:
        raise HTTPException(404, "Run not found.")
    if state.status != "done":
        raise HTTPException(400, f"Run not done yet (status: {state.status})")
    return state.result


@app.delete("/api/run/{run_id}")
def cancel_run(run_id: str):
    state = RUNS.get(run_id)
    if not state:
        raise HTTPException(404, "Run not found.")
    state.cancel_flag.set()
    return {"cancelled": True}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=False)
