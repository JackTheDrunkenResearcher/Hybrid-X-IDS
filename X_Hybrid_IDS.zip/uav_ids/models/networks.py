"""
models/networks.py

Four classifiers for UAV intrusion detection:

  MLPClassifier    — residual feedforward blocks + LLM embedding injection
  CNN1DClassifier  — dilated causal convolutions + LLM embedding injection
  LSTMClassifier   — bidirectional LSTM + LLM embedding injection
  XGBoostModel     — XGBoost (no LLM embedding)

All neural models:
  - Accept (X_flat, embed) at inference time
  - Output class probabilities (softmax, n_classes)
  - Probability calibration is handled by rolling_cv._train_torch /
    _train_xgb using our own _fit_calibrators / _apply_calibrators,
    which avoids the sklearn CalibratedClassifierCV(cv=N) crash when
    a fold contains only a subset of the full class set.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.base import BaseEstimator, ClassifierMixin
from sklearn.preprocessing import label_binarize

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Hyperparameter configs (Optuna fills these in)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class MLPConfig:
    n_layers:       int   = 3
    hidden_dim:     int   = 128
    dropout:        float = 0.2
    activation:     str   = "relu"       # relu | gelu | silu
    use_batchnorm:  bool  = True
    lr:             float = 1e-3
    batch_size:     int   = 64
    epochs:         int   = 30
    proj_dim:       int   = 64           # LLM embed projection dim
    calibration:    str   = "isotonic"   # isotonic | sigmoid


@dataclass
class CNNConfig:
    n_blocks:       int   = 3
    out_channels:   int   = 64
    kernel_size:    int   = 3
    dilation_base:  int   = 2
    use_residual:   bool  = True
    dropout:        float = 0.2
    lr:             float = 1e-3
    batch_size:     int   = 64
    epochs:         int   = 30
    proj_dim:       int   = 64
    seq_len:        int   = 16           # window length for CNN view
    calibration:    str   = "isotonic"


@dataclass
class LSTMConfig:
    n_layers:       int   = 2
    hidden_size:    int   = 128
    dropout:        float = 0.2
    bidirectional:  bool  = True
    lr:             float = 1e-3
    batch_size:     int   = 64
    epochs:         int   = 30
    proj_dim:       int   = 64
    seq_len:        int   = 16
    calibration:    str   = "isotonic"


@dataclass
class XGBConfig:
    n_estimators:   int   = 200
    max_depth:      int   = 6
    learning_rate:  float = 0.05
    subsample:      float = 0.8
    colsample:      float = 0.8
    reg_alpha:      float = 0.1
    reg_lambda:     float = 1.0
    min_child_weight: int = 3
    calibration:    str   = "isotonic"


# ─────────────────────────────────────────────────────────────────────────────
# Shared: LLM Embedding Fusion
# ─────────────────────────────────────────────────────────────────────────────

class EmbeddingFusion(nn.Module):
    """
    Fuse a dense LLM embedding into the backbone representation.
    Modes: concat | add | gate
    """
    def __init__(
        self,
        embed_dim:    int,
        backbone_dim: int,
        proj_dim:     int  = 64,
        mode:         str  = "concat",
        dropout:      float = 0.1,
    ):
        super().__init__()
        self.mode         = mode
        self.backbone_dim = backbone_dim

        if mode == "concat":
            self.proj    = nn.Sequential(nn.Linear(embed_dim, proj_dim), nn.ReLU(), nn.Dropout(dropout))
            self.out_dim = backbone_dim + proj_dim
        elif mode == "add":
            self.proj    = nn.Sequential(nn.Linear(embed_dim, backbone_dim), nn.Tanh())
            self.out_dim = backbone_dim
        elif mode == "gate":
            self.proj    = nn.Sequential(nn.Linear(embed_dim, backbone_dim), nn.Tanh())
            self.gate    = nn.Sequential(nn.Linear(embed_dim, backbone_dim), nn.Sigmoid())
            self.out_dim = backbone_dim
        else:
            raise ValueError(f"Unknown fusion mode: {mode}")

        self.drop = nn.Dropout(dropout)

    def forward(self, backbone: torch.Tensor, embed: torch.Tensor) -> torch.Tensor:
        if self.mode == "concat":
            return torch.cat([backbone, self.drop(self.proj(embed))], dim=-1)
        elif self.mode == "add":
            return backbone + self.proj(embed)
        elif self.mode == "gate":
            g = self.gate(embed)
            return backbone * g + self.proj(embed) * (1 - g)


# ─────────────────────────────────────────────────────────────────────────────
# MLP
# ─────────────────────────────────────────────────────────────────────────────

class ResBlock(nn.Module):
    def __init__(self, dim: int, dropout: float, use_bn: bool, act: str):
        super().__init__()
        acts = {"relu": nn.ReLU, "gelu": nn.GELU, "silu": nn.SiLU}
        A = acts.get(act, nn.ReLU)
        self.net = nn.Sequential(
            nn.Linear(dim, dim),
            nn.BatchNorm1d(dim) if use_bn else nn.Identity(),
            A(),
            nn.Dropout(dropout),
            nn.Linear(dim, dim),
            nn.BatchNorm1d(dim) if use_bn else nn.Identity(),
        )
        self.act = A()

    def forward(self, x):
        return self.act(x + self.net(x))


class MLPNet(nn.Module):
    def __init__(
        self,
        in_features: int,
        embed_dim:   int,
        n_classes:   int,
        cfg:         MLPConfig,
    ):
        super().__init__()
        self.input_proj = nn.Linear(in_features, cfg.hidden_dim)
        self.blocks = nn.ModuleList([
            ResBlock(cfg.hidden_dim, cfg.dropout, cfg.use_batchnorm, cfg.activation)
            for _ in range(cfg.n_layers)
        ])
        self.fusion = EmbeddingFusion(embed_dim, cfg.hidden_dim, cfg.proj_dim, "concat")
        self.head   = nn.Linear(self.fusion.out_dim, n_classes)

    def forward(self, x: torch.Tensor, embed: torch.Tensor) -> torch.Tensor:
        h = F.relu(self.input_proj(x))
        for b in self.blocks:
            h = b(h)
        h = self.fusion(h, embed)
        return self.head(h)


# ─────────────────────────────────────────────────────────────────────────────
# CNN1D
# ─────────────────────────────────────────────────────────────────────────────

class CausalConvBlock(nn.Module):
    def __init__(self, ch: int, kernel: int, dilation: int, dropout: float, residual: bool):
        super().__init__()
        self.pad = (kernel - 1) * dilation
        self.conv = nn.Conv1d(ch, ch * 2, kernel_size=kernel, dilation=dilation, padding=0)
        self.drop = nn.Dropout(dropout)
        self.use_res = residual

    def forward(self, x):
        xp = F.pad(x, (self.pad, 0))
        h  = self.conv(xp)
        h1, h2 = h.chunk(2, dim=1)
        h  = torch.tanh(h1) * torch.sigmoid(h2)
        h  = self.drop(h)
        return h + x if self.use_res else h


class CNNNet(nn.Module):
    def __init__(
        self,
        n_features: int,
        embed_dim:  int,
        n_classes:  int,
        cfg:        CNNConfig,
    ):
        super().__init__()
        self.input_proj = nn.Conv1d(n_features, cfg.out_channels, kernel_size=1)
        self.blocks = nn.ModuleList([
            CausalConvBlock(
                cfg.out_channels,
                cfg.kernel_size,
                cfg.dilation_base ** i,
                cfg.dropout,
                cfg.use_residual,
            )
            for i in range(cfg.n_blocks)
        ])
        self.norm   = nn.LayerNorm(cfg.out_channels)
        self.fusion = EmbeddingFusion(embed_dim, cfg.out_channels, cfg.proj_dim, "gate")
        self.head   = nn.Linear(self.fusion.out_dim, n_classes)

    def forward(self, x: torch.Tensor, embed: torch.Tensor) -> torch.Tensor:
        # x: (batch, n_features, seq_len)
        h = self.input_proj(x)
        for b in self.blocks:
            h = b(h)
        h = h.mean(dim=-1)         # global avg pool
        h = self.norm(h)
        h = self.fusion(h, embed)
        return self.head(h)


# ─────────────────────────────────────────────────────────────────────────────
# LSTM
# ─────────────────────────────────────────────────────────────────────────────

class LSTMNet(nn.Module):
    def __init__(
        self,
        n_features: int,
        embed_dim:  int,
        n_classes:  int,
        cfg:        LSTMConfig,
    ):
        super().__init__()
        self.bidirectional = cfg.bidirectional
        self.hidden_size   = cfg.hidden_size
        self.lstm = nn.LSTM(
            input_size    = n_features,
            hidden_size   = cfg.hidden_size,
            num_layers    = cfg.n_layers,
            batch_first   = True,
            dropout       = cfg.dropout if cfg.n_layers > 1 else 0.0,
            bidirectional = cfg.bidirectional,
        )
        self.norm   = nn.LayerNorm(cfg.hidden_size)
        self.drop   = nn.Dropout(cfg.dropout)
        self.fusion = EmbeddingFusion(embed_dim, cfg.hidden_size, cfg.proj_dim, "add")
        self.head   = nn.Linear(self.fusion.out_dim, n_classes)

    def forward(self, x: torch.Tensor, embed: torch.Tensor) -> torch.Tensor:
        # x: (batch, seq_len, n_features)
        _, (h_n, _) = self.lstm(x)
        # forward direction last layer
        h = h_n[-2 if self.bidirectional else -1]   # (batch, hidden_size)
        h = self.norm(self.drop(h))
        h = self.fusion(h, embed)
        return self.head(h)


# ─────────────────────────────────────────────────────────────────────────────
# Sklearn-compatible wrapper for PyTorch models + calibration
# ─────────────────────────────────────────────────────────────────────────────

class TorchWrapper(BaseEstimator, ClassifierMixin):
    """
    Wrap a PyTorch model in an sklearn-compatible interface so we can
    use CalibratedClassifierCV on it.

    The wrapper expects numpy inputs (X, embed) packed as a single 2D
    array [X | embed] by concatenation on axis=1.
    """

    def __init__(
        self,
        model:        nn.Module,
        n_features:   int,
        embed_dim:    int,
        n_classes:    int,
        epochs:       int   = 30,
        lr:           float = 1e-3,
        batch_size:   int   = 64,
        model_type:   str   = "mlp",
        cfg           = None,
        device:       str   = "cpu",
    ):
        self.model       = model
        self.n_features  = n_features
        self.embed_dim   = embed_dim
        self.n_classes   = n_classes
        self.epochs      = epochs
        self.lr          = lr
        self.batch_size  = batch_size
        self.model_type  = model_type
        self.cfg         = cfg
        self.device      = device
        self.classes_    = np.arange(n_classes)
        self._loss_history: List[float] = []

    def _unpack(self, X: np.ndarray):
        """Split packed [X | embed] array."""
        x_part     = torch.tensor(X[:, :self.n_features], dtype=torch.float32).to(self.device)
        embed_part = torch.tensor(X[:, self.n_features:], dtype=torch.float32).to(self.device)
        return x_part, embed_part

    def fit(self, X: np.ndarray, y: np.ndarray, **kw) -> "TorchWrapper":
        self.model.to(self.device).train()
        optimizer = torch.optim.AdamW(self.model.parameters(), lr=self.lr, weight_decay=1e-4)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=self.epochs)
        criterion = nn.CrossEntropyLoss()
        self._loss_history = []

        n = len(X)
        for epoch in range(self.epochs):
            idx     = np.random.permutation(n)
            ep_loss = 0.0
            steps   = 0
            for start in range(0, n, self.batch_size):
                batch_idx = idx[start:start + self.batch_size]
                x_b, e_b = self._unpack(X[batch_idx])
                y_b       = torch.tensor(y[batch_idx], dtype=torch.long).to(self.device)

                optimizer.zero_grad()
                logits = self._forward(x_b, e_b)
                loss   = criterion(logits, y_b)
                loss.backward()
                nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                optimizer.step()
                ep_loss += loss.item()
                steps   += 1
            scheduler.step()
            self._loss_history.append(ep_loss / max(steps, 1))
        return self

    def _forward(self, x_b, e_b):
        cfg = self.cfg
        if self.model_type == "mlp":
            return self.model(x_b, e_b)
        elif self.model_type == "cnn":
            seq_len    = getattr(cfg, "seq_len", 16)
            n_features = self.n_features
            # Reshape flat → (batch, features, seq_len) with zero padding if needed
            batch = x_b.shape[0]
            needed = n_features * seq_len
            if x_b.shape[1] < needed:
                pad = torch.zeros(batch, needed - x_b.shape[1], device=self.device)
                x_b = torch.cat([x_b, pad], dim=1)
            x_3d = x_b[:, :needed].view(batch, n_features, seq_len)
            return self.model(x_3d, e_b)
        elif self.model_type == "lstm":
            seq_len    = getattr(cfg, "seq_len", 16)
            n_features = self.n_features
            batch      = x_b.shape[0]
            needed     = n_features * seq_len
            if x_b.shape[1] < needed:
                pad = torch.zeros(batch, needed - x_b.shape[1], device=self.device)
                x_b = torch.cat([x_b, pad], dim=1)
            x_3d = x_b[:, :needed].view(batch, seq_len, n_features)
            return self.model(x_3d, e_b)
        raise ValueError(f"Unknown model_type: {self.model_type}")

    @torch.no_grad()
    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        self.model.eval()
        probs = []
        for start in range(0, len(X), self.batch_size):
            x_b, e_b = self._unpack(X[start:start + self.batch_size])
            logits    = self._forward(x_b, e_b)
            probs.append(F.softmax(logits, dim=-1).cpu().numpy())
        return np.concatenate(probs, axis=0)

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.predict_proba(X).argmax(axis=1)


# ─────────────────────────────────────────────────────────────────────────────
# XGBoost wrapper with calibration
# ─────────────────────────────────────────────────────────────────────────────

class XGBoostModel:
    """
    XGBoost classifier.
    Calibration is handled externally by rolling_cv._train_xgb()
    using our own _fit_calibrators / _apply_calibrators, which avoids
    the sklearn CalibratedClassifierCV(cv=N) crash when a fold only
    contains a subset of the full class set.
    """

    def __init__(self, n_classes: int, cfg: XGBConfig):
        self.n_classes = n_classes
        self.cfg       = cfg
        self._base     = None
        self.classes_  = None

    def _make_base(self):
        try:
            from xgboost import XGBClassifier
        except ImportError:
            from sklearn.ensemble import GradientBoostingClassifier
            return GradientBoostingClassifier(
                n_estimators  = self.cfg.n_estimators,
                max_depth     = self.cfg.max_depth,
                learning_rate = self.cfg.learning_rate,
                subsample     = self.cfg.subsample,
                random_state  = 42,
            )
        return XGBClassifier(
            n_estimators     = self.cfg.n_estimators,
            max_depth        = self.cfg.max_depth,
            learning_rate    = self.cfg.learning_rate,
            subsample        = self.cfg.subsample,
            colsample_bytree = self.cfg.colsample,
            reg_alpha        = self.cfg.reg_alpha,
            reg_lambda       = self.cfg.reg_lambda,
            min_child_weight = self.cfg.min_child_weight,
            eval_metric      = "mlogloss",
            random_state     = 42,
            n_jobs           = -1,
            tree_method      = "hist",
        )

    def fit(self, X: np.ndarray, y: np.ndarray, **kwargs) -> "XGBoostModel":
        """Fit the base estimator. Calibration is done by rolling_cv."""
        self._base = self._make_base()
        self._base.fit(X, y)
        self.classes_ = self._base.classes_
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Return probability matrix aligned to n_classes columns."""
        raw     = self._base.predict_proba(X)
        classes = self._base.classes_
        if raw.shape[1] == self.n_classes:
            return raw
        full = np.zeros((len(X), self.n_classes), dtype=float)
        for col_idx, cls in enumerate(classes):
            if int(cls) < self.n_classes:
                full[:, int(cls)] = raw[:, col_idx]
        row_sums = full.sum(axis=1, keepdims=True)
        row_sums = np.where(row_sums < 1e-9, 1.0, row_sums)
        return full / row_sums

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.predict_proba(X).argmax(axis=1)

    def get_feature_importance(self, feature_names: List[str]) -> dict:
        try:
            imps = self._base.feature_importances_
            return {f: float(v) for f, v in zip(feature_names, imps)}
        except Exception:
            return {}


# ─────────────────────────────────────────────────────────────────────────────
# Generic sklearn / LightGBM wrapper
# ─────────────────────────────────────────────────────────────────────────────

class SklearnModel:
    """
    Unified wrapper for all sklearn and LightGBM classifiers.

    Handles:
      - Class-column alignment: when a fold doesn't contain all classes,
        predict_proba expands the output to n_classes columns.
      - Feature importance extraction for tree-based models.
      - A consistent .fit() / .predict_proba() / .predict() interface
        so rolling_cv._train_sklearn() can treat all of them identically.

    Models supported:
      Random Forest, Extra-Trees, Gradient Boosting,
      Histogram-Based Gradient Boosting, AdaBoost (DT base),
      Bagging (DT base), Stacking-1, Stacking-2, LightGBM.
    """

    def __init__(self, estimator, n_classes: int, model_name: str = "sklearn"):
        self.estimator  = estimator
        self.n_classes  = n_classes
        self.model_name = model_name
        self.classes_   = None
        self._fitted    = False

    def fit(self, X: np.ndarray, y: np.ndarray, **kwargs) -> "SklearnModel":
        self.estimator.fit(X, y)
        self.classes_ = getattr(self.estimator, "classes_", np.unique(y))
        self._fitted  = True
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        raw     = self.estimator.predict_proba(X)
        classes = self.classes_ if self.classes_ is not None else np.arange(raw.shape[1])

        if raw.shape[1] == self.n_classes:
            return raw

        # Expand to full n_classes columns
        full = np.zeros((len(X), self.n_classes), dtype=float)
        for col_idx, cls in enumerate(classes):
            if int(cls) < self.n_classes:
                full[:, int(cls)] = raw[:, col_idx]
        row_sums = full.sum(axis=1, keepdims=True)
        row_sums = np.where(row_sums < 1e-9, 1.0, row_sums)
        return full / row_sums

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.predict_proba(X).argmax(axis=1)

    def get_feature_importance(self, feature_names: List[str]) -> dict:
        est = self.estimator
        # Unwrap stacking: get importance from first base estimator
        if hasattr(est, "estimators_"):
            # StackingClassifier stores fitted estimators as list of (name, est)
            try:
                first = est.estimators_[0]
                if hasattr(first, "feature_importances_"):
                    imps = first.feature_importances_
                    return {f: float(v) for f, v in zip(feature_names, imps)}
            except Exception:
                pass
        if hasattr(est, "feature_importances_"):
            imps = est.feature_importances_
            return {f: float(v) for f, v in zip(feature_names, imps)}
        return {}


# ─────────────────────────────────────────────────────────────────────────────
# Sklearn / LightGBM configs
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class RFConfig:
    n_estimators:     int   = 200
    max_depth:        int   = 8       # was 15 — shallower prevents complete memorisation
    min_samples_leaf: int   = 4       # was 2
    min_samples_split:int   = 8       # was 3
    max_features:     str   = "sqrt"
    class_weight:     str   = "balanced_subsample"
    calibration:      str   = "isotonic"


@dataclass
class ETConfig:
    n_estimators:     int   = 200
    max_depth:        int   = 8       # was 15
    min_samples_leaf: int   = 4       # was 2
    min_samples_split:int   = 8       # was 3
    max_features:     str   = "sqrt"
    class_weight:     str   = "balanced_subsample"
    calibration:      str   = "isotonic"


@dataclass
class GBConfig:
    n_estimators:     int   = 150
    max_depth:        int   = 5
    learning_rate:    float = 0.05
    subsample:        float = 0.8
    min_samples_leaf: int   = 3
    calibration:      str   = "isotonic"


@dataclass
class HGBConfig:
    max_iter:         int   = 150
    max_depth:        int   = 6
    learning_rate:    float = 0.05
    min_samples_leaf: int   = 20
    l2_regularization:float = 1e-4
    calibration:      str   = "isotonic"


@dataclass
class AdaConfig:
    n_estimators:     int   = 100
    learning_rate:    float = 0.5
    dt_max_depth:     int   = 3
    calibration:      str   = "isotonic"


@dataclass
class BaggingConfig:
    n_estimators:     int   = 20
    max_samples:      float = 0.8
    max_features:     float = 0.8
    dt_max_depth:     int   = 8
    calibration:      str   = "isotonic"


@dataclass
class Stacking1Config:
    dt_max_depth:     int   = 8
    hgb_max_iter:     int   = 100
    ridge_alpha:      float = 1.0
    calibration:      str   = "isotonic"


@dataclass
class Stacking2Config:
    dt_max_depth:     int   = 8
    lr_C:             float = 1.0
    lr_max_iter:      int   = 1000
    ridge_alpha:      float = 1.0
    calibration:      str   = "isotonic"


@dataclass
class LGBMConfig:
    n_estimators:     int   = 200
    max_depth:        int   = 7
    learning_rate:    float = 0.05
    num_leaves:       int   = 63
    subsample:        float = 0.8
    colsample_bytree: float = 0.8
    reg_alpha:        float = 0.1
    reg_lambda:       float = 1.0
    min_child_samples:int   = 10
    calibration:      str   = "isotonic"


# ─────────────────────────────────────────────────────────────────────────────
# Sklearn / LightGBM builders
# ─────────────────────────────────────────────────────────────────────────────

def build_rf(n_classes: int, cfg: RFConfig) -> SklearnModel:
    from sklearn.ensemble import RandomForestClassifier
    est = RandomForestClassifier(
        n_estimators      = cfg.n_estimators,
        max_depth         = cfg.max_depth,
        min_samples_leaf  = cfg.min_samples_leaf,
        min_samples_split = cfg.min_samples_split,
        max_features      = cfg.max_features,
        class_weight      = cfg.class_weight,
        n_jobs            = -1,
        random_state      = 42,
    )
    return SklearnModel(est, n_classes, "rf")


def build_et(n_classes: int, cfg: ETConfig) -> SklearnModel:
    from sklearn.ensemble import ExtraTreesClassifier
    est = ExtraTreesClassifier(
        n_estimators      = cfg.n_estimators,
        max_depth         = cfg.max_depth,
        min_samples_leaf  = cfg.min_samples_leaf,
        min_samples_split = cfg.min_samples_split,
        max_features      = cfg.max_features,
        class_weight      = cfg.class_weight,
        n_jobs            = -1,
        random_state      = 42,
    )
    return SklearnModel(est, n_classes, "et")


def build_gb(n_classes: int, cfg: GBConfig) -> SklearnModel:
    from sklearn.ensemble import GradientBoostingClassifier
    est = GradientBoostingClassifier(
        n_estimators      = cfg.n_estimators,
        max_depth         = cfg.max_depth,
        learning_rate     = cfg.learning_rate,
        subsample         = cfg.subsample,
        min_samples_leaf  = cfg.min_samples_leaf,
        random_state      = 42,
    )
    return SklearnModel(est, n_classes, "gb")


def build_hgb(n_classes: int, cfg: HGBConfig) -> SklearnModel:
    from sklearn.ensemble import HistGradientBoostingClassifier
    est = HistGradientBoostingClassifier(
        max_iter           = cfg.max_iter,
        max_depth          = cfg.max_depth,
        learning_rate      = cfg.learning_rate,
        min_samples_leaf   = cfg.min_samples_leaf,
        l2_regularization  = cfg.l2_regularization,
        random_state       = 42,
    )
    return SklearnModel(est, n_classes, "hgb")


def build_ada(n_classes: int, cfg: AdaConfig) -> SklearnModel:
    from sklearn.ensemble import AdaBoostClassifier
    from sklearn.tree import DecisionTreeClassifier
    est = AdaBoostClassifier(
        estimator         = DecisionTreeClassifier(max_depth=cfg.dt_max_depth,
                                                    random_state=42),
        n_estimators      = cfg.n_estimators,
        learning_rate     = cfg.learning_rate,
        algorithm         = "SAMME",
        random_state      = 42,
    )
    return SklearnModel(est, n_classes, "ada")


def build_bagging(n_classes: int, cfg: BaggingConfig) -> SklearnModel:
    from sklearn.ensemble import BaggingClassifier
    from sklearn.tree import DecisionTreeClassifier
    est = BaggingClassifier(
        estimator         = DecisionTreeClassifier(max_depth=cfg.dt_max_depth,
                                                    random_state=42),
        n_estimators      = cfg.n_estimators,
        max_samples       = cfg.max_samples,
        max_features      = cfg.max_features,
        n_jobs            = -1,
        random_state      = 42,
    )
    return SklearnModel(est, n_classes, "bagging")


def build_stacking1(n_classes: int, cfg: Stacking1Config) -> SklearnModel:
    """
    Stacking-1:
      Base estimators: DecisionTree, HistGradientBoosting, GaussianNaiveBayes
      Final estimator: Ridge (via RidgeClassifier)
    """
    from sklearn.ensemble import (StackingClassifier,
                                   HistGradientBoostingClassifier)
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.naive_bayes import GaussianNB
    from sklearn.linear_model import RidgeClassifier
    from sklearn.calibration import CalibratedClassifierCV

    base = [
        ("dt",  DecisionTreeClassifier(max_depth=cfg.dt_max_depth,
                                        random_state=42)),
        ("hgb", HistGradientBoostingClassifier(max_iter=cfg.hgb_max_iter,
                                                random_state=42)),
        ("gnb", GaussianNB()),
    ]
    # RidgeClassifier has no predict_proba → wrap with calibration
    ridge = CalibratedClassifierCV(
        RidgeClassifier(alpha=cfg.ridge_alpha), cv=3
    )
    est = StackingClassifier(
        estimators       = base,
        final_estimator  = ridge,
        stack_method     = "predict_proba",
        passthrough      = False,
        n_jobs           = -1,
        cv               = 3,
    )
    return SklearnModel(est, n_classes, "stacking1")


def build_stacking2(n_classes: int, cfg: Stacking2Config) -> SklearnModel:
    """
    Stacking-2:
      Base estimators: DecisionTree, LogisticRegression, GaussianNaiveBayes
      Final estimator: Ridge (via RidgeClassifier)
    """
    from sklearn.ensemble import StackingClassifier
    from sklearn.tree import DecisionTreeClassifier
    from sklearn.naive_bayes import GaussianNB
    from sklearn.linear_model import LogisticRegression, RidgeClassifier
    from sklearn.calibration import CalibratedClassifierCV

    base = [
        ("dt",  DecisionTreeClassifier(max_depth=cfg.dt_max_depth,
                                        random_state=42)),
        ("lr",  LogisticRegression(C=cfg.lr_C, max_iter=cfg.lr_max_iter,
                                    solver="lbfgs", multi_class="multinomial",
                                    n_jobs=-1, random_state=42)),
        ("gnb", GaussianNB()),
    ]
    ridge = CalibratedClassifierCV(
        RidgeClassifier(alpha=cfg.ridge_alpha), cv=3
    )
    est = StackingClassifier(
        estimators       = base,
        final_estimator  = ridge,
        stack_method     = "predict_proba",
        passthrough      = False,
        n_jobs           = -1,
        cv               = 3,
    )
    return SklearnModel(est, n_classes, "stacking2")


def build_lgbm(n_classes: int, cfg: LGBMConfig) -> SklearnModel:
    try:
        from lightgbm import LGBMClassifier
        est = LGBMClassifier(
            n_estimators      = cfg.n_estimators,
            max_depth         = cfg.max_depth,
            learning_rate     = cfg.learning_rate,
            num_leaves        = cfg.num_leaves,
            subsample         = cfg.subsample,
            colsample_bytree  = cfg.colsample_bytree,
            reg_alpha         = cfg.reg_alpha,
            reg_lambda        = cfg.reg_lambda,
            min_child_samples = cfg.min_child_samples,
            class_weight      = "balanced",
            n_jobs            = -1,
            random_state      = 42,
            verbose           = -1,
        )
    except ImportError:
        # Graceful fallback to HGB if lightgbm not installed
        from sklearn.ensemble import HistGradientBoostingClassifier
        est = HistGradientBoostingClassifier(
            max_iter     = cfg.n_estimators,
            max_depth    = cfg.max_depth,
            learning_rate= cfg.learning_rate,
            random_state = 42,
        )
    return SklearnModel(est, n_classes, "lgbm")


# ─────────────────────────────────────────────────────────────────────────────
# Factory
# ─────────────────────────────────────────────────────────────────────────────

def build_mlp(
    n_features: int,
    embed_dim:  int,
    n_classes:  int,
    cfg:        MLPConfig,
    device:     str = "cpu",
) -> TorchWrapper:
    net = MLPNet(n_features, embed_dim, n_classes, cfg)
    return TorchWrapper(net, n_features, embed_dim, n_classes,
                        cfg.epochs, cfg.lr, cfg.batch_size,
                        "mlp", cfg, device)


def build_cnn(
    n_features: int,
    embed_dim:  int,
    n_classes:  int,
    cfg:        CNNConfig,
    device:     str = "cpu",
) -> TorchWrapper:
    net = CNNNet(n_features, embed_dim, n_classes, cfg)
    return TorchWrapper(net, n_features, embed_dim, n_classes,
                        cfg.epochs, cfg.lr, cfg.batch_size,
                        "cnn", cfg, device)


def build_lstm(
    n_features: int,
    embed_dim:  int,
    n_classes:  int,
    cfg:        LSTMConfig,
    device:     str = "cpu",
) -> TorchWrapper:
    net = LSTMNet(n_features, embed_dim, n_classes, cfg)
    return TorchWrapper(net, n_features, embed_dim, n_classes,
                        cfg.epochs, cfg.lr, cfg.batch_size,
                        "lstm", cfg, device)
