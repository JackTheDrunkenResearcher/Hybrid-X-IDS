"""
models/embeddings.py

Per-window LLM embeddings for UAV intrusion detection.

For each rolling window, a context string is built from the window's
aggregate UAV flow statistics (mean, std, min, max per feature) and
sent to the chosen LLM provider. The returned dense vector is
concatenated to the feature matrix as additional conditioning signal
for the MLP, CNN, and LSTM models.

Providers
---------
  claude     — Anthropic (hash-proxy; Anthropic has no embedding API)
  gpt-4o     — OpenAI text-embedding-3-small
  qwen       — Qwen-Turbo via DashScope OR via Ollama (qwen2:7b)
  llama      — Meta Llama 3 via Ollama

All embeddings are cached to disk keyed by SHA-256 of the context string
so re-runs with the same window data never re-call the API.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import struct
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Optional

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

# Fixed embedding dimension used throughout the architecture.
# All providers are projected to this size via a linear layer in the models.
EMBED_DIM = 256


# ─────────────────────────────────────────────────────────────────────────────
# Config
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class EmbeddingConfig:
    provider:    str   = "gpt-4o"        # claude | gpt-4o | qwen | llama
    cache_dir:   str   = "./embed_cache"
    timeout_s:   float = 60.0
    max_retries: int   = 3

    # OpenAI
    openai_api_key_env:    str = "OPENAI_API_KEY"
    openai_embed_model:    str = "text-embedding-3-small"

    # Anthropic (hash-proxy — no embedding API)
    anthropic_api_key_env: str = "ANTHROPIC_API_KEY"

    # Qwen — via DashScope or Ollama
    qwen_via_ollama:       bool = True
    qwen_ollama_model:     str  = "qwen2:7b"
    dashscope_api_key_env: str  = "DASHSCOPE_API_KEY"
    qwen_embed_model:      str  = "text-embedding-v2"

    # Llama — via Ollama
    llama_ollama_model:    str  = "llama3.1:8b"
    ollama_base_url:       str  = "http://localhost:11434"


# ─────────────────────────────────────────────────────────────────────────────
# Context string builder
# ─────────────────────────────────────────────────────────────────────────────

def build_window_context(
    X_window: pd.DataFrame,
    Y_window: pd.Series,
    class_names: list,
    window_idx: int,
) -> str:
    """
    Build a text summary of a rolling window for LLM embedding.

    Includes aggregate statistics per feature and the class distribution
    of the window (labels are known at training time).
    """
    lines = [
        f"UAV network intrusion detection — window {window_idx}",
        f"Window size: {len(X_window)} flow records",
        "",
        "Class distribution in this window:",
    ]
    vc = Y_window.value_counts().sort_index()
    for cls_id, cnt in vc.items():
        cls_name = class_names[int(cls_id)] if int(cls_id) < len(class_names) else str(cls_id)
        lines.append(f"  {cls_name}: {cnt} ({100*cnt/len(Y_window):.1f}%)")

    lines.append("")
    lines.append("Feature statistics (mean | std | min | max):")
    for col in X_window.columns[:20]:  # cap at 20 for token budget
        v = X_window[col].dropna()
        if len(v) == 0:
            continue
        lines.append(
            f"  {col}: {v.mean():.4f} | {v.std():.4f} "
            f"| {v.min():.4f} | {v.max():.4f}"
        )

    return "\n".join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# Disk cache
# ─────────────────────────────────────────────────────────────────────────────

class EmbeddingCache:
    def __init__(self, cache_dir: str):
        self.path = Path(cache_dir)
        self.path.mkdir(parents=True, exist_ok=True)

    def _key(self, provider: str, text: str) -> str:
        return hashlib.sha256(f"{provider}::{text}".encode()).hexdigest()[:20]

    def get(self, provider: str, text: str) -> Optional[np.ndarray]:
        p = self.path / f"{self._key(provider, text)}.npy"
        if p.exists():
            try:
                return np.load(str(p))
            except Exception:
                return None
        return None

    def set(self, provider: str, text: str, vec: np.ndarray) -> None:
        p = self.path / f"{self._key(provider, text)}.npy"
        try:
            np.save(str(p), vec)
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────────────────────
# Provider clients
# ─────────────────────────────────────────────────────────────────────────────

def _project_to_dim(vec: np.ndarray, target_dim: int = EMBED_DIM) -> np.ndarray:
    """Project / pad / truncate any vector to target_dim using a deterministic seed."""
    vec = vec.astype(np.float32)
    if len(vec) == target_dim:
        return vec
    if len(vec) > target_dim:
        return vec[:target_dim]
    # Pad with deterministic noise seeded by hash of vec
    seed = int(hashlib.sha256(vec.tobytes()).hexdigest()[:8], 16) % (2**32)
    rng  = np.random.default_rng(seed)
    pad  = rng.standard_normal(target_dim - len(vec)).astype(np.float32)
    return np.concatenate([vec, pad])


def _embed_openai(text: str, cfg: EmbeddingConfig) -> np.ndarray:
    from openai import OpenAI
    key    = os.environ.get(cfg.openai_api_key_env, "")
    client = OpenAI(api_key=key, timeout=cfg.timeout_s)
    resp   = client.embeddings.create(model=cfg.openai_embed_model, input=text[:8000])
    raw    = np.array(resp.data[0].embedding, dtype=np.float32)
    return _project_to_dim(raw)


def _embed_anthropic_proxy(text: str, cfg: EmbeddingConfig) -> np.ndarray:
    """
    Anthropic has no public embedding API.
    We use a deterministic hash-based proxy: the SHA-256 of the text
    seeds a random unit vector. This is consistent (same text → same vec)
    and serves as a meaningful 'fingerprint' of the window context.
    In production, pair Claude forecasts with OpenAI embeddings.
    """
    h   = hashlib.sha256(text.encode()).digest()
    seed = struct.unpack("Q", h[:8])[0]
    rng  = np.random.default_rng(seed % (2**32))
    vec  = rng.standard_normal(EMBED_DIM).astype(np.float32)
    vec /= np.linalg.norm(vec) + 1e-9
    logger.info("[claude] using hash-proxy embedding (no Anthropic embed API)")
    return vec


def _embed_ollama(text: str, model: str, base_url: str, timeout: float) -> np.ndarray:
    import requests
    resp = requests.post(
        f"{base_url}/api/embeddings",
        json={"model": model, "prompt": text[:4000]},
        timeout=timeout,
    )
    resp.raise_for_status()
    raw = np.array(resp.json()["embedding"], dtype=np.float32)
    return _project_to_dim(raw)


def _embed_qwen_dashscope(text: str, cfg: EmbeddingConfig) -> np.ndarray:
    import requests
    key = os.environ.get(cfg.dashscope_api_key_env, "")
    resp = requests.post(
        "https://dashscope.aliyuncs.com/api/v1/services/embeddings/text-embedding/text-embedding",
        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
        json={"model": cfg.qwen_embed_model,
              "input": {"texts": [text[:2048]]}},
        timeout=cfg.timeout_s,
    )
    resp.raise_for_status()
    raw = np.array(
        resp.json()["output"]["embeddings"][0]["embedding"],
        dtype=np.float32,
    )
    return _project_to_dim(raw)


# ─────────────────────────────────────────────────────────────────────────────
# Main embedder
# ─────────────────────────────────────────────────────────────────────────────

class WindowEmbedder:
    """
    Generates a fixed-size embedding vector for each rolling window.

    Usage
    -----
    embedder = WindowEmbedder(cfg)
    vec = embedder.embed(X_window, Y_window, class_names, window_idx=0)
    # vec.shape == (EMBED_DIM,)
    """

    def __init__(self, cfg: EmbeddingConfig):
        self.cfg   = cfg
        self.cache = EmbeddingCache(cfg.cache_dir)

    def embed(
        self,
        X_window:    pd.DataFrame,
        Y_window:    pd.Series,
        class_names: list,
        window_idx:  int = 0,
    ) -> np.ndarray:
        text = build_window_context(X_window, Y_window, class_names, window_idx)

        # Try cache first
        cached = self.cache.get(self.cfg.provider, text)
        if cached is not None:
            return cached

        vec = self._call_provider(text)
        self.cache.set(self.cfg.provider, text, vec)
        return vec

    def _call_provider(self, text: str) -> np.ndarray:
        cfg = self.cfg
        for attempt in range(cfg.max_retries):
            try:
                if cfg.provider == "gpt-4o":
                    return _embed_openai(text, cfg)

                elif cfg.provider == "claude":
                    return _embed_anthropic_proxy(text, cfg)

                elif cfg.provider == "qwen":
                    if cfg.qwen_via_ollama:
                        return _embed_ollama(
                            text, cfg.qwen_ollama_model,
                            cfg.ollama_base_url, cfg.timeout_s,
                        )
                    else:
                        return _embed_qwen_dashscope(text, cfg)

                elif cfg.provider == "llama":
                    return _embed_ollama(
                        text, cfg.llama_ollama_model,
                        cfg.ollama_base_url, cfg.timeout_s,
                    )

                else:
                    logger.warning(f"Unknown provider '{cfg.provider}', using hash proxy")
                    return _embed_anthropic_proxy(text, cfg)

            except Exception as e:
                logger.warning(f"[{cfg.provider}] embed attempt {attempt+1} failed: {e}")
                if attempt < cfg.max_retries - 1:
                    time.sleep(2 ** attempt)

        # Final fallback
        logger.error(f"[{cfg.provider}] all attempts failed — using zero vector")
        return np.zeros(EMBED_DIM, dtype=np.float32)

    @property
    def embed_dim(self) -> int:
        return EMBED_DIM
